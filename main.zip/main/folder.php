<?php
/* $carpeta = '/main/pages/suplentes/soportes/cedula.jpg';
$nombre_fichero = 'pages/suplentes/soportes/cedula.jpg';

if (file_exists($nombre_fichero)) {
    echo "El fichero $nombre_fichero existe";
} else {
    echo "El fichero $nombre_fichero no existe";
} */

$carpeta = '/var/www/main/pages/suplentes/soportes/touch';
if (!file_exists($carpeta)) {
    mkdir($carpeta, 0777, true);
}
?>