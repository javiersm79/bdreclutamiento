<?php 
	//define el IP para la conexion a la base de datos 
	define("SERVIDOR","190.168.128.109"); //"150.186.64.77"
	//define el nombre de la base de datos 
	//define("BD","suplenciadev");   
	define("BD","suplenciaudo");   
	//define el usuario para la conexion a la base de datos 
	define("USUARIO","pgsuplencia"); 
	//define la clave para la conexion a la base de datos 
	define("CLAVE","pgsuplencia"); 
	//define el Puerto de la conexion a la base de datos 
	define("PUERTO","5432");
/* 	define("UNO",1);
	define("CERO",0);
	define("CTA_IVA","40318010000"); */
?>
