<?php 
include_once("BD.php");
$bd=new Datos();
$bd -> conectar();

print_r ($bd -> consultar($_POST["sql"]));
//$imprimir = $bd -> actualizar('UPDATE usuario SET activo=1 WHERE id_tipousuario=3');

$bd -> desconectar();
?>
