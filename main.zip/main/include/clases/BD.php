<?php
//session_start();
include_once('constantes.php');
class Datos
	{
/*		private $conectar;
		private $nimpreso;
 		private $mnombreBD;
		private $mservidor;
		private $musuario;
		private $mclave;
		private $mpuerto;
		//____Constructor de la clase
		function __construct($mnombreBD, $mservidor, $musuario, $mclave, $mpuerto)
		{
			 $this->mnombreBD = $mnombreBD;
			 $this->mservidor = $mservidor;
			 $this->musuario = $musuario;
			 $this->mclave = $mclave;
			 $this->mpuerto = $mpuerto;
		} 

		function __destruct()
		{
		}*/
		//Metodo para ralizar la conexion a la base de datos 
		function conectar()
		{
			try {
				$this->mdb = new PDO('pgsql:dbname='.BD.';user='.USUARIO.';password='.CLAVE.';host='.SERVIDOR);
				return 1;
			} 
			catch (PDOException $e) {
				return 0;
			}
			
		}//____fin conectar
		
		function desconectar() // metodo para desconectar la conexion a la base de datos
		{
			$this->mdb = null;
		}
		
		function insertar($tabla,$columnaValor)
		{
				$clave;
				$valor;
	            $sql;
				$col='(';    //____necesario para concatenar las columnas a ser afectadas en la tabla	
				$val='(';    //____necesario para concatenar los valores a ser insertados en la tabla	
		
				//_____recorremos el arreglo asociativo para extraer los valores pasados
				while(list($clave,$valor)=each($columnaValor)) 
				{	//____while_ini
					$col.=$clave.', ';
					if ($valor=='default')
						$val.=$valor.", ";
					else
						$val.="'".addslashes($valor)."', ";
				}	//____while_fin
	
				//____recorremos el arreglo asociativo para extraer los valores pasados
				$col=substr($col,0,strlen($col)-2);	//____retiro el ultimo caracter ingresado por el ciclo
				$val=substr($val,0,strlen($val)-2);	//____retiro el ultimo caracter ingresado por el ciclo
				$col.=')';//cerramos las columnas
				$val.=')';//cerramos los valores ha ingresar
		
				//____construimos el string sql que vamos ha ejecutar
				$sql='INSERT INTO '.$tabla.' '.$col.' VALUES '.$val;
				//echo $sql."<br>";
				//Enviando a BD y devuelve el numero de filas afectadas
				$count = $this->mdb->exec($sql) or $count = 0;
				
				if ($count > 0) //____Verificamos que la  consulta se ejecuto correctamente
				{    
					return 1; // "Registro ingresado exitosamente";
				}
				else
				{    
					return 0; // "Error al ingresar registro";
				}

		}	//____fin_insertar
		
		function consultar($sql) // metodo para desconectar la conexion a la base de datos
		{
			
			//$resultado = $this->mdb->prepare($sql);
			//$resultado->execute();
			$consulta =  $this->mdb->query($sql);
			$resultado = $consulta->fetchAll(PDO::FETCH_ASSOC);
			//$count = $consulta->rowCount(); 
			/* Return number of rows that were affected */
			//print("Regresa el numero de filas afectadas:\n");
			//$count = $resultado->rowCount();
			if (count($resultado) >0)
			{
				//echo json_encode($resultado);
				return $resultado;
			}
			else
			{
				return 0;
			}
		}//____fin_consultar,
		
		
/* 		function actualizar($sql) // metodo para actualizar datos en la BD
		{
			$count = $this->mdb->exec($sql) or $count = 0;

			if ($count >0)
			{
				return $count;
			}
			else
			{
				return 0;
			}
		}//____fin_actualizar, */
		
		function actualizar($tabla,$columnaValor,$colCond,$cond)
		{
				$clave;
				$valor;
	            $sql;
				$col;    //____necesario para concatenar las columnas a ser afectadas en la tabla	
				$val;    //____necesario para concatenar los valores a ser insertados en la tabla	
				$colval;
				//_____recorremos el arreglo asociativo para extraer los valores pasados
				while(list($clave,$valor)=each($columnaValor)) 
				{	//____while_ini
					if ($valor=='default')
						$val=$valor.", ";
					else
						$val="'".addslashes($valor)."'";
					$colval.= $clave.'= '.$val.', ';
				}	//____while_fin
	
				//____recorremos el arreglo asociativo para extraer los valores pasados
				$colval=substr($colval,0,strlen($colval)-2);	//____retiro el ultimo caracter ingresado por el ciclo

		
				//____construimos el string sql que vamos ha ejecutar
				$sql='UPDATE '.$tabla.' SET '.$colval. ' WHERE '.$colCond.'='.$cond;
				//echo $sql."\n";
				//Enviando a BD y devuelve el numero de filas afectadas
 				$count = $this->mdb->exec($sql) or $count = 0;
				
				if ($count > 0) //____Verificamos que la  consulta se ejecuto correctamente
				{    
					return 1; // "Registro ingresado exitosamente";
				}
				else
				{    
					return 0; // "Error al ingresar registro";
				} 

		}	//____fin_insertar
		
	} //Fin clase datos
			
?>