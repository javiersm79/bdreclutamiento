<form name="test" method="post" action="interfazbd.php">
  SQL:<br>
  <input type="text" name="sql">

  <input type="submit" value="Enviar" />
</form>
