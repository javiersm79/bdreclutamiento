function cargarLstDsp(idilsta,datos)
{
			//var cars = ["Saab", "Volvo", "BMW"];
			var cmb = $('#'+idilsta+'');
            cmb.empty();
			$.each( datos, function( key, value ) {
			  var option = $("<option></option>").attr("value", key).text(value).appendTo(cmb);
			});	
			$("<option></option>").attr("value", "").text("Seleccione").appendTo(cmb);
		
}

function tabChkOk(tab)
{
	var nombretab = tab.text();
	tab.html(nombretab + "<i class='fa fa-check' style='color: #00a65a'></i>");
}

function msgNotificar(msgDiv, msgTipo, msgTxt)
{

	switch (msgTipo) {
	case 'advertencia':
		$('#'+msgDiv+'').html('<div class="ui-state-highlight ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;'+ msgTxt +' </h4></div>');
		$('#'+msgDiv+'').show();
		$('#'+msgDiv+'').delay(5000).fadeOut(1500);
		break;
	case 'error':
		$('#'+msgDiv+'').html('<div class="ui-state-error ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-remove"></i><strong>&nbsp;'+ msgTxt +' </h4></div>');
		$('#'+msgDiv+'').show();
		$('#'+msgDiv+'').delay(5000).fadeOut(1500);
		break;
	case 'exito':
		$('#'+msgDiv+'').html('<div class="bg-green-active color-palette ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-check"></i><strong>&nbsp;'+ msgTxt +' </h4></div>');
		$('#'+msgDiv+'').show();
		$('#'+msgDiv+'').delay(5000).fadeOut(1500);
		break;
	}

}
//********************** Acepta solo numeros en los inputs con la clase numeric *******************
$(document).on("input", ".numeric", function(e) {
    this.value = this.value.replace(/[^0-9\.]/g,'');
});

//************************Funcion cargar menu************************
function cargarmenu(tipoUser)
{
	switch(tipoUser) {
    case 0:
        menuhtml = "menu.html";
        break;
    case 1:
        menuhtml = "menu0.html";
        break;
    default:
		menuhtml = "menu.html";
        break;
        
}
	
	$("#menu").load("/main/include/seg/menu/"+menuhtml, function(responseTxt, statusTxt, xhr){
			if(statusTxt == "success")
				//alert("External content loaded successfully!");
				//$("#solicitarSuplencia").addClass('active');
			if(statusTxt == "error")
				//alert("Error: " + xhr.status + ": " + xhr.statusText);
				alert("Error al cargar el menu");
		});
}

//************************Fin de Funcion cargar menu************************

//************************ Random String alfanumerico ************************
function randString(n)
{
    if(!n)
    {
        n = 5;
    }

    var text = '';
    var possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

    for(var i=0; i < n; i++)
    {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }

    return text;
}
//************************Fin de Funcion Random String alfanumerico************************
//************************ BootstrapDialog ************************
function notificar (titulo, mnsj, tipoMnsj)
{
var notificacion = BootstrapDialog;
notificacion.show({
			type:  tipoMnsj,
            title: titulo,
            message: mnsj
        });
}
//************************Fin de BootstrapDialog************************