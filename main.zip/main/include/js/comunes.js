function registrarUsuario(tipoUsuario)
{
	//alert("X");
	var cedula = $('#precedula').val() + '-' +$('#cedula').val();
	var nombre = $('#nombres').val();
	var apellido = $('#apellidos').val();
	var email = $('#email').val();
	var estado = $('#estado').val();
	var municipio = $('#municipio').val();
	var parroquia = $('#parroquia').val();
	var clave = randString(6);
	
	var emailValido = validarEmail(email);

	if (emailValido)
	{
		 $.ajax({
		  type: 'POST',
		  url: 'include/seg/registrarusuario.php',
		  dataType: 'json',
		  data :	{'nombre':nombre,'apellido':apellido,'email':email,'clave':clave,'cedula':cedula,'estado':estado,'municipio':municipio,'parroquia':parroquia},
		  cache: false,
		  success: function(data) {
			if (data==0)
				{
					var mnsj = 'Email regisrado en el sistema'
					notificar ("Aviso",mnsj, "type-warning");
					/* $( "#errorReg" ).css("visibility", 'visible');
					for(i=0;i<3;i++) {
						$("#errorReg").fadeTo('slow', 0.5).fadeTo('slow', 1.0);
					} */
					//enviarEmail (email, "titulo", "mensaje");
				}
			else
				{
					$( "#errorReg" ).css("visibility", 'hidden');
					var mnsj = 'Su registro se realizo de manera exitosa. <br>  \
					Ingrese al sistema con la clave enviada al correo:&nbsp;<b>' + $("#email").val() + '</b> y complete sus datos'
					notificar ("Regsitro Exitoso",mnsj, "type-success");
/* 					var mnsj = 'Bienvenido <b>' + nombre +'</b><br>  \
					Debe completar los datos de registro para ser un candidato valido<br>  \
					Su clave de ingreso es: '+clave; */
					enviarEmailRegistro (email, nombre + " " + apellido, clave);
					
				}
		  },
		  });
	}
	else
	{
		var mnsj = 'Formato de <b>Email</b> invalido'
		notificar ("Aviso",mnsj, "type-danger");	
	}
	
	
}


function iniciarSesion(){
	var user = $('#username').val();
	var clave = $('#password').val();
		 $.ajax({
		  type: 'POST',
		  url: 'include/seg/login.php',
		  dataType: 'json',
		  data :	{'username':user,'password':clave},
		  cache: false,
		  success: function(data) {
			if (data==0)
				{
					$( "#errorlogin" ).css("visibility", 'visible');
					for(i=0;i<3;i++) {
						$("#errorlogin").fadeTo('slow', 0.5).fadeTo('slow', 1.0);
					}
					
				}
			else /* if (data==1)
				{window.location="pages/solicitudes/formulario.php";}
			else if (data==3)
				{window.location="pages/suplentes/gestionardatos.php";} */
			switch(data) {
				case 1:
					window.location="pages/suplentes/buscarsuplente.php";
					break;
				case 2:
					
					break;				
				case 3:
					
					break;				
				case 4:
					
					break;				
				case 5:
					
					break;				
				case 6:
					window.location="pages/suplentes/gestionardatos.php";
					break;				

			}

		  },
		  });
	
}

function cerrarSesion(){		
	$.ajax( {
			type : 'POST',
			url : 'include/seg/logout.php',	
			data :	{'accion':'closeSession'},
			error : function(xhr, ajaxOptions, thrownError) {
				alert("ERROR");
			},
			success : function(req){
				window.location="/main/";
			}
	});
	
}

function enviarClave(email){		
			
	var email = $('#username').val();
		 $.ajax({
		  type: 'POST',
		  url : 'include/seg/enviarEmailClave.php',
		  data :	{'username':email},
		  cache: false,
		  success:function(data){			
			
 			//var data=$.parseJSON(req);
			//mnsj=req;
			//notificar ("Error","SSSSSS", "type-danger");
			if (data==0)
				{
					notificar ("Aviso","Su clave fue enviada exitosamente al email", "type-success");
					
				}
			else
				{
					//alert (data["clave"])
					//enviarEmailClave(email,data)
					notificar ("Error","Ocurrió un error a recuperar su clave. Verifique su email. Si el problema persiste comunicarse con el administrador", "type-danger");
				} 
			},
		  });
	
}

function validarCNE(tipoced,cedula){
	var tipoced = $('#precedula').val();
	var cedula = $('#cedula').val();
		$.ajax({
		type:'POST',
		async:false,
		//url:"datosfrm.php",
		url: 'include/clases/getCNE.php',
		data:{"tipoced":tipoced,"cedula":cedula},
		error:function(xhr,ajaxOptions,thrownError){
			//$('#msgFooterDatos').html('<div class="ui-state-error ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;Error!</strong> Intente nuevamente</h4></div>');
			mnsj="Error al enviar el Email.. Contactar al Administrador suplencias@udo.edu.ve"
			notificar ("Error",mnsj, "type-danger");
		},
		success:function(req){
			  var data=$.parseJSON(req);
			 
 			if (data["error"]==0)
				{
					//$('#nombres').val(data["nombres"]);
					//$('#precedula').val(data["nombres"]);
					$('#precedula').prop('disabled', true);
					$('#cedula').prop('disabled', true);
					$('#nombres').val(data["nombres"]);
					$('#apellidos').val(data["apellidos"]);
					$('#parroquia').val(data["cvparroquia"].slice(4));
					$('#municipio').val(data["cvmunicipio"].slice(4));
					$('#estado').val(data["cvestado"].slice(5));
					$('#btnRegistrar').prop('disabled', false);
					$('#btnValidar').prop('disabled', true);
				}
			else
				{
					mnsj="Cedula no registrada en la Base de Datos Nacional <br />(Fuente: <a href='http://www.cne.gob.ve/web/index.php'>http://www.cne.gob.ve/</a>)"
					notificar ("Error",mnsj, "type-danger");
				} 
		  },
		  });
	
}

function enviarEmailRegistro(email,nombreuser,clave){		
		 $.ajax({
		  type: 'POST',
		  url: 'include/seg/enviarEmailRegistro.php',
		  dataType: 'json',
		  data :	{'nombreuser':nombreuser,'clave':clave,'email':email},
		  cache: false,
		  success: function(data) {
			if (data==0)
				{
					window.location="/main/";
				}
			else
				{
					mnsj="Error al enviar el Email.. Contactar al Administrador suplencias@udo.edu.ve"
					notificar ("Error",mnsj, "type-danger");
				}
		  },
		  });
	
}

function enviarEmailClave(email,clave){		
		 $.ajax({
		  type: 'POST',
		  url: 'include/seg/enviarEmailClave.php',
		  dataType: 'json',
		  data :	{'clave':clave,'email':email},
		  cache: false,
		  success: function(data) {
			if (data==0)
				{
					mnsj="El Email con su Clave de Acceso fue enviado existosamente"
					notificar ("Error",mnsj, "type-success");
				}
			else
				{
					mnsj="Error al enviar el Email.. Contactar al Administrador suplencias@udo.edu.ve"
					notificar ("Error",mnsj, "type-danger");
				}
		  },
		  });
	
}

function validarEmail (email)
{

// Verificar el formato del email
var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
var valido = filter.test(email);
return valido
//*****************

}

function limpiarRegistro ()
{
	$('#precedula').prop('disabled', false);
	$('#cedula').prop('disabled', false);
	$('#precedula').val('V');
	$('#cedula').val('');
	$('#nombres').val('');
	$('#apellidos').val('');
	$('#email').val('');
	$('#btnRegistrar').prop('disabled', true);
	$('#btnValidar').prop('disabled', false);
}

