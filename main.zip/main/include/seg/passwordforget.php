<?php 

    // First we execute our common code to connection to the database and start the session 
    require("common.php"); 
     
    // This variable will be used to re-display the user's username to them in the 
    // login form if they fail to enter the correct password.  It is initialized here
    // to an empty value, which will be shown if the user has not submitted the form.
    //$submitted_username = ''; 
     
    // This if statement checks to determine whether the login form has been submitted 
    // If it has, then the login code is run, otherwise the form is displayed 
    if(!empty($_POST)) 
    { 
        // This query retreives the user's information from the database using 
        // their username. 
        $query = "
					SELECT DISTINCT
					a.*,
					b.nombretipo
					FROM 
					persona as a JOIN 
					tipousuario as b ON (a.id_tipousuario  = b.id_tipousuario) 
					WHERE
					usuario = :username
        "; 
        // The parameter values 
        $query_params = array( 
            ':username' => $_POST['username'] 
        ); 
         
        try 
        { 
            // Execute the query against the database 
            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 
        } 
        catch(PDOException $ex) 
        { 
            // Note: On a production website, you should not output $ex->getMessage(). 
            // It may provide an attacker with helpful information about your code.  
            die("Error con el servidor: " . $ex->getMessage()); 
        } 
         
        
        // Retrieve the user data from the database.  If $row is false, then the username 
        // they entered is not registered. 
        $row = $stmt->fetch(); 
		
        if($row) 
        { 
          // echo $row['clave'];
            echo json_encode($row);
			//echo 1;
        } 
        else 
        { 
            echo 0;
        } 
    }
     
?>