<?php 

    // First we execute our common code to connection to the database and start the session 
    require("common.php"); 
    
    // This variable will be used to re-display the user's username to them in the 
    // login form if they fail to enter the correct password.  It is initialized here
    // to an empty value, which will be shown if the user has not submitted the form.
    //$submitted_username = ''; 
    
    // This if statement checks to determine whether the login form has been submitted 
    // If it has, then the login code is run, otherwise the form is displayed 
    if(!empty($_POST)) 
    { 
        // This query retreives the user's information from the database using 
        // their username. 
        $query = " 
            SELECT *
            FROM persona 
            WHERE 
                email = :email 
        "; 
         //echo $query . "/n";
        // The parameter values 
        $query_params = array( 
            ':email' => $_POST['email'] 
        );

        try 
        { 
            // Execute the query against the database 
            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 
        } 
        catch(PDOException $ex) 
        { 
            // Note: On a production website, you should not output $ex->getMessage(). 
            // It may provide an attacker with helpful information about your code.  
            die("Error con el servidor: " . $ex->getMessage()); 
        } 
         
         
        // Retrieve the user data from the database.  If $row is false, then the username 
        // they entered is not registered. 
        $row = $stmt->fetch(); 
		
		//Si existe un usuario registrado con ese correo devuelve 0
        if($row) 
        { 
			echo 0;	

        } 
		else
		{
			//print_r($_POST);
			//echo "\n \n";
			//Insrerta al candidato en la BD
			$cedula = $_POST['cedula'];
			$nombre = $_POST['nombre'];
			$apellido = $_POST['apellido'];
			$estado = $_POST['estado'];
			$municipio = $_POST['municipio'];
			$parroquia = $_POST['parroquia'];
			$email = $_POST['email'];
			$clave = $_POST['clave'];
			$query = " INSERT INTO persona (cedula, nombres, apellidos, email, usuario, clave, id_tipousuario, activo, estado, municipio, parroquia) VALUES ('$cedula', '$nombre', '$apellido', '$email', '$email', '$clave', 6, 1, '$estado', '$municipio', '$parroquia')"; 
			//echo $query;

			try 
			{ 
				// Execute the query against the database 
				$db->exec($query); 
				//$result = $stmt->execute($query_params); 
			} 
			catch(PDOException $ex) 
			{ 
				// Note: On a production website, you should not output $ex->getMessage(). 
				// It may provide an attacker with helpful information about your code.  
				die("Error con el servidor: " . $ex->getMessage()); 
			} 
			
			//Crea la carpetas para soportes en "pages/suplentes"
			
			$query = " 
				SELECT *
				FROM persona 
				WHERE 
					email = :email 
			"; 
			 //echo $query . "/n";
			// The parameter values 
			$query_params = array( 
				':email' => $_POST['email'] 
			);

			try 
			{ 
				// Execute the query against the database 
				$stmt = $db->prepare($query); 
				$result = $stmt->execute($query_params); 
				// Retrieve the user data from the database.  If $row is false, then the username 
				// they entered is not registered. 
				$row = $stmt->fetch(); 
				// Crea la carpeta de soportes para adjuntos
				$carpeta = '/var/www/main/pages/suplentes/soportes/'.$row["id_persona"];
				$carpeta = strval($carpeta);
				$query_carcteristicas = " INSERT INTO persona_caracteristicas (id_persona, profesion, fortaleza1, fortaleza2, fortaleza3, sexo, motricidad) VALUES (".$row["id_persona"].", '',0,0,0,0,0)";
				$db->exec($query_carcteristicas); 				
				if (!file_exists($carpeta)) {
					mkdir($carpeta, 0777, true);
				}
			} 
			catch(PDOException $ex) 
			{ 
				// Note: On a production website, you should not output $ex->getMessage(). 
				// It may provide an attacker with helpful information about your code.  
				die("Error con el servidor: " . $ex->getMessage()); 
			} 
			 
			 

			
			
			echo $row["id_persona"];
			
		/* Sends the mail and outputs the "Thank you" string if the mail is successfully sent, or the error string otherwise. */
			/* 	if (mail($email,$titulo,$mensaje)) {
			  echo 1;
			} 
			else {
			  //echo 0;
			  print_r($_POST);
			} */

		}
         
		
        // If the user logged in successfully, then we send them to the private members-only page 
        // Otherwise, we display a login failed message and show the login form again
/*         if($existe_ok) 
        { 
			echo 1;
        } 
        else 
        { 
			echo 0;
        }  */
    } 

?>