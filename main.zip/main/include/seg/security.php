<?php
session_start();
//COMPRUEBA QUE EL USUARIO ESTA AUTENTIFICADO
if ($_SESSION["autenticado"] != "SI") {
//si no existe, envio a la p�gina de autentificacion
header("Location: /main/erroracceso.html");
//ademas salgo de este script
exit();
}
?>