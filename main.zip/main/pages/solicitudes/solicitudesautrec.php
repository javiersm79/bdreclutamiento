<?php
//include ("include/seg/security.php");
?>


<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html>
  <head>
    <meta charset="UTF-8">
    <title>Buscar Candidatos</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
	<!-- Dialogos -->
	<link rel="stylesheet" href="../../include/css/jquery-ui-smoothness.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- Ionicons ******** Utilizar en el futuro para cargar iconos locales*************
   <link rel="stylesheet" href="include/themes/ionicons/css/ionicons.min.css">-->
	    <!-- DataTables -->
    <link rel="stylesheet" href="../../plugins/datatables/dataTables.bootstrap.css">
    <link rel="stylesheet" href="../../plugins/datatables/extensions/Buttons/css/buttons.dataTables.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. We have chosen the skin-blue for this starter
          page. However, you can choose any other skin. Make sure you
          apply the skin class to the body tag so the changes take effect.
    -->
    <link rel="stylesheet" href="../../dist/css/skins/skin-blue.min.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <!--
  BODY TAG OPTIONS:
  =================
  Apply one or more of the following classes to get the
  desired effect
  |---------------------------------------------------------|
  | SKINS         | skin-blue                               |
  |               | skin-black                              |
  |               | skin-purple                             |
  |               | skin-yellow                             |
  |               | skin-red                                |
  |               | skin-green                              |
  |---------------------------------------------------------|
  |LAYOUT OPTIONS | fixed                                   |
  |               | layout-boxed                            |
  |               | layout-top-nav                          |
  |               | sidebar-collapse                        |
  |               | sidebar-mini                            |
  |---------------------------------------------------------|
  -->
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">

      <!-- Main Header -->
      <header class="main-header">

        <!-- Logo -->
        <a href="index2.html" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels 
          <span class="logo-mini"><b>A</b>LT</span>-->
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><b>Suplencias</b>UDO</span>
        </a>

        <!-- Header Navbar -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
		  
          <!-- Navbar Right Menu -->
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
             
             <!-- Salir del sistema -->
              <li>
                <a href="#" onclick="cerrarSesion();"><i class="fa fa-sign-out"></i>&nbsp;Cerrar Sesi&oacute;n</a>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">

        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">

          <!-- Sidebar user panel (optional) -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="../../include/img/logo_udo_min.jpg" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
              <p><?php //echo $_SESSION['nombre']; ?>Juan Torres</p>
              <!-- Status 
              <a href="#"><i class="fa fa-circle text-success"></i> Delegado</a>-->
			 <center id="id_rol"><?php //echo $_SESSION['tipousuario']; ?> Analista<center/>
            </div>
          </div>

          <!-- search form (Optional)
          <form action="#" method="get" class="sidebar-form">
            <div class="input-group">
              <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i></button>
              </span>
            </div>
          </form> -->
          <!-- /.search form -->

			<div id="menu"><!-- Menu de navegacion --></div>
        </section>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
       <div class="content-wrapper" style="max-height: 1000px">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Usuarios del Sistema
            <small>Usuarios del Sistema de Suplencias UDO</small>
          </h1>

        </section>

        <!-- Main content -->
        <section class="content" >
		
			<div id="botonera" style="right: 10px; position: absolute;">			
				<div class="btn-group">
				<button class="btn btn-block btn-primary" style="width: 100px" onclick="$('#campana').html('3');">Imprimir</button>
				</div>
				<div class="btn-group">
				<button id="msgdialog"class="btn btn-block btn-danger" style="width: 100px; " onclick="$('#dialogo').dialog('open');">Dialogo</button>
				</div>
				<div class="btn-group">
				<button id="reportebut"class="btn btn-block btn-warning" style="width: 100px; " onclick="window.open('reporte.php','_blank');">Reporte</button>
				</div>
				<div class="btn-group">
				<!-- <button id="excelBut"class="btn btn-block btn-success" style="width: 100px; " onclick="window.open('tablepg2.php','_blank');">Excel</button>
				-->
				<button id="excelBut" class="btn btn-block btn-success" style="width: 100px; ">Excel</button>
				</div>
			</div><br/><br/>
          <!-- Your Page Content Here -->
		<!-- JJPage -->
			<div class="box">
				<div class="box-header">
				  <h3 class="box-title"></h3>
				</div><!-- /.box-header -->
				<div class="box-body">
					<?php
					$dbconn = pg_connect( "user=pgsuplencia ".
													"password=pgsuplencia ".
													"host=190.168.128.109 ".
													"dbname=suplenciadev"
												  ) or die( "Error al conectar: ".pg_last_error() );



						
					$query = 'SELECT * FROM persona;';
					$result = pg_query($query) or die('Query failed: ' . pg_last_error());
					$nucleos = array("Anzoategui","Sucre","Monagas","Bolivar","Nva. Esparta");
					$rows = pg_numrows($result);
					//echo "<h1>cantidad de rows $rows </h1>"; 

					//echo "<table id='tabladyn' class='display' cellspacing='0' width='100%'>\n";
					echo "<table id='tabladyn' class='table table-bordered table-striped table-hover'>\n";
					echo "<thead>";
					echo "<th>Nucleo</th><th>Nº Ofic RC</th><th>CI Emp</th><th>Nombre EMP</th><th>CI Sup</th><th>Nombre Sup</th><th>Fecha</th><th>Ficha</th>";
					echo "</thead>";
					//mostrar los datos
					echo "<tbody>";
					for($i=1;$i<=$rows; $i++){
					$line = pg_fetch_array($result, null, PGSQL_ASSOC);
					$n=rand(0,4);
					echo "\t<tr>\n";
					echo "\t\t<td>$nucleos[$n]</td>\n";
					echo "\t\t<td>".rand()."</td>\n";
					echo "\t\t<td>".rand(5000000,25000000)."</td>\n";
					echo "\t\t<td>$line[nombres] $line[apellidos]</td>\n";					
					echo "\t\t<td>".rand(5000000,25000000)."</td>\n";
					echo "\t\t<td>$line[nombres] $line[apellidos]</td>\n";									
					echo "\t\t<td>".gmdate('d-m-Y', rand(998548548,1398548548))."</td>\n";
					echo "\t\t<td><button class='btn btn-block btn-info btn-xs' onclick='window.location.href = \"fichaSolicitudOper.php\"'>Ver</button></td>\n";
					
					echo "\t</tr>\n";
					}
					echo "</tbody>";
					echo "</table>\n";
					// Free resultset
					pg_free_result($result);
					// Closing connection
					pg_close($dbconn);
					?>		
					


					
				</div><!-- /.box-body -->		
			</div><!-- /.box -->	
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
					<div id="dialogo" title="Basic dialog">I'm in a dialog!</div>
      <!-- Main Footer -->
      <footer class="main-footer">
        <!-- To the right -->
        <div class="pull-right hidden-xs">
          Web Master - Lcdo. Javier Salazar
        </div>
        <!-- Default to the left -->
        <strong>Copyright &copy; 2015 <a href="#">Universidad de Oriente</a>.</strong> Todos los Derechos Reservados.
      </footer>

      
    </div><!-- ./wrapper -->

<!-- REQUIRED JS SCRIPTS -->

<!-- jQuery 2.1.4 -->
<script src="../../plugins/jQuery/jQuery-2.1.4.min.js"></script>
<!-- Bootstrap 3.3.5 -->
<script src="../../bootstrap/js/bootstrap.min.js"></script>
<!-- JS UI -->	
<script src="../../include/js/ui.js"></script>
<!-- DataTables -->
<script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
<script src="../../plugins/datatables/dataTables.bootstrap.min.js"></script>
<script src="../../plugins/datatables/TableTools.min.js"></script>
<script src="../../plugins/datatables/jquery.battatech.excelexport.js"></script>
<script src="../../plugins/jQueryUI/jquery-ui.min.js"></script>

<!-- fancybox iframe -->
<script src="../../plugins/fancybox/jquery.fancybox.js?v=2.1.5"></script>
<!-- SlimScroll -->
<script src="../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="../../plugins/fastclick/fastclick.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/app.min.js"></script>
<!-- InputMask -->
<script src="../../plugins/input-mask/jquery.inputmask.js"></script>
<script src="../../plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="../../plugins/input-mask/jquery.inputmask.extensions.js"></script>
<!-- Suplentes -->

<!-- UI Custom -->
<script src="../../include/js/ui.js"></script>

 <script type="text/javascript">
//····················Datatables························	 
    $(document).ready(function() {
        $('#tabladyn').dataTable( {
            "language": {"url": "../../plugins/datatables/dataTableSpanish.json"},
			 "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "Todos"]],
			 "columnDefs": [
				//{ "visible": false, "targets": 0 }
			  ]
        } );
    } );
	
	//Obtiene el valor de una columna segun la fila seleccionada
/* $('tr').each(function() {
    $(this).click(function() {
        var selectedTd = $(this).children('td:nth-child(0)').text();
		alert(selectedTd);
    });
});*/
//····················Dialogo························	
$( "#dialogo" ).dialog({
  autoOpen: false,
  closeText: ""
} );
//····················Excel Export························
$("#excelBut").click(function () {
    tableToExcel('tabladyn', 'Usuarios');
});
 

var tableToExcel = (function () {
    var uri = 'data:application/vnd.ms-excel;base64,'
      , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
      , base64 = function (s) { return window.btoa(unescape(encodeURIComponent(s))) }
      , format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) }
    return function (table, name) {
        if (!table.nodeType) table = document.getElementById(table)
        var ctx = { worksheet: name || 'Worksheet', table: table.innerHTML }
        window.location.href = uri + base64(format(template, ctx))
    }
})()
cargarmenu(0);
</script>	


 
    <!-- Optionally, you can add Slimscroll and FastClick plugins.
         Both of these plugins are recommended to enhance the
         user experience. Slimscroll is required when using the
         fixed layout. -->
  </body>
</html>
