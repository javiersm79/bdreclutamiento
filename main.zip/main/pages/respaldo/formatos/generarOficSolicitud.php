<?php
//include ("../../include/seg/security.php");
?>

<html>
	<head>
		<meta charset="UTF-8">
		<title>Generar Solicitud</title>
		<!-- Tell the browser to be responsive to screen width -->
		<meta>
		<!-- Bootstrap 3.3.5 -->
		<link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
		<!-- jquery-ui -->
		<link rel="stylesheet" href="../../include/css/jquery-ui-smoothness.css">
		<!-- Font Awesome -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
		<!-- Ionicons ******** Utilizar en el futuro para cargar iconos locales*************
		<link rel="stylesheet" href="include/themes/ionicons/css/ionicons.min.css">-->

		<!-- fancybox iframe -->
		<link rel="stylesheet" href="../../plugins/fancybox/jquery.fancybox.css?v=2.1.5" media="screen">
		<!-- Theme style -->
		<link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">
		<!-- AdminLTE Skins. We have chosen the skin-blue for this starter
		page. However, you can choose any other skin. Make sure you
		apply the skin class to the body tag so the changes take effect.
		-->
		<link rel="stylesheet" href="../../dist/css/skins/skin-blue.min.css">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

	</head>

	<body class="skin-blue sidebar-mini">
		<div class="wrapper" >

			<!-- Main Header -->
			<header class="main-header">

				<!-- Logo -->
				<a href="index2.html" class="logo"> <!-- mini logo for sidebar mini 50x50 pixels
				<span class="logo-mini"><b>A</b>LT</span>--> <!-- logo for regular state and mobile devices --> <span class="logo-lg"><b>Suplencias</b>UDO</span> </a>

				<!-- Header Navbar -->
				<nav class="navbar navbar-static-top" role="navigation">
					<!-- Sidebar toggle button-->
					<a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button"> <span class="sr-only">Toggle navigation</span> </a>

					<!-- Navbar Right Menu -->
					<div class="navbar-custom-menu">
						<ul class="nav navbar-nav">

							<!-- Salir del sistema -->
							<li>
								<a href="#" ><i class="fa fa-sign-out"></i>&nbsp;Cerrar Sesi&oacute;n</a>
							</li>
						</ul>
					</div>
				</nav>
			</header>
			<!-- Left side column. contains the logo and sidebar -->
			<aside class="main-sidebar">

				<!-- sidebar: style can be found in sidebar.less -->
				<section class="sidebar">

					<!-- Sidebar user panel (optional) -->
					<div class="user-panel">
						<div class="pull-left image">
							<img src="../../include/img/logo_udo_min.jpg" class="img-circle" alt="User Image">
						</div>
						<div class="pull-left info">
							<p>
								Alexander Pierce
							</p>
							<!-- Status
							<a href="#"><i class="fa fa-circle text-success"></i> Delegado</a>-->
							<center id="id_rol">
								Delegado
							<center/>
						</div>
					</div>

					<!-- search form (Optional)
					<form action="#" method="get" class="sidebar-form">
					<div class="input-group">
					<input type="text" name="q" class="form-control" placeholder="Search...">
					<span class="input-group-btn">
					<button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i></button>
					</span>
					</div>
					</form> -->
					<!-- /.search form -->
					<div id="menu"><!-- Menu de navegacion --></div>
					
				</section>
				<!-- /.sidebar -->
			</aside>

			<!-- Content Wrapper. Contains page content -->
			<div class="content-wrapper" style="max-height: 1000px">
				<!-- Content Header (Page header) -->
				<section class="content-header">
					<h1>Generar Oficio de Solicitud<small>&nbsp;&nbsp;Generar Oficio de Solicitud de Autorizaci&oacute;n</small></h1>

				</section>

				<!-- Main content -->
				<section class="content" >

					<div id="botoneraHeader" style="right: 15px; position: absolute;">

					</div>

					<div class="box">

						<div class="box-body">
							<!-- Horizontal Form --> 
							<div class="box box-info">
							<div class="box-header with-border">
							Ingresar el datos
							</div><!-- fin header -->
							</div><!-- /.box info-->
							<form class="form-horizontal" action="OficSolicitud.php" method="get">
								<!-- Nucleo -->
								 <div class="form-group" id="grupoNucleo">
									<label for="nucleo" class="col-sm-2 control-label">N&uacute;cleo</label>
									<div class="col-sm-2">
										
										<select id="nucleo" name="nucleo" class="form-control" required>
										<option>Anzoategui</option>
										<option>Bol&iacute;var</option>
										<option>Monagas</option>
										<option>Nva. Esparta</option>
										<option>Rectorado</option>
										<option>Sucre</option>
										</select>
										
									</div>
								</div>											

								<!-- Nº Oficio -->
								<div class="form-group">
									<label for="numOficio" class="col-sm-2 control-label">Nº de Oficio</label>
									<div class="col-sm-4">
										<div class="input-group">
											<input type="text" class="form-control" id="numOficio" name="numOficio" placeholder="Ej: 1234566" required />
											<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-font"></i></span>
										</div>									  

									</div>						  
								</div>								
								
								<!-- Boton generar -->
								<div class="form-group">
									<label for="btnGenerar" class="col-sm-2 control-label"></label>
									<div class="col-sm-4">
									<button type="submit" class="btn btn-success">Generar</button>
									</div>						  
								</div>
								
							</form>

						</div><!-- /.box-body -->

						<div class="box-footer">

							<!-- <button type="submit" class="btn btn-info pull-right">Sign in</button> -->

						</div><!-- /.box-footer -->

					</div><!-- /.box -->

				</section><!-- /.content -->
			</div><!-- /.content-wrapper -->

			<!-- Main Footer -->
			<footer class="main-footer">
				<!-- To the right -->
				<div class="pull-right hidden-xs">
					Web Master - Lcdo. Javier Salazar Marcano
				</div>
				<!-- Default to the left -->
				<strong>Copyright &copy; 2015 <a href="#">Universidad de Oriente</a>.</strong> Todos los Derechos Reservados.
			</footer>

		</div><!-- ./wrapper -->

		<!-- Cuadros de dialogos -->
		<div id="dialogo" title="Aviso"></div>
		<div id="resultado" title="Personal de Suplencia Registrado"></div>

		<!-- REQUIRED JS SCRIPTS -->

		<!-- jQuery 2.1.4 -->
		<script src="../../plugins/jQuery/jQuery-2.1.4.min.js"></script>
		<!-- Bootstrap 3.3.5 -->
		<script src="../../bootstrap/js/bootstrap.min.js"></script>
		<!-- JS Javier -->
		<script src="../../include/js/ui.js"></script>
		<!-- DataTables -->
		<script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
		<script src="../../plugins/datatables/dataTables.bootstrap.min.js"></script>
		<script src="../../plugins/datatables/TableTools.min.js"></script>
		<script src="../../plugins/datatables/jquery.battatech.excelexport.js"></script>
		<script src="../../plugins/jQueryUI/jquery-ui.min.js"></script>

		<!-- fancybox iframe -->
		<script src="../../plugins/fancybox/jquery.fancybox.js?v=2.1.5"></script>
		<!-- SlimScroll -->
		<script src="../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
		<!-- FastClick -->
		<script src="../../plugins/fastclick/fastclick.min.js"></script>
		<!-- AdminLTE App -->
		<script src="../../dist/js/app.min.js"></script>
		<!-- InputMask -->
		<script src="../../plugins/input-mask/jquery.inputmask.js"></script>
		<script src="../../plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
		<script src="../../plugins/input-mask/jquery.inputmask.extensions.js"></script>
		<!-- Suplentes -->
		<script src="js/suplentes.js"></script>
		<!-- UI Custom -->
		<script src="../../include/js/ui.js"></script>

<script type="text/javascript">
//····················inputmask (Mascaras como tlfn)························
$("[data-mask]").inputmask();
//···················· Disble click on tabs ························
/* $('a[data-toggle="tab"]').on('click', function(){
	if ($(this).parent('li').hasClass('disabled')) {
	return false;
	};
});
 */
//····················Dialogo························
$("#dialogo").dialog({
	autoOpen : false,
	closeText : ""
});

$("#tabSoportes").tooltip({
	content : "<div class='ui-state-highlight ui-corner-all' style='padding: 0 .7em;'><p><span class='ui-icon ui-icon-info' style='float: left; margin-right: .3em; margin-top: .2em;'></span>Aviso! Debe<strong style='color:red'> guardar</strong> primero los datos del candidato.</p></div>"
});
cargarmenu(0);
</script>

		<!-- Optionally, you can add Slimscroll and FastClick plugins.
		Both of these plugins are recommended to enhance the
		user experience. Slimscroll is required when using the
		fixed layout. -->
	</body>
</html>
