<?php
//include ("../../include/seg/security.php");
?>


<html>
  <head>
    <meta charset="UTF-8">
    <title>Solicitar Suplencia</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
   <!-- daterange picker -->
    <link rel="stylesheet" href="../../plugins/daterangepicker/daterangepicker-bs3.css">
	<!-- Dialogos -->
	<link rel="stylesheet" href="../../include/css/jquery-ui-smoothness.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- Ionicons ******** Utilizar en el futuro para cargar iconos locales*************
   <link rel="stylesheet" href="include/themes/ionicons/css/ionicons.min.css">-->
	    <!-- DataTables -->
    <link rel="stylesheet" href="../../plugins/datatables/dataTables.bootstrap.css">
	<!-- fancybox iframe -->
	<link rel="stylesheet" href="../../plugins/fancybox/jquery.fancybox.css?v=2.1.5" media="screen">

    <!-- daterange picker -->

    <!-- Theme style -->
    <link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. We have chosen the skin-blue for this starter
          page. However, you can choose any other skin. Make sure you
          apply the skin class to the body tag so the changes take effect.
    -->
    <link rel="stylesheet" href="../../dist/css/skins/skin-blue.min.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body class="skin-blue sidebar-mini">
    <div class="wrapper">

      <!-- Main Header -->
      <header class="main-header">

        <!-- Logo -->
        <a href="index2.html" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels 
          <span class="logo-mini"><b>A</b>LT</span>-->
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><b>Suplencias</b>UDO</span>
        </a>

        <!-- Header Navbar -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
		  
          <!-- Navbar Right Menu -->
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
             
             <!-- Salir del sistema -->
              <li>
                <a href="#" ><i class="fa fa-sign-out"></i>&nbsp;Cerrar Sesi&oacute;n</a>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">

        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">

          <!-- Sidebar user panel (optional) -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="../../include/img/logo_udo_min.jpg" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
              <p>Juan Martinez</p>
              <!-- Status 
              <a href="#"><i class="fa fa-circle text-success"></i> Delegado</a>-->
			 <center id="id_rol">Delegado<center/>
            </div>
          </div>

          <!-- search form (Optional)
          <form action="#" method="get" class="sidebar-form">
            <div class="input-group">
              <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i></button>
              </span>
            </div>
          </form> -->
          <!-- /.search form -->

		<div id="menu"><!-- Menu de navegacion --></div>
        </section>
        <!-- /.sidebar -->
      </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Formulario de Solicitud de Suplencias
            <small>Favor ingresar todos los datos</small>
          </h1>

        </section>

        <!-- Main content -->
        <section class="content" >
			
<!-- 			<div id="botoneraHeader" style="right: 15px; position: absolute;">


			</div><br/><br/> -->

			<div class="box">

				<div class="box-body">

					
					<!-- Horizontal Form 
					<div class="box box-info">
						<div class="box-header with-border">
							<h3>Ingresar datos del suplente</h3>
						</div><!-- fin header 
					</div><!-- /.box info-->	
						<div class="nav-tabs-custom" id="solicitudTabs">
							<ul class="nav nav-tabs">
							<li class="active"><a data-toggle="tab" href="#funcionario">Datos del Funcionario</a></li>
							<li ><a data-toggle="tab" href="#datos">Suplente</a></li>
							<li><a data-toggle="tab" href="#datosPeriodo">Per&iacute;odo de Suplencia</a></li>
							<li><a data-toggle="tab" href="#pagos">C&aacute;lculo de Pagos</a></li>
							
							<button id="" class="btn btn-block bg-gray disabled color-palette pull-right" style="width: 100px; margin-right:20px">Guardar</button>
							</ul>
						</div>
							<div class="tab-content">

								<!-- tab "Datos del Funcionario" -->
								<div id="funcionario" class="tab-pane fade in active">
								<br/>
									<div class="box-body">
										<!-- form start -->
										<form class="form-horizontal">
											<!-- Tipo de permiso de la suplencia -->
											<div class="form-group">

												<label for="tipoPermiso" class="col-sm-2 control-label">Tipo de permiso</label>
												<div class="col-sm-2">												
													<select id="tipopersonal" class="form-control">
														<option>M&eacute;dico</option>
														<option>Vacaciones</option>
														<option>Pre/Post Natal</option>
														<option>Otros</option>
													</select>
												</div>	
											</div>
											
											<!-- Tipo de personal -->
											<div class="form-group">
												<label for="tipopersonal" class="col-sm-2 control-label">Tipo de personal</label>
												<div class="col-sm-2">
													
													<select id="tipopersonal" class="form-control">
														<option>Docente</option>
														<option>Obrero</option>
														<option>Administrativo</option>
													</select>
													
												</div>
											</div>
											
											<!-- Nucleo -->
											 <div class="form-group" id="grupoNucleo">
												<label for="nucleo" class="col-sm-2 control-label">N&uacute;cleo</label>
												<div class="col-sm-2">
													
													<select id="nucleo" class="form-control">
													<option>Anzoategui</option>
													<option>Bol&iacute;var</option>
													<option>Monagas</option>
													<option>Nva. Esparta</option>
													<option>Rectorado</option>
													<option>Sucre</option>
													</select>
													
												</div>
											</div>											

											<!-- Depencdencia del Funcionario -->
											<div class="form-group">
												<label for="nombreFuncionario" class="col-sm-2 control-label">Dependencia</label>
												<div class="col-sm-4">
													<div class="input-group">
														<input type="text" class="form-control" id="dependFuncionario" name="dependFuncionario" placeholder="Ej: Control de Estudios" required />
														<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-font"></i></span>
													</div>									  

												</div>						  
											</div>
											
											<!-- Nombre del Funcionario -->
											<div class="form-group">
												<label for="nombreFuncionario" class="col-sm-2 control-label">Nombre del Funcionario</label>
												<div class="col-sm-4">
													<div class="input-group">
														<input type="text" class="form-control" id="nombreFuncionario" name="nombreFuncionario" placeholder="Ej: Francisco Martinez" required />
														<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-font"></i></span>
													</div>									  

												</div>						  
											</div>											
					
											<!-- Cedula del Suplente -->
											<div class="form-group">

													<label for="cedula" class="col-sm-2 control-label">C&eacute;dula</label>
												<div class="col-sm-4">													
													<div class="input-group">
														<input type="text" class="form-control" id="cedulasuplente" name="cedulasuplente" placeholder="Ej: 12345678" required>
														<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-sort-numeric-asc"></i></big></span>
													</div>
												</div>	
											</div>											
																		

											<!-- Cargo  -->
											<div class="form-group">
												<label for="cargoOrigSup" class="col-sm-2 control-label">Cargo</label>
												<div class="col-sm-4">													
													<div class="input-group">
														<input type="text" class="form-control" id="cargoFuncionario" placeholder="Ej: Asistente administrativo" required>
														<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-font"></i></span>
													</div>	
												</div>						  
											</div>

											
											

										</form>	
									</div><!-- /.box-body -->
									<div class="box-footer">
										<div id="botoneraFooter">
											<div class="btn-group">
											<!-- <button id="excelBut"class="btn btn-block btn-success" style="width: 100px; " onclick="window.open('tablepg2.php','_blank');">Excel</button>
											-->
											<button id="enviarbut" class="btn btn-block btn-success" style="width: 100px;">Guardar</button>
											</div>						

										</div>
										<!-- <button type="submit" class="btn btn-info pull-right">Sign in</button> -->

									</div><!-- /.box-footer -->

								</div><!-- Fin del tab "Datos del Funcionario" -->
							
								<div id="datos" class="tab-pane fade">
									<br/>
									<div class="box-body">
										<!-- form start -->
										<form class="form-horizontal">


											<!-- Datos del Suplente -->
											<div class="form-group" id="grupoDatosSup">
												<label for="nombres" class="col-sm-2 control-label">Suplente</label>
												<div class="col-sm-4">
													<input type="text" class="form-control" id="nombresuplente" placeholder="Datos del Suplente" title="" required>							
													<input type="hidden" class="form-control" id="idsuplente">
												</div>						  
											  <div class="col-sm-1">
												<a class="selecPersona fancybox.iframe" id="buscarpersona" href="../comunes/buscar.php"><img src="../../include/img/buscar.png"/></a>
											  </div>
											</div>
											
											<!-- Cumple con el Manual de Cargos OPSU -->
											<div class="form-group">
												<label for="cargoOPSU" class="col-sm-2 control-label">Cumple el suplente con el manual de cargos OPSU</label>
												<div class="col-sm-4">
													<div class="radio">
														<label>
														  <input name="optionsRadios" id="optionsRadios1" value="si" checked="" type="radio">
														  Si cumple
														</label>
													</div>
													<div class="radio">
														<label>
														  <input name="optionsRadios" id="optionsRadios2" value="no" type="radio">
														  No cumple
														</label>
													</div>
												</div>	
											</div>	
											
											
										</form>
										<div id="msgDatosSup"></div>
									</div><!-- /.box-body -->
									
									<div class="box-footer">
										<div id="botoneraFooter">
											<div class="btn-group">
											<!-- <button id="excelBut"class="btn btn-block btn-success" style="width: 100px; " onclick="window.open('tablepg2.php','_blank');">Excel</button>
											-->
											<button id="guardarSup" class="btn btn-block btn-success" style="width: 100px; ">Guardar</button>
											</div>						

										</div>
										<!-- <button type="submit" class="btn btn-info pull-right">Sign in</button> -->

									</div><!-- /.box-footer -->
								</div><!-- Fin del tab "DATOS" -->
								
								<!-- tab "Período Suplencia" -->
								<div id="datosPeriodo" class="tab-pane fade">
																		<br/>
									<!-- form start -->
									<form class="form-horizontal">
										<div class="box-body">

											<!-- Observaciones -->
											<div class="form-group">
												<label for="observaciones" class="col-sm-2 control-label">Observaciones</label>
												<div class="col-sm-4">
													<div class="input-group">
														<input type="text" class="form-control" id="observaciones">
														<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-font"></i></span>
													</div>													
												</div>						  
											</div>
											
											<!-- Fecha rango  de la suplencia -->
											<div class="form-group">
												<label for="fechaIniSup" class="col-sm-2 control-label">Fecha de Inicio/Fin de la Suplencia</label>
												<div class="col-sm-4">
													<div class="input-group">
														<div class="input-group-addon">
															<i class="fa fa-calendar"></i>
														</div>
														<div id="rango">
															<div class="input-daterange input-group" id="datepicker">
																<input type="text" class="form-control" id="finicio" />
																<span class="input-group-addon">-</span>
																<input type="text" class="form-control" id="ffin" />
															</div>															
														</div>

													</div><!-- /.input group -->
												</div>

												<!--<div class="col-sm-6">
													<div class="input-group">
														<input type="text" class="form-control" id="ndiasSup" disabled="true" style="width: 500px"/>
													</div>
												</div>	 /.input group -->
											</div>
											
											<!-- Tiempo de la suplencia -->
											<!-- <div class="form-group">

												<label for="tiempoSup" class="col-sm-2 control-label">Tiempo del permiso</label>
												<div class="col-sm-4">												
														<div class="input-daterange input-group" id="datepicker">
															<input type="text" class="form-control" id="tiempoSup" style="width: 80px" placeholder="Ej: 15" required>
															<span class="input-group-addon"></span>
															<select id="tipopersonal" class="form-control">
																<option>D&iacute;as</option>
																<option>Meses</option>
																<option>A&ntilde;os</option>
															</select>
														</div>
												</div>	
											</div> -->

											<!-- Dias efectivos de la suplencia -->
											<div class="form-group">
												<label for="diasEfectivos" class="col-sm-2 control-label">D&iacute;as efectivos de la Suplencia</label>
												<div class="col-sm-2">
													<div class="input-group">
														<input type="text" class="form-control entero" id="diasEfectivos" required>
														<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-sort-numeric-asc"></i></span>
													</div>													
												</div>
											</div>

												
										</div><!-- /.box-body -->
										<div class="box-footer">
											<div id="botoneraFooter">
												<div class="btn-group">
												<!-- <button id="excelBut"class="btn btn-block btn-success" style="width: 100px; " onclick="window.open('tablepg2.php','_blank');">Excel</button>
												-->
												<button id="enviarbut" class="btn btn-block btn-success" style="width: 100px;">Guardar</button>
												</div>						

											</div>
											<!-- <button type="submit" class="btn btn-info pull-right">Sign in</button> -->

										</div><!-- /.box-footer -->
									</form>
								</div><!-- Fin del tab "Calculos de pago" -->
								
								<!-- tab "Calculos de pago" -->
								<div id="pagos" class="tab-pane fade">
								<br/>
									<div class="box-body">
										<!-- form start -->
										<form class="form-horizontal">
											<!-- Monto Total del sueldo -->
											<div class="form-group">
												<label for="montoTotalSueldo" class="col-sm-2 control-label">Monto Total del Sueldo</label>
												<div class="col-sm-4">
													<div class="input-group">
														<input type="text" class="form-control decimal" id="montoTotalSueldo" placeholder="Ej: 25.000,00">
														<span class="input-group-addon" style="background: #f0f0f0"><b>BsF.</b></span>
													</div>
												</div>						  
											</div>

											<!-- Monto Total del sueldo -->
											<div class="form-group">
												<label for="montoTotalBonoAlim" class="col-sm-2 control-label">Monto Total del Bono de alimentci&oacute;n</label>
												<div class="col-sm-4">
													<div class="input-group">
														<input type="text" class="form-control decimal" id="montoTotalBonoAlim" placeholder="Ej: 25.000,00">
														<span class="input-group-addon" style="background: #f0f0f0"><b>BsF.</b></span>
													</div>													
												</div>						  
											</div>

											<!-- Hoja de Calculo del Sueldo -->
											<div class="form-group">
												<label for="xlsxSueldo" class="col-sm-2 control-label">Hoja de C&aacute;lculo del Sueldo</label>
												<div class="col-sm-4">													
														<input name="xlsxSueldo" type="file" >
														<p class="help-block">Formato: .xls o .xlsx - tama&ntilde;o m&aacute;ximo: 2Mb</p>
														<div class="progress">
															<div id="progXlsxSueldo" class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div>
														</div>	
														<input type="button" value="Cargar" id="btnXlsxSueldo"/>
												</div>					  
											</div>
											
											<!-- Nombres del Analista -->
											<div class="form-group">
											  <label for="nombreAnalista" class="col-sm-2 control-label">Nombres y Apellidos del Anal&iacute;sta</label>
											  <div class="col-sm-4">
													<div class="input-group">
														<input type="text" class="form-control" id="nombreAnalista" name="nombreAnalista" placeholder="Nombres del Ana&iacute;sta" required />
														<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-font"></i></span>
													</div>
												
											  </div>						  
											</div>
											
											<!-- Email del Analista -->
											<div class="form-group">
											  <label for="emailAnalista" class="col-sm-2 control-label">Email del Anal&iacute;sta</label>
											  <div class="col-sm-4">
													<div class="input-group">
														<input class="form-control" id="emailAnalista" name="emailAnalista" placeholder="Ej: analista@udo.edu.ve" />
														<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-envelope-o"></i></span>
													</div>						  
											  </div>						  
											</div>
										
											<!-- Telf Principal del Suplente -->
											<div class="form-group">
												<label for="telefono1" class="col-sm-2 control-label">Telf. Principal</label>
												<div class="col-sm-4" >
													<div class="input-group">
														<input type="text" id="telefono1" name="telefono1" class="form-control" data-inputmask='"mask": "(9999) 999-9999"' data-mask>
														<span class="input-group-addon" style="background: #f0f0f0">☎</span>
													</div>											
												</div>						  							
											</div>											
										</form>			
									</div><!-- /.box-body -->
									<div class="box-footer">
										<div id="botoneraFooter">
											<div class="btn-group">
											<!-- <button id="excelBut"class="btn btn-block btn-success" style="width: 100px; " onclick="window.open('tablepg2.php','_blank');">Excel</button>
											-->
											<button id="enviarbut" class="btn btn-block btn-success" style="width: 100px;">Guardar</button>
											</div>						

										</div>
										<!-- <button type="submit" class="btn btn-info pull-right">Sign in</button> -->

									</div><!-- /.box-footer -->
									
								</div><!-- Fin del tab "Calculos de pago" -->


							</div><!-- /.tab-content -->
						
				</div><!-- /.box-body -->
					
				  				
						
			</div><!-- /.box -->	
        </section><!-- /.content -->
    </div><!-- /.content-wrapper -->

      <!-- Main Footer -->
      <footer class="main-footer">
        <!-- To the right -->
        <div class="pull-right hidden-xs">
          Web Master - Lcdo. Javier Salazar Marcano
        </div>
        <!-- Default to the left -->
        <strong>Copyright &copy; 2015 <a href="#">Universidad de Oriente</a>.</strong> Todos los Derechos Reservados.
      </footer>

      
    </div><!-- ./wrapper -->
	
	
	
	<!-- Cuadros de dialogos -->
	<div id="dialogo" title="Personal de Suplencia Registrado"></div>
	<div id="resultado" title="Personal de Suplencia Registrado"></div>
	
<!-- REQUIRED JS SCRIPTS -->

<!-- jQuery 2.1.4 -->
<script src="../../plugins/jQuery/jQuery-2.1.4.min.js"></script>
<!-- Bootstrap 3.3.5 -->
<script src="../../bootstrap/js/bootstrap.min.js"></script>
<!-- JS UI -->	
<script src="../../include/js/ui.js"></script>
<!-- DataTables -->
<script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
<script src="../../plugins/datatables/dataTables.bootstrap.min.js"></script>
<script src="../../plugins/datatables/TableTools.min.js"></script>
<script src="../../plugins/datatables/jquery.battatech.excelexport.js"></script>
<script src="../../plugins/jQueryUI/jquery-ui.min.js"></script>

<!-- fancybox iframe -->
<script src="../../plugins/fancybox/jquery.fancybox.js?v=2.1.5"></script>
<!-- SlimScroll -->
<script src="../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="../../plugins/fastclick/fastclick.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/app.min.js"></script>
<!-- InputMask -->
<script src="../../plugins/input-mask/jquery.inputmask.js"></script>
<script src="../../plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="../../plugins/input-mask/jquery.inputmask.extensions.js"></script>
<!-- Suplentes -->
<script src="js/suplentes.js"></script>

<!-- Numeros -->
<script src="jquery.number.js"></script>

    <!-- date-picker -->
<link rel="stylesheet" href="datepicker3.min.css" />
<script src="bootstrap-datepicker.js"></script>

 <script type="text/javascript">
 //····················inputmask························
$("[data-mask]").inputmask();
$('.decimal').number( true, 2 );
$('.entero').number( true, 0 );



$(document).ready(function() {
	
	$(".selecPersona").fancybox({
		maxWidth	: 1000,
		maxHeight	: 600,
		fitToView	: false,
		width		: '100%',
		height		: '80%',
		autoSize	: true,
		closeClick	: true,
		//Obtiene el valor de la ventana emergente
		beforeClose: function () {
 		    var idpersona=$(".fancybox-iframe").contents().find("#idpersona");
 		    var nombrepersona=$(".fancybox-iframe").contents().find("#nombrepersona");
			$("#nombresuplente").val(nombrepersona.val()); 
			$("#idsuplente").val(idpersona.val()); 
		}
	});

});

//····················Descativar ingreso de teclado en el campo datos del suplente························	
$("#nombresuplente").keydown(false);

$('#nombresuplente').bind('contextmenu', function(e) {
	// evito que se ejecute el evento click derecho
	e.preventDefault();
	// conjunto de acciones a realizar
});

//Date range picker $("#fechaIniSup").datepicker();


$('#rango .input-daterange').datepicker({
	 language: 'es',
	format: "dd/mm/yyyy",
	daysOfWeekDisabled: "0,6"

});

/* $('#rango .input-daterange').datepicker()
    .on('hide', function(e){

			$("#ndiasSup").val(restaFechas($("#finicio").val(),$("#ffin").val()));
    }); */
	

 //*****Evento click del boton
$(':button').click(function(){
	var valido =0;
	switch ($(this).attr('id')) {
		case 'guardarSup':
			//$("#nombresuplente").attr("title", "Seleecione un suplente");
			//$("#errorMsg").text(" Es Necesario selccionar un suplente");
			//$("#msgDatosSup").append("<div class='col-sm-6 alert alert-warning alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button> <strong>Warning!</strong> Better check yourself, you're not looking too good.</div>")
			//$('#solicitudTabs a[href="#pagos"]').hide();
			//$('#solicitudTabs a[href="#pagos"]').html("C&aacutelculo de Pagos <i class='fa fa-check' style='color: #00a65a'></i>");
			//$('#grupoNucleo label[for="nucleo"]').text("jj");
			validarCheck($('#solicitudTabs a[href="#pagos"]'));
			break;
			
		case 'guardarSup2':
			
			
			break;

			//Fin case 'guardarBut':
	} //FIN DEL SWITCH
	
	
    if (valido == 1)
	{

	}
/* 	$("#grupoDatosSup").removeClass("has-success")
    $("#grupoDatosSup").addClass("has-error") */
	
	
}); //*****Fin evento click del boton************************

//************************Evento Focus************************
$("#nombresuplente").focus(function() {
  //alert("");
  $("#grupoDatosSup").removeClass("has-error")
  $("#grupoDatosSup").addClass("has-success")
});
//************************Fin Evento Focus************************
//************************Funcion para clacular dias************************

			restaFechas = function(f1,f2)
			{
  			var aFecha1 = f1.split('/'); 
			var aFecha2 = f2.split('/'); 
			var fFecha1 = Date.UTC(aFecha1[2],aFecha1[1]-1,aFecha1[0]); 
			var fFecha2 = Date.UTC(aFecha2[2],aFecha2[1]-1,aFecha2[0]); 
			var dif = fFecha2 - fFecha1;
			var totaldias = Math.floor(dif / (1000 * 60 * 60 * 24));
			var meses;
			var anios;
			
			anios = parseInt(totaldias / 360);
			meses = parseInt((totaldias - anios*360)/30);
			dias = parseInt((totaldias - anios*360 - meses*30));
	
			return anios + " año(s) / " + meses + " mese(s) / " + dias + " dia(s)";
			}
//************************Fin de Funcion para calcular dias************************

//************************Funcion para validar guardados de tabs (forms)************************

			validarCheck = function(tab)
			{
			  $("#solicitarSuplencia").removeClass("active")
			  $("#solicitudGuardada").addClass("active")
			}
//************************Fin de Funcion para validar guardados de tabs (forms)************************

cargarmenu(0);
</script>	



  </body>
</html>
