<?php
//include ("../../include/seg/security.php");
?>

<html>
	<head>
		<meta charset="UTF-8">
		<title>Nuevo Suplente</title>
		<!-- Tell the browser to be responsive to screen width -->
		<meta>
		<!-- Bootstrap 3.3.5 -->
		<link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
		<!-- jquery-ui -->
		<link rel="stylesheet" href="../../include/css/jquery-ui-smoothness.css">
		<!-- Font Awesome -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
		<!-- Ionicons ******** Utilizar en el futuro para cargar iconos locales*************
		<link rel="stylesheet" href="include/themes/ionicons/css/ionicons.min.css">-->

		<!-- fancybox iframe -->
		<link rel="stylesheet" href="../../plugins/fancybox/jquery.fancybox.css?v=2.1.5" media="screen">
		<!-- Theme style -->
		<link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">
		<!-- AdminLTE Skins. We have chosen the skin-blue for this starter
		page. However, you can choose any other skin. Make sure you
		apply the skin class to the body tag so the changes take effect.
		-->
		<link rel="stylesheet" href="../../dist/css/skins/skin-blue.min.css">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

	</head>

	<body class="skin-blue sidebar-mini">
		<div class="wrapper" >

			<!-- Main Header -->
			<header class="main-header">

				<!-- Logo -->
				<a href="index2.html" class="logo"> <!-- mini logo for sidebar mini 50x50 pixels
				<span class="logo-mini"><b>A</b>LT</span>--> <!-- logo for regular state and mobile devices --> <span class="logo-lg"><b>Suplencias</b>UDO</span> </a>

				<!-- Header Navbar -->
				<nav class="navbar navbar-static-top" role="navigation">
					<!-- Sidebar toggle button-->
					<a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button"> <span class="sr-only">Toggle navigation</span> </a>

					<!-- Navbar Right Menu -->
					<div class="navbar-custom-menu">
						<ul class="nav navbar-nav">

							<!-- Salir del sistema -->
							<li>
								<a href="#" ><i class="fa fa-sign-out"></i>&nbsp;Cerrar Sesi&oacute;n</a>
							</li>
						</ul>
					</div>
				</nav>
			</header>
			<!-- Left side column. contains the logo and sidebar -->
			<aside class="main-sidebar">

				<!-- sidebar: style can be found in sidebar.less -->
				<section class="sidebar">

					<!-- Sidebar user panel (optional) -->
					<div class="user-panel">
						<div class="pull-left image">
							<img src="../../include/img/logo_udo_min.jpg" class="img-circle" alt="User Image">
						</div>
						<div class="pull-left info">
							<p>
								Alexander Pierce
							</p>
							<!-- Status
							<a href="#"><i class="fa fa-circle text-success"></i> Delegado</a>-->
							<center id="id_rol">
								Delegado
							<center/>
						</div>
					</div>

					<!-- search form (Optional)
					<form action="#" method="get" class="sidebar-form">
					<div class="input-group">
					<input type="text" name="q" class="form-control" placeholder="Search...">
					<span class="input-group-btn">
					<button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i></button>
					</span>
					</div>
					</form> -->
					<!-- /.search form -->
					<div id="menu"><!-- Menu de navegacion --></div>
					
				</section>
				<!-- /.sidebar -->
			</aside>

			<!-- Content Wrapper. Contains page content -->
			<div class="content-wrapper" style="max-height: 1000px">
				<!-- Content Header (Page header) -->
				<section class="content-header">
					<h1> Editar Suplente <small>Edición de datos de candidatos a suplentes</small></h1>

				</section>

				<!-- Main content -->
				<section class="content" >

					<div id="botoneraHeader" style="right: 15px; position: absolute;">

					</div>

					<div class="box">

						<div class="box-body">

							<!-- Horizontal Form
							<div class="box box-info">
							<div class="box-header with-border">
							<h3>Ingresar datos del suplente</h3>
							</div><!-- fin header
							</div><!-- /.box info-->
							<div class="nav-tabs-custom" id="nvoSupTabs">
								<ul class="nav nav-tabs">
									<li class="active" id="tabDatos">
										<a data-toggle="tab" href="#datos">Datos</a>
									</li>
									<li id="tabSoportes" title="">
										<a data-toggle="tab" href="#adjuntos">Soportes</a>
									</li>
									<div id="botonGuardar" style="float: right; display: none">
										<button id="btnEnviarSup" class="btn btn-block btn-success" style="width: 100px;">
											Crear
										</button>
									</div>
								</ul>
							</div>
							<div class="tab-content">
								<div id="datos" class="tab-pane fade in active">
									<br/>

									<!-- form start -->
									<form id="frmDatosSuplentes" class="form-horizontal">
										<!-- Profesion del Suplente -->
										<div class="form-group" id="grupoProfesion">
											<label for="profesion" class="col-sm-2 control-label">Profesi&oacute;n</label>
											<div class="col-sm-6">
												<div class="input-group">
													<input type="text" class="form-control" id="profesionsuplente" name="profesionsuplente" placeholder="Profesi&oacute;n del Suplente"/>
													<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-font"></i></span>
												</div>
											</div>
										</div>

										<!-- Nombres del Suplente -->
										<div class="form-group" id="grupoNombres">
											<label for="nombres" class="col-sm-2 control-label">Nombres</label>
											<div class="col-sm-6">
												<div class="input-group">
													<input type="text" class="form-control" id="nombresuplente" name="nombresuplente" placeholder="Nombres del Suplente" required />
													<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-font"></i></span>
												</div>
											</div>
										</div>

										<!-- Apellidos del Suplente -->
										<div class="form-group" id="grupoApellidos">
											<label for="apellidos" class="col-sm-2 control-label">Apellidos</label>
											<div class="col-sm-6">
												<div class="input-group">
													<input type="text" class="form-control" id="apellidossuplente" name="apellidossuplente" placeholder="Apellidos del Suplente" required />
													<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-font"></i></span>
												</div>

											</div>
										</div>

										<!-- Cedula del Suplente -->
										<div class="form-group" id="grupoCedula">
											<label for="cedula" class="col-sm-2 control-label">C&eacute;dula</label>
											<div class="col-sm-2" style="width: 110px">

												<select id="precedula" name="precedula" class="form-control">
													<option>V</option>
													<option>E</option>

												</select>

											</div>
											<div class="col-sm-2" style="width: 243px">

												<div class="input-group" id="grupoCedula">
													<input type="text" class="form-control numeric" id="cedulasuplente" name="cedulasuplente" placeholder="Ej: 12345678">
													<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-sort-numeric-asc"></i></big></span>
												</div>
											</div>
										</div>

										<!-- Email del Suplente -->
										<div class="form-group" id="grupoEmail">
											<label for="apellidos" class="col-sm-2 control-label">Email</label>
											<div class="col-sm-6">
												<div class="input-group">
													<input class="form-control" id="emailasuplente" name="emailasuplente" placeholder="Ej: suplente@udo.edu.ve" />
													<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-envelope-o"></i></span>
												</div>
											</div>
										</div>

										<!-- Telf Principal del Suplente -->
										<div class="form-group" id="grupoTlf1">
											<label for="telefono1" class="col-sm-2 control-label">Telf. Principal</label>
											<div class="col-sm-4" >
												<div class="input-group">
													<input type="text" id="telefono1" name="telefono1" class="form-control" data-inputmask='"mask": "(9999) 999-9999"' data-mask>
													<span class="input-group-addon" style="background: #f0f0f0">☎</span>
												</div>
											</div>
										</div>
										<!-- Telf Adicional del Suplente -->
										<div class="form-group" id="grupoTlf2">
											<label for="telefono2" class="col-sm-2 control-label">Telf. Seundario</label>
											<div class="col-sm-4" >
												<div class="input-group">
													<input type="text" id="telefono2" name="telefono2" class="form-control" data-inputmask='"mask": "(9999) 999-9999"' data-mask>
													<span class="input-group-addon" style="background: #f0f0f0">☎</span>
												</div>
											</div>
										</div>
									</form>

									<div class="box-footer">
										<div class="btn-group">
											<button id="btnGuardar"class="btn btn-block btn-primary" style="width: 100px;">
												Guardar
											</button>
											<div id="msgFooterDatos" style="position: absolute; left:110px; width: 700px; height: 10px">
											<!-- <button id="excelBut"class="btn btn-block btn-success" style="width: 100px; " onclick="window.open('tablepg2.php','_blank');">Excel</button>
											-->
											<!-- <button id="enviarBut" class="btn btn-block btn-danger" style="width: 100px; ">Enviar</button> -->
											</div>

										</div>

									</div><!-- /.box-footer -->

								</div><!-- Fin del tab "DATOS" -->

								<!-- tab "ADJUNTOS" -->
								<div id="adjuntos" class="tab-pane fade">
									<!-- <h3>Adjuntar documentaci&oacute;n</h3> -->
									<br/>

									<div class="box box-info">
										<div class="box-header with-border">
											<!-- Grupo Superior -->
											<div class="form-group">
												<!-- Foto Carnet -->
												<div class="col-sm-6">
													<label for="imgfoto" class="col-sm-2 control-label">Foto Carnet</label>
													<div class="col-sm-4">
														<form id="formFotoCarnet" class="form-horizontal">

															<input name="imgfoto" type="file" style="width: 350px">
															<p class="help-block">
																Formato: .jpg o .png - tama&ntilde;o m&aacute;ximo: 2Mb
															</p>
															<div class="progress">
																<div id="progFoto" class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div>
															</div>
															<input type="button" value="Cargar" id="btnImgFoto"/>
															<input type="button" value="Ver" id="btnVerImgFoto"/>
														</form>
													</div>
												</div>
												<!-- Fin de Foto Carnet -->											
												<!-- Cedula -->
												<div class="col-sm-6">
													<label for="cedula" class="col-sm-2 control-label">C&eacute;dula</label>
													<div class="col-sm-4">
														<form id="formcedula" class="form-horizontal">
															<input id="idCedula" name="idCedula" type="hidden" style="width: 350px" value="JJ">
															<input name="imgcedula" type="file" style="width: 450px">
															<p class="help-block" style="width: 350px">
																Formato: .jpg o .png - tama&ntilde;o m&aacute;ximo: 2Mb
															</p>
															<div class="progress">
																<div id="progcedula" class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuemin="0" aria-valuemax="100"></div>
															</div>
															<input type="button" value="Cargar" id="btnImgCed"/>
														</form>
													</div>
												</div>
												<!-- Fin de Cedula -->
											</div>
											<!-- /.form-group-superior -->											
											
											<h1>&nbsp;<hr></h1>
																					
											<!-- Grupo Middle -->
											<div class="form-group">
												<!-- Certificado de Salud -->
												<div class="col-sm-6">
													<label for="titulo" class="col-sm-2 control-label">Certificado de Salud</label>
													<div class="col-sm-4">
														<form id="formSalud" class="form-horizontal">

															<input name="imgSalud" type="file" style="width: 350px">
															<p class="help-block">
																Formato: .jpg o .png - tama&ntilde;o m&aacute;ximo: 2Mb
															</p>
															<div class="progress">
																<div id="progsalud" class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div>
															</div>
															<input type="button" value="Cargar" id="btnImgSalud"/>
														</form>
													</div>
												</div>
												<!-- Fin del Certificado de Salud -->

												<!-- Cta Bancaria -->
												<div class="col-sm-6">
													<label for="imgBanco" class="col-sm-2 control-label">Cta. Bancaria</label>
													<div class="col-sm-4">
														<form id="formBanco" class="form-horizontal">

															<input name="imgBanco" type="file" style="width: 350px">
															<p class="help-block">
																Formato: .pdf - tama&ntilde;o m&aacute;ximo: 2Mb
															</p>
															<div class="progress">
																<div id="progBanco" class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div>
															</div>
															<input type="button" value="Cargar" id="btnImgBco"/>
														</form>
													</div>
												</div>
												<!-- Fin del Curriculum -->
											</div>
											<!-- /.form-group-Middle -->
											<h1>&nbsp;<hr></h1>
											
											<!-- Grupo Inferior -->
											<div class="form-group">
												<!-- Titulo -->
												<div class="col-sm-6">
													<label for="titulo" class="col-sm-2 control-label">T&iacute;tulo (Fondo negro)</label>
													<div class="col-sm-4">
														<form id="formtitulo" class="form-horizontal">

															<input name="imgtitulo" type="file" style="width: 350px">
															<p class="help-block">
																Formato: .jpg o .png - tama&ntilde;o m&aacute;ximo: 2Mb
															</p>
															<div class="progress">
																<div id="progceula" class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div>
															</div>
															<input type="button" value="Cargar" id="btnImgTit"/>
														</form>
													</div>
												</div>
												<!-- Fin del Titulo -->

												<!-- Curriculum -->
												<div class="col-sm-6">
													<label for="pdfcurriculum" class="col-sm-2 control-label">Curriculum Vitae</label>
													<div class="col-sm-4">
														<form id="formcurriculum" class="form-horizontal">

															<input name="pdfcurriculum" type="file" style="width: 350px">
															<p class="help-block">
																Formato: .pdf - tama&ntilde;o m&aacute;ximo: 2Mb
															</p>
															<div class="progress">
																<div id="progceula" class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div>
															</div>
															<input type="button" value="Cargar" id="btnPdfCV"/>
														</form>
													</div>
												</div>
												<!-- Fin del Curriculum -->
											</div>
											<!-- /.form-group-inferior -->

										</div><!-- /.box-header-->
									</div><!-- /.box-info -->

								</div><!-- Fin del tab "Adjuntos" -->

							</div><!-- /.tab-content -->

						</div><!-- /.box-body -->

						<div class="box-footer">

							<!-- <button type="submit" class="btn btn-info pull-right">Sign in</button> -->

						</div><!-- /.box-footer -->

					</div><!-- /.box -->

				</section><!-- /.content -->
			</div><!-- /.content-wrapper -->

			<!-- Main Footer -->
			<footer class="main-footer">
				<!-- To the right -->
				<div class="pull-right hidden-xs">
					Web Master - Lcdo. Javier Salazar Marcano
				</div>
				<!-- Default to the left -->
				<strong>Copyright &copy; 2015 <a href="#">Universidad de Oriente</a>.</strong> Todos los Derechos Reservados.
			</footer>

		</div><!-- ./wrapper -->

		<!-- Cuadros de dialogos -->
		<div id="dialogo" title="Aviso"></div>
		<div id="resultado" title="Personal de Suplencia Registrado"></div>

		<!-- REQUIRED JS SCRIPTS -->

		<!-- jQuery 2.1.4 -->
		<script src="../../plugins/jQuery/jQuery-2.1.4.min.js"></script>
		<!-- Bootstrap 3.3.5 -->
		<script src="../../bootstrap/js/bootstrap.min.js"></script>
		<!-- JS Javier -->
		<script src="../../include/js/ui.js"></script>
		<!-- DataTables -->
		<script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
		<script src="../../plugins/datatables/dataTables.bootstrap.min.js"></script>
		<script src="../../plugins/datatables/TableTools.min.js"></script>
		<script src="../../plugins/datatables/jquery.battatech.excelexport.js"></script>
		<script src="../../plugins/jQueryUI/jquery-ui.min.js"></script>

		<!-- fancybox iframe -->
		<script src="../../plugins/fancybox/jquery.fancybox.js?v=2.1.5"></script>
		<!-- SlimScroll -->
		<script src="../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
		<!-- FastClick -->
		<script src="../../plugins/fastclick/fastclick.min.js"></script>
		<!-- AdminLTE App -->
		<script src="../../dist/js/app.min.js"></script>
		<!-- InputMask -->
		<script src="../../plugins/input-mask/jquery.inputmask.js"></script>
		<script src="../../plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
		<script src="../../plugins/input-mask/jquery.inputmask.extensions.js"></script>
		<!-- Suplentes -->
		<script src="js/suplentes.js"></script>
		<!-- UI Custom -->
		<script src="../../include/js/ui.js"></script>

<script type="text/javascript">
//····················inputmask (Mascaras como tlfn)························
$("[data-mask]").inputmask();
//···················· Disble click on tabs ························
/* $('a[data-toggle="tab"]').on('click', function(){
	if ($(this).parent('li').hasClass('disabled')) {
	return false;
	};
});
 */
//····················Dialogo························
$("#dialogo").dialog({
	autoOpen : false,
	closeText : ""
});

/* $("#tabSoportes").tooltip({
	content : "<div class='ui-state-highlight ui-corner-all' style='padding: 0 .7em;'><p><span class='ui-icon ui-icon-info' style='float: left; margin-right: .3em; margin-top: .2em;'></span>Aviso! Debe<strong style='color:red'> guardar</strong> primero los datos del candidato.</p></div>"
}); */
cargarmenu(0);
</script>

		<!-- Optionally, you can add Slimscroll and FastClick plugins.
		Both of these plugins are recommended to enhance the
		user experience. Slimscroll is required when using the
		fixed layout. -->
	</body>
</html>
