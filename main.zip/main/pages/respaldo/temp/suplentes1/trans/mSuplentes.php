<?php
	//session_start();
	include_once("../clases/Suplentes.php");

	foreach($_POST as $nombre_campo => $valor)
	{
	   $asignacion = "\$" . $nombre_campo . "='".addslashes($valor)."';";
	   eval($asignacion);
	} 
	 
	switch($accion){
		case 'guardarNuevoSuplente':	
			$Suplentes = new Suplentes();
			$datos = $Suplentes->guardarNuevoSuplente($profesion, $nombres, $apellidos, $cedula, $email, $telefono1, $telefono2);
		break;
		case 'verificarCedulaSuplente':	
			$Suplentes = new Suplentes();
			$datos = $Suplentes->verificarCedulaSuplente($cedula);
		break;	
	}
	echo json_encode($datos);

?>