<!DOCTYPE html>
<html lang="es">
<head>
  <title>PG Conex</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>  
  <link rel="stylesheet" href="https://cdn.datatables.net/plug-ins/1.10.7/integration/jqueryui/dataTables.jqueryui.css">
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
   <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
   <script type="text/javascript" src="https://cdn.datatables.net/1.10.7/js/jquery.dataTables.min.js"></script>
   <script type="text/javascript" src="https://cdn.datatables.net/plug-ins/1.10.7/integration/jqueryui/dataTables.jqueryui.js"></script>
-->
	<link rel="stylesheet" href="plugins/datatables/jquery.dataTables.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
	
	<script src="plugins/datatables/jquery.js"></script>
	<script src="plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="plugins/datatables/dataTables.bootstrap.min.js"></script>
    <script src="plugins/datatables/TableTools.min.js"></script>
	<script src="plugins/datatables/dataTables.jqueryui.js"></script>

	
	</head>
<body>

<div class="container" >
     <h1>Lista de Usuarios - N&uacute;cleo de Sucre &nbsp;<button>Imprimir</button></h1>
	
<?php
       $dbconn = pg_connect( "user=".USUARIO.
							" password=".CLAVE.
							" host=".SERVIDOR.
							" dbname=suplenciasudo"
						  ) or die( "Error al conectar: ".pg_last_error() );


	
$query = 'SELECT id_persona, tx_cedula, tx_nombre_apellido FROM usuarios;';
$result = pg_query($query) or die('Query failed: ' . pg_last_error());

$rows = pg_numrows($result);
//echo "<h1>cantidad de rows $rows </h1>";

echo "<table id='tabladyn' class='cell-border' cellspacing='0' width='100%'>\n";
echo "<thead>";
echo "<tr><th>ID<th>CEDULA<th>NOMBRE</tr>";
echo "</thead>";
//mostrar los datos
for($i=1;$i<=$rows; $i++){
$line = pg_fetch_array($result, null, PGSQL_ASSOC);
echo "\t<tr>\n";
echo "\t\t<td>$line[id_persona]</td>\n";
echo "\t\t<td>$line[tx_cedula]</td>\n";
echo "\t\t<td>$line[tx_nombre_apellido]</td>\n";
echo "\t</tr>\n";
}
echo "</table>\n";
echo "<hr>";
// Free resultset
pg_free_result($result);
// Closing connection
pg_close($dbconn);
?>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $('#tabladyn').dataTable( {
            paging: false,
			searching: false, 
			"language": {"url": "plugins/datatables/dataTableSpanish.json"}
        } );
    } );
	
	$("button").click(function(){
    $("button").hide();
	window.print();
	$("button").show();
});
</script>

 

 
</body>
</html>
