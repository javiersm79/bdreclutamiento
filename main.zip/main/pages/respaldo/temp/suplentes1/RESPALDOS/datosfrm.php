<?php


//convertir los valores de un form en un array
$datos=array(); 
foreach($_POST as $columna => $valor) $datos[$columna]="$valor";


echo "Datos del Array <br>";
print_r($datos);
//print_r($_POST);
/* 	foreach($_POST as $nombre_campo => $valor)
	{
	   $asignacion = "\$" . $nombre_campo . "='".addslashes($valor)."';";
	   eval($asignacion);
	} 
echo $nombres; */

?>