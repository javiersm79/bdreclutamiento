<?php

/* $ncedula=$_FILES['imgcedula']['name'];


echo $ncedula."<br></br>";
//mkdir('js/'.$nombrec, 0755, true);
//$uploaddir = 'js/'.$ncedula.'/';

$uploadfile = "soportes/" . basename($_FILES['imgcedula']['name']);
move_uploaded_file($_FILES['imgcedula']['tmp_name'], $uploadfile);

    print_r($_POST);
    print_r($_FILES);
//echo $_POST['txcedula'];

 */
 

?>