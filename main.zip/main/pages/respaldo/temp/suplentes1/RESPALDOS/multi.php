<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<title>title</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<meta name="robots" content="index,follow" />
	<link rel="stylesheet" type="text/css" href="styles.css" />
	<!-- jQuery 2.1.4 -->
    <script src="../../plugins/jQuery/jQuery-2.1.4.min.js"></script>
</head>

<body>
<!-- <form action="subirfiles.php" method="post" enctype="multipart/form-data">
  Enviar estos archivos:<br />
  <input name="cedula" id="cedulaimg" type="file" /><br />
  <input name="chequera" id="chequeraimg" type="file" /><br />
  <input type="submit" value="Send files" />
</form>  -->

<form id="formcedula" enctype="multipart/form-data">
	
    <input name="imgcedula" type="text" /><br/>
    <input name="imgcedula2" type="file" /><br/>
    <input type="button" value="Cargar cedula" />
</form>
<progress id="progcedula" value="0"></progress><br/><br/>

<form id="formtitulo" enctype="multipart/form-data">
    <input name="titulo" type="file" /><br/>
    <input type="button" value="Cargar titulo" />
</form>
<progress id="progtitulo" value="0"></progress>



<script type="text/javascript" src="js/suplentes.js"></script> 


<script type="text/javascript">

/* $(':file').change(function(){
    var file = this.files[0];
    var name = file.name;
    var size = file.size;
    var type = file.type;
    //Your validation
});*/

$(':button').click(function(){
    var formData = new FormData($('form')[0]);
    $.ajax({
        url: 'upload.php',  //Server script to process data
        type: 'POST',
        xhr: function() {  // Custom XMLHttpRequest
            var myXhr = $.ajaxSettings.xhr();
            if(myXhr.upload){ // Check if upload property exists
                myXhr.upload.addEventListener('progress',progressHandlingFunction, false); // For handling the progress of the upload
            }
            return myXhr;
        },
        //Ajax events
        //beforeSend: beforeSendHandler,
        //success: completeHandler,
        //error: errorHandler,
        // Form data
        //data: {formData, 'nombre':'1'},
		data: formData,
        //Options to tell jQuery not to process data or worry about content-type.
        cache: false,
        contentType: false,
        processData: false
    });
});

function progressHandlingFunction(e){
    if(e.lengthComputable){
        $('#progcedula').attr({value:e.loaded,max:e.total});
    }
}
</script>
</body>
</html>
