<?php 
	include_once('../../../include/clases/BD.php');
	class Suplentes
	{
		
		public function guardarTempPersona($id_datos_generales)
		{
			/*$bd=new FachadaBD();
			$bd->abrir(BD,SERVIDOR,USUARIO,CLAVE,PUERTO);
			$sql_1=	"select 
						sum(nu_meta) as total_meta
					from 
						formulacion.t002_accion_especifica
					where 
						id_datos_generales =".$id_datos_generales." and in_activo = 1";
			$resul_1=$bd->consultar($sql_1,'ARREGLO');
			$sql_2=	"select 
						sum(nu_total) as total_distribucion
					from 	
						formulacion.t002_accion_especifica a join 
						formulacion.t005_distribucion_meta b on (a.id_accion_especifica = b.id_accion_especifica)
					where 
						id_datos_generales =".$id_datos_generales." and in_activo = 1";
			$resul_2=$bd->consultar($sql_2,'ARREGLO');
			
			$resultado =0;
			if ($resul_1[0]['total_meta'] == $resul_2[0]['total_distribucion']){
				$resultado =1;
			}else
				$resultado = 2;
			return $resultado;*/
		} //Fin de la funcion guardarTempPersona
		
		public function guardarNuevoSuplente($profesion, $nombres, $apellidos, $cedula, $email, $telefono1, $telefono2)
		{
			$bd=new Datos();
			$bd->conectar();
			$datosSup = array(
			    "id_suplente" => rand(),
			    "nombres" => $nombres,
			    "apellidos" => $apellidos,
			    "cedula" => $cedula,
				"email" => $email,
			    "telefono1" => $telefono1,
			    "telefono2" => $telefono2,
			    "profesion" => $profesion  
			);
			$buscarCedula = $this->verificarCedulaSuplente($cedula); //Verifica si esa cedula esta registrada
			//$cedulaReg = json_decode($buscarCedula);
			//echo $buscarCedula;
			//print_r($buscarCedula);
 			//if ($cedulaReg[0]->{'count'} > 0) {
			if ($buscarCedula == 0) {
				$resultado=$bd->insertar("suplente",$datosSup);
				//echo $cedulaReg;
			}
			else {
				$resultado = 2;
			}
			//$resultado = 2;
			$bd->desconectar();	
			return $resultado;

		} //Fin de la funcion guardarTempPersona
		
		public function verificarCedulaSuplente($cedula)
		{
			$bd=new Datos();
			$bd->conectar();
			$sql ="SELECT cedula, id_suplente FROM suplente WHERE cedula = '".$cedula."'";
			//echo $sql;
			$resultado=$bd->consultar($sql);	
			return $resultado;
		} //Fin de la funcion guardarTempPersona
			
	} //Fin de la clase Suplentes
?>