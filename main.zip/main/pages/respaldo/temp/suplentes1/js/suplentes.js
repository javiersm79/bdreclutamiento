
function guardarActualizarSuplente(datafrm){
	cedula=$("#cedulaimg").val();
	$.ajax({
		type:'POST',
		async:false,
		//url:"datosfrm.php",
		url:"trans/mSuplentes.php",	
		data:datafrm,
		error:function(xhr,ajaxOptions,thrownError){
			//$('#msgFooterDatos').html('<div class="ui-state-error ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;Error!</strong> Intente nuevamente</h4></div>');
			msgNotificar("msgFooterDatos", "error", " Error! Contactar con el administrador del sistema");
		},
		success:function(req){			
			
 				var data=req;
				if(data == 0){
					msgNotificar("msgFooterDatos", "advertencia", "Verificar los datos");
				}
				else if(data == 1){
					$('#tabSoportes').removeClass("disabled");
					$("#tabSoportes").tooltip("disable");
					var i=0; for (i=1;i<=1;i++) {
						//$('form > input')[i].val("Funciono");
						$('form').each(function(){
							//$(this).find("input #idCedula").text("Funciono");
							idFrm=$(this).attr("id");
							//alert($( "#"+idFrm+" input:first" ).val());
						});
						
					} 
					msgNotificar("msgFooterDatos", "exito", "Registro ingresado exitosamente");
					
				} 				
				else if(data == 2){
					msgNotificar("msgFooterDatos", "advertencia", "C&eacute;dula registrada en el sistema");
				} 
			}
		
	});
}
//···················· Carga de archivos ························
function subirArchivo(datafrm){
			$.ajax({
			url: 'soportes/subirImg.php',  //Server script to process data
			//url: 'datosfrm.php',  //Server script to process data
			type: 'POST',
			xhr: function() {  // Custom XMLHttpRequest
				var myXhr = $.ajaxSettings.xhr();
				if(myXhr.upload){ // Check if upload property exists
					myXhr.upload.addEventListener('progress',progressHandlingFunction, false); // For handling the progress of the upload
				}
				return myXhr;
			},
			//Ajax events
			//beforeSend: beforeSendHandler,
			//success: completeHandler,
			//error: errorHandler,
			// Form data
			//data: {datafrm, 'cedula':'123'},
			data: datafrm,
			//Options to tell jQuery not to process data or worry about content-type.
			cache: false,
			contentType: false,
			processData: false
		}); //*****Fin $.ajax UPLOAD
}
function progressHandlingFunction(e){
    if(e.lengthComputable){
        //$('#progceula').attr({'style', 'width:'+e.loaded,max:e.total;});
		$( "#progcedula" ).css( "width", e.loaded );
       
    }

}
//···················· Fin de carga de archivos ························

//····················Botones de carga de archivo y envio de datos························
$(':button').click(function(){
	//var valido =0;
	switch ($(this).attr('id')) {
	case 'btnGuardar':
        //var formData = new FormData($('form')[0]);
		var profesionsuplente=$("#profesionsuplente").val();
		var nombresuplente=$("#nombresuplente").val();
		var apellidossuplente=$("#apellidossuplente").val();
		var precedula=$("#precedula").val();
		var cedulasuplente=$("#cedulasuplente").val();
		var emailasuplente=$("#emailasuplente").val();
		var telefono1=$("#telefono1").val();
		var telefono2=$("#telefono2").val();
		
		if (profesionsuplente == "")
		{
			$("#grupoProfesion").addClass("has-error");
			$("#profesionsuplente").attr("title", "Ingresar la profesi&oacute;n del candidato");
		}
		else if (nombresuplente == "")
		{
			$("#grupoNombres").addClass("has-error")
			$("#nombresuplente").attr("title", "Ingresar los nombres del candidato");
		}
		else if (apellidossuplente == "")
		{
			$("#grupoApellidos").addClass("has-error")
			$("#apellidossuplente").attr("title", "Ingresar los apellidos del candidato");
		}
		else if (cedulasuplente == "")
		{
			$("#grupoCedula").addClass("has-error")
			$("#cedulasuplente").attr("title", "Ingresar la c&eacute;dula del candidato");
		}
		else if (emailasuplente == "" &&  telefono1 == "" &&  telefono2 == "")
		{
			$("#grupoEmail").addClass("has-error");
			$("#grupoTlf1").addClass("has-error");
			$("#grupoTlf2").addClass("has-error");
			if( $('#msgFooterDatos').length )         // use this if you are using id to check
			{
			     //$('#msgFooterDatos').html('<div class="alert alert-warning alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> <strong>Aviso!</strong> Debe ingresar alg&uacute;n dato de contacto (Email o Tel&eacute;fono)</h4></div>');
			     $('#msgFooterDatos').html('<div class="ui-state-error ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;Aviso!</strong> Debe ingresar alg&uacute;n dato de contacto (Email o Tel&eacute;fono)</h4></div>');
			}
			//$('#dialogo').html('Debe ingresar alg&uacute;n dato de contacto (Email o Tel&eacute;fono)');
			//$('#dialogo').dialog('open');
		}
		else
		{
			//valido =0;
			//var formData = "{'data1':'" + nombresuplente+ "', 'data2':'" + cedulasuplente+ "', 'data3':'" + emailasuplente+ "'}";
			var formData = {accion: 'guardarNuevoSuplente', profesion: profesionsuplente, nombres: nombresuplente, apellidos: apellidossuplente, cedula: precedula + '-' + cedulasuplente, email: emailasuplente, telefono1: telefono1, telefono2: telefono2};
			guardarActualizarSuplente(formData);
		}
        break;
    case 'btnImgCed':
        var formData = new FormData($('form')[1]);
		 subirArchivo(formData);
        break;
    case 'btnImgBco':
        var formData = new FormData($('form')[2]);
		subirArchivo(formData);
        break;
    case 'btnImgTit':
        var formData = new FormData($('form')[3]);
        break;
    case 'btnPdfCV':
        var formData = new FormData($('form')[4]);
        break;
	default:
		$("#botonGuardar").show();
		$('#dialogo').html('');
		$('#dialogo').dialog('open');
	}
	//$( "#tabSoportes" ).tooltip( "disable" );
	
}); 
//********************Fin evento click del boton*******************


	
//************PREVIENE EL CLICK EN LAS TABS DESABILITADAS**********************
/* $('a[data-toggle="tab"]').on('click', function(){
  if ($(this).parent('li').hasClass('disabled')) {
    return false;
  };
}); */

