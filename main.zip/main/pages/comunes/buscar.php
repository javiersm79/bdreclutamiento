<!DOCTYPE html>
<html lang="es">
<head>
  <title>Buscar Suplente</title>
    <meta charset="UTF-8">
    <title>Buscar Suplente</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
	<!-- Dialogos -->
	<link rel="stylesheet" href="../../include/css/jquery-ui-smoothness.css">

    <!-- Ionicons ******** Utilizar en el futuro para cargar iconos locales*************
   <link rel="stylesheet" href="include/themes/ionicons/css/ionicons.min.css">-->
	    <!-- DataTables -->
    <link rel="stylesheet" href="../../plugins/datatables/dataTables.bootstrap.css">
    <link rel="stylesheet" href="../../plugins/datatables/extensions/Buttons/css/buttons.dataTables.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. We have chosen the skin-blue for this starter
          page. However, you can choose any other skin. Make sure you
          apply the skin class to the body tag so the changes take effect.
    -->
    <link rel="stylesheet" href="../../dist/css/skins/skin-blue.min.css">
	</head>
<body>

<div class="container" >
<!-- Horizontal Form -->
				<div class="box box-info">
					<div class="box-header with-border"></div>
					 <div class="box-body"> 
					 <div id="tablaCandidatos"></div>
					 
						<?php
						/*
					$dbconn = pg_connect( "user=pgsuplencia ".
													"password=pgsuplencia ".
													"host=190.168.128.109 ".
													"dbname=suplenciaudo"
												  ) or die( "Error al conectar: ".pg_last_error() );


						
					$query = 'SELECT * FROM persona;';
					$result = pg_query($query) or die('Query failed: ' . pg_last_error());

					$rows = pg_numrows($result);
					//echo "<h1>cantidad de rows $rows </h1>";

					//echo "<table id='tabladyn' class='display' cellspacing='0' width='100%'>\n";
					echo "<table id='tabladyn' class='table table-bordered table-striped table-hover'>\n";
					echo "<thead>";
					echo "<tr><th>ID</th><th>CEDULA</th><th>NOMBRE</th><th>APELLIDO</th><th>Seleccionar</th></tr>";
					echo "</thead>";
					//mostrar los datos
					echo "<tbody>";
					for($i=1;$i<=$rows; $i++){
					$line = pg_fetch_array($result, null, PGSQL_ASSOC);
					echo "\t<tr>\n";
					echo "\t\t<td>$line[id_usuario]</td>\n";
					echo "\t\t<td>$line[cedula]</td>\n";
					echo "\t\t<td>$line[nombre]</td>\n";
					echo "\t\t<td>$line[apellidos]</td>\n";
					echo "\t\t<td align='center' width='100'><button class='btn-xs btn-flat btn-primary' style='width: 100px; heigth: 1000px' onclick='' name=$line[id_usuario]>Seleccionar</button></td>\n";
					echo "\t</tr>\n";
					}
					echo "</tbody>";
					echo "</table>\n";
					// Free resultset
					pg_free_result($result);
					// Closing connection
					pg_close($dbconn);*/
					?>	
					</div>			
				</div><!-- /.box-body -->		
			</div><!-- /.box -->	
</div>

<input type="hidden" value="valor por defecto" id="idpersona"/>
<input type="hidden" value="valor por defecto" id="nombrepersona"/>

<!-- REQUIRED JS SCRIPTS -->

    <!-- jQuery 2.1.4 -->
    <script src="../../plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../../bootstrap/js/bootstrap.min.js"></script>
    <!-- DataTables -->
    <script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../../plugins/datatables/dataTables.bootstrap.min.js"></script>
    <script src="../../plugins/jQueryUI/jquery-ui.min.js"></script>


<script type="text/javascript">
/*     $(document).ready(function() {
        $('#tabladyn').dataTable( {
			"language": {"url": "../../plugins/datatables/dataTableSpanish.json"}
			
        } );
    } ); */


$.ajax({
		type:'POST',
		async:false,
		//url:"datosfrm.php",
		url:"../suplentes/trans/mSuplentes.php",	
		data:{"accion":"cargarCandidatos"},
		error:function(xhr,ajaxOptions,thrownError){
			//$('#msgFooterDatos').html('<div class="ui-state-error ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;Error!</strong> Intente nuevamente</h4></div>');
			//msgNotificar("msgFooterDatos", "error", " Error! Contactar con el administrador del sistema");
		},
		success:function(req){
  				var data=$.parseJSON(req);
				if(data)
				{
					//$("<span>Hello World!</span>").appendTo("#tablaCandidatos");
 					$('#tablaCandidatos').html("<table id='tabladyn' class='table table-bordered table-striped table-hover'><thead><th>CEDULA</th><th>NOMBRE</th><th>TELEFONO</th><th>EMAIL</th><th>SELECCIONAR</th></thead><tbody></tbody></table>")
					for (i = 0; i < data.length; i++) {
						if (!data[i]["telefono1"])
						{telefono="N/A"}
						else
						{telefono = data[i]["telefono1"]}
						$('#tabladyn > tbody:last').append('<tr><td>'+data[i]["cedula"]+'</td><td>'+data[i]["nombres"]+' '+data[i]["apellidos"]+'</td><td>'+telefono+'</td><td>'+data[i]["email"]+'</td><td align="center" width="100"><button class="btn-xs btn-flat btn-primary" style="width: 100px; heigth: 1000px" onclick="" name='+data[i]["id_persona"]+'>Seleccionar</button></td></tr>');
						//$('#tabladyn > tbody:last').append('<tr><td>'+data[i]["id_persona"]+'</td><td>'+data[i]["cedula"]+'</td><td>'+data[i]["nombres"]+' '+data[i]["apellidos"]+'</td><td>'+telefono+'</td><td>'+data[i]["email"]+'</td><td align="center" width="100"><button class="btn-xs btn-flat btn-primary" style="width: 100px; heigth: 1000px" onclick="" name='+data[i]["id_persona"]+'>Seleccionar</button></td></tr>');
						//$('#tablaCandidatosAll > tbody:last').append('<tr><td>'+data[i]["cedula"]+'</td><td>'+data[i]["nombres"]+' '+data[i]["apellidos"]'</td><td>3</td><td>4</td><td>5</td></tr>');
					}
					
					//$('#tablaCandidatos').append("<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td></tr></tbody></table> ");
					$('#tabladyn').dataTable( {
					"language": {"url": "../../plugins/datatables/dataTableSpanish.json"},
					 "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "Todos"]],
					 "columnDefs": [
						//{ "visible": false, "targets": 0 } 
			  ]
        } );
					 
				}
				else 
				{
					notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","Error al cargar datos", "type-danger");
				}  
			}
		
	});

$("button").click(function () {
//var selectedId = $(this).closest("tr").children('td:nth-child(1)').text();
var selectedId = $(this).attr("name");
var selectedCi = $(this).closest("tr").children('td:nth-child(1)').text();
var selectedName = $(this).closest("tr").children('td:nth-child(2)').text();
        $("#idpersona").val(selectedId);
        $("#nombrepersona").val(selectedCi + ' - ' + selectedName); 
		//alert ($("#idpersona").val())
		parent.jQuery.fancybox.close()
		//alert(selectedCi + ' - ' + selectedName);
});

</script>

 

 
</body>
</html>
