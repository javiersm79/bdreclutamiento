<!DOCTYPE html>
<html lang="es">
<head>
  <title>Buscar Suplente</title>
    <meta charset="UTF-8">
    <title>AdminLTE 2 | Dashboard</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
	<!-- Dialogos -->
	<link rel="stylesheet" href="../../include/css/jquery-ui-smoothness.css">

    <!-- Ionicons ******** Utilizar en el futuro para cargar iconos locales*************
   <link rel="stylesheet" href="include/themes/ionicons/css/ionicons.min.css">-->
	    <!-- DataTables -->
    <link rel="stylesheet" href="../../plugins/datatables/dataTables.bootstrap.css">
    <link rel="stylesheet" href="../../plugins/datatables/extensions/Buttons/css/buttons.dataTables.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. We have chosen the skin-blue for this starter
          page. However, you can choose any other skin. Make sure you
          apply the skin class to the body tag so the changes take effect.
    -->
    <link rel="stylesheet" href="d../../ist/css/skins/skin-blue.min.css">
	</head>
<body>

<div class="container" >
     <h1>Buscar Suplente</h1>

<?php
        $dbconn = pg_connect( "user=postgres ".
                                "password=1234jj ".
                                "host=localhost ".
                                "dbname=suplentesudo"
                              ) or die( "Error al conectar: ".pg_last_error() );


	
$query = 'SELECT id_persona, tx_cedula, tx_nombre_apellido FROM usuarios;';
$result = pg_query($query) or die('Query failed: ' . pg_last_error());

$rows = pg_numrows($result);
//echo "<h1>cantidad de rows $rows </h1>";

//echo "<table id='tabladyn' class='cell-border' cellspacing='1' width='100%'>\n";
echo "<table id='tabladyn' class='table table-bordered table-striped table-hover'>\n";
echo "<thead>";
echo "<th>ID</th><th>CEDULA</th><th>NOMBRE</th><th>SELECCIONAR</th>";
echo "</thead>";
//mostrar los datos
for($i=1;$i<=$rows; $i++){
$line = pg_fetch_array($result, null, PGSQL_ASSOC);
echo "\t<tr id=$line[id_persona]>\n";
//echo "\t<tr onclick='vercedula(this)'>\n";
echo "\t\t<td>$line[id_persona]</td>\n";
echo "\t\t<td>$line[tx_cedula]</td>\n";
echo "\t\t<td>$line[tx_nombre_apellido]</td>\n";
echo "\t\t<td align='center' width='100'><button class='btn btn-block btn-primary' style='width: 100px; heigth: 10px' onclick=''>Seleccionar</button></td>\n";

echo "\t</tr>\n";
}
echo "</table>\n";
echo "<hr>";
// Free resultset
pg_free_result($result);
// Closing connection
pg_close($dbconn);
?>
</div>

<input type="hidden" value="valor por defecto" id="idpersona"/>
<!-- REQUIRED JS SCRIPTS -->

    <!-- jQuery 2.1.4 -->
    <script src="../../plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../../bootstrap/js/bootstrap.min.js"></script>
    <!-- DataTables -->
    <script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../../plugins/datatables/dataTables.bootstrap.min.js"></script>
    <script src="../../plugins/jQueryUI/jquery-ui.min.js"></script>


<script type="text/javascript">
    $(document).ready(function() {
        $('#tabladyn').dataTable( {
			"language": {"url": "../../plugins/datatables/dataTableSpanish.json"}
        } );
    } );

/* $('tr').each(function() {
    $(this).click(function() {
        var selectedTd = $(this).children('td:nth-child(2)').text();
        $("#idpersona").val(selectedTd);
		parent.jQuery.fancybox.close()
		//alert(selectedTd);
    });
}); */




$("button").click(function () {
	
  var selectedCi = $(this).closest("tr").children('td:nth-child(2)').text();
  var selectedName = $(this).closest("tr").children('td:nth-child(3)').text();
        $("#idpersona").val(selectedCi + ' - ' + selectedName);
		parent.jQuery.fancybox.close()
		//alert(selectedCi + ' - ' + selectedName);
}); 
</script>

 

 
</body>
</html>
