<?php
include ("../../include/seg/security.php");
?>

<html>
	<head>
		<meta charset="UTF-8">
		<title>Ficha del Candidato</title>
		<!-- Tell the browser to be responsive to screen width -->
		<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
		<!-- Bootstrap 3.3.5 -->
		<link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
		<!-- jquery-ui -->
		<link rel="stylesheet" href="../../include/css/jquery-ui-smoothness.css">
		<!-- Font Awesome -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
		<!-- Ionicons ******** Utilizar en el futuro para cargar iconos locales*************
		<link rel="stylesheet" href="include/themes/ionicons/css/ionicons.min.css">-->
		<!-- Bootstraps Dialog -->
		<link rel="stylesheet" href="../../plugins/bootstrap-dialog/bootstrap-dialog.min.css">
		<!-- fancybox iframe -->
		<link rel="stylesheet" href="../../plugins/fancybox/jquery.fancybox.css?v=2.1.5" media="screen">
		<!-- Theme style -->
		<link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">
		<!-- AdminLTE Skins. We have chosen the skin-blue for this starter
		page. However, you can choose any other skin. Make sure you
		apply the skin class to the body tag so the changes take effect.
		-->
		<link rel="stylesheet" href="../../dist/css/skins/skin-blue.min.css">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

	</head>
<input type="hidden" name="id_candidato" id="id_candidato" value="<?php echo $_GET["id_candidato"]; ?>"/>
	<body class="skin-blue sidebar-mini">
		<div class="wrapper">

			<!-- Main Header -->
			<header class="main-header">

				<!-- Logo -->
				<a href="index2.html" class="logo"> <!-- mini logo for sidebar mini 50x50 pixels
				<span class="logo-mini"><b>A</b>LT</span>--> <!-- logo for regular state and mobile devices --> <span class="logo-lg"><b>Suplencias</b>UDO</span> </a>

				<!-- Header Navbar -->
				<nav class="navbar navbar-static-top" role="navigation">
					<!-- Sidebar toggle button-->
					<a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button"> <span class="sr-only">Toggle navigation</span> </a>

					<!-- Navbar Right Menu -->
					<div class="navbar-custom-menu">
						<ul class="nav navbar-nav">

							<!-- Salir del sistema -->
							<li>
								<a href="logout.php" ><i class="fa fa-sign-out"></i>&nbsp;Cerrar Sesi&oacute;n</a>
							</li>
						</ul>
					</div>
				</nav>
			</header>
			<!-- Left side column. contains the logo and sidebar -->
			<aside class="main-sidebar">

				 <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">

          <!-- Sidebar user panel (optional) -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="../../include/img/logo_udo_min.jpg" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
              <p><br/><?php echo $_SESSION["tipousuario"]; ?></p>
              <!-- Status 
              <a href="#"><i class="fa fa-circle text-success"></i> Delegado</a>
			 <p id="id_rol"><p/>-->
            </div>
          </div>

          <!-- search form (Optional)
          <form action="#" method="get" class="sidebar-form">
            <div class="input-group">
              <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i></button>
              </span>
            </div>
          </form> -->
          <!-- /.search form -->
			<div id="menu"><!-- Menu de navegacion --></div>
         
        </section>
        <!-- /.sidebar -->
			</aside>

			<!-- Content Wrapper. Contains page content -->
			<div class="content-wrapper">
				<!-- Content Header (Page header) -->
				<section class="content-header">
					<h1>&nbsp;&nbsp;Ficha del candidato <small>Datos del candidato registrados en el sistema</small></h1>
				</section>

				<!-- Main content -->
				<section class="invoice">
				  <!-- title row -->
				  <div class="row">
					<div class="col-xs-12">
					  <h2 class="page-header">
						<i class="fa fa-user"></i> <span id="nombres"></span><span id="precedula"></span><span id="cedula"></span><!-- Nombre / CI del Candidato -->
						<small class="pull-right"></small>
					  </h2>
					</div><!-- /.col -->
				  </div>
				  <!-- info row -->
				<div class="row invoice-info">
					<div class="col-sm-12 invoice-col">
						<strong>Títulos:</strong><br>					
						<address class="callout callout-warning">
						<strong id="profesionsuplente"></strong>
						</address>
					</div><!-- /.col -->
				</div><!-- /.row ******Profesiones******-->
				<div class="row invoice-info">
					<div class="col-sm-4 invoice-col">
						<strong>Datos de Contacto</strong>
						<address class="callout callout-success">
							<strong>Teléfono 1: </strong><span id="telefono1"></span><br>
							<strong>Teléfono 2: </strong><span id="telefono2"></span><br>
							<strong>Email: </strong><span id="emailsuplente"></span><br>
							<strong>Fecha de Nac: </strong><span id="fechanacsuplente"></span><br>
							<strong>Sexo: </strong><span id="sexo"></span><br>
							<strong>Motricidad: </strong><span id="motricidad"></span><br>
							<strong>SSO: </strong><span id="segurosocial"></span>&nbsp;&nbsp;&nbsp;<button name="actSSO" id="actSSO" class="btn btn-flat btn-xs" style="color: black" onclick="actualizarSSO()">Verificar SSO</button><br> 
						</address>
					</div><!-- /.col -->
					<div class="col-sm-4 invoice-col">
						<strong>Habilidades:</strong><br>					
						<address class="callout callout-info">
						1º:&nbsp;<strong id="fortaleza1"></strong><br>
						2º:&nbsp;<strong id="fortaleza2"></strong><br>
						3º:&nbsp;<strong id="fortaleza3"></strong><br>
						</address>
						<strong>Inf. Bancaria:</strong><br>					
						<address class="callout callout-info">
						Banco:&nbsp;<strong id="banco"></strong><br>
						Tipo de Cuenta:&nbsp;<strong id="tipoctabancaria"></strong><br>
						Nº de Cuenta:&nbsp;<strong id="nctabnacaria"></strong><br>
						</address>
					</div><!-- /.col -->
					<div class="col-sm-4 invoice-col">
						<strong>Ubicaci&oacute;n:</strong><br>					
						<address class="callout callout-danger">
						<strong>Estado: </strong><span id="estadosuplente"></span><br>
						<strong>Municipio: </strong><span id="municipiosuplente"></span><br>
						<strong>Parroquia: </strong><span id="parroquiasuplente"></span><br>
						</address>
					</div><!-- /.col -->



				
				<!-- /.row ******BOTONES DE SOPORTES******-->
				<div class="row invoice-info">
						<div class="col-sm-8 invoice-col">
						<strong>&nbsp;&nbsp;&nbsp;Soportes</strong><br>					
						<a id="verImgFoto" class="btn btn-app fancybox.iframe" href="#">
							<i class="fa fa-credit-card"></i> Foto
						</a>			
						<a id="verImgCedula" class="btn btn-app fancybox.iframe" href="#">
							<i class="fa fa-credit-card"></i> C&eacute;dula
						</a>
						<a id="verImgSalud" class="btn btn-app fancybox.iframe" href="#">
							<i class="fa fa-file-text"></i> Cert. Salud
						</a>
						<a id="verImgBanco" class="btn btn-app fancybox.iframe" href="#">
							<i class="glyphicon glyphicon-folder-close"></i> Banco
						</a>
						<a id="verImgTitulo" class="btn btn-app fancybox.iframe" href="#">
							<i class="fa fa-file-text"></i> T&iacutetulo
						</a>
						<a id="verCV" class="btn btn-app" href="#" download>
							<i class="fa fa-file-pdf-o"></i> CV
						</a>
					</div><!-- /.col -->
				</div><!-- /.row ******BOTONES DE SOPORTES******---->
				
				
				  <!-- Table row -->
				  <div class="row">
					<div class="col-xs-12 table-responsive">
					  <table class="table table-striped">
						<thead>
						  <tr class="bg-light-blue-active color-palette" >
							<th colspan=5  class="text-center">Últimas Suplencias realizadas</th>
						  </tr>
						  <tr>
							<th>No. Oficio</th>
							<th>Empleado</th>
							<th>CI Empleado</th>
							<th>Periodo</th>
							<th>Duraci&oacuten</th>
						  </tr>
						</thead>
						<tbody>
<!-- 						  <tr>
							<td>12355</td>
							<td>Juan Perez</td>
							<td>V-12444678</td>
							<td>22/10/2011 al 30/10/2011</td>
							<td>8 Dias</td>
						  </tr>
						  <tr>
							<td>34556</td>
							<td>Juan Perez</td>
							<td>V-12444678</td>
							<td>1/10/2013 al 30/10/2013</td>
							<td>1 Mes</td>
						  </tr>
						  <tr>
							<td>44666</td>
							<td>Jose Blondel</td>
							<td>V-14778900</td>
							<td>12/02/2014 al 15/02/2014</td>
							<td>3 Dias</td>
						  </tr>
						  <tr>
							<td>778999</td>
							<td>Marta Blanco</td>
							<td>V-11345665</td>
							<td>17/11/2014 al 30/11/2014</td>
							<td>13 Dias</td>
						  </tr> -->
						</tbody>
					  </table>
					</div><!-- /.col -->
				  </div><!-- /.row -->

				  <div class="row">
					<!-- accepted payments column 
					<div class="col-xs-6">
					  <p class="lead">Payment Methods:</p>
					  <img src="../../dist/img/credit/visa.png" alt="Visa">
					  <img src="../../dist/img/credit/mastercard.png" alt="Mastercard">
					  <img src="../../dist/img/credit/american-express.png" alt="American Express">
					  <img src="../../dist/img/credit/paypal2.png" alt="Paypal">
					  <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
						Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles, weebly ning heekya handango imeem plugg dopplr jibjab, movity jajah plickers sifteo edmodo ifttt zimbra.
					  </p>
					</div> /.col -->
					<!-- <div class="col-xs-6">
					  <p class="lead">Amount Due 2/22/2014</p>
					  <div class="table-responsive">
						<table class="table">
						  <tr>
							<th style="width:50%">Subtotal:</th>
							<td>$250.30</td>
						  </tr>
						  <tr>
							<th>Tax (9.3%)</th>
							<td>$10.34</td>
						  </tr>
						  <tr>
							<th>Shipping:</th>
							<td>$5.80</td>
						  </tr>
						  <tr>
							<th>Total:</th>
							<td>$265.24</td>
						  </tr>
						</table>
					  </div>
					</div>/.col -->
				  </div><!-- /.row -->

				  <!-- this row will not appear when printing -->
				  <div class="row no-print">
					<div class="col-xs-12">
					  <a href="#" id="btnImprimirFicha" class="btn btn-default" target="blank"><i class="fa fa-print"></i> Imprimir</a>
					  <!-- <button class="btn btn-success pull-right"><i class="fa fa-credit-card"></i> Submit Payment</button> -->
					  <button class="btn btn-primary pull-right" style="margin-right: 5px;" onclick="$('#dialogo').dialog('open')"><i class="fa fa-pencil-square-o"></i> Editar datos</button>
					</div>
				  </div>


				</section><!-- /.content -->
			</div><!-- /.content-wrapper -->

			<!-- Main Footer -->
			<footer class="main-footer">
				<!-- To the right -->
				<div class="pull-right hidden-xs">
					Web Master - Lcdo. Javier Salazar Marcano
				</div>
				<!-- Default to the left -->
				<strong>Copyright &copy; 2015 <a href="#">Universidad de Oriente</a>.</strong> Todos los Derechos Reservados.
			</footer>

		</div><!-- ./wrapper -->

		<!-- Cuadros de dialogos -->
			<div id="dialogo" title="Confirmar">
				¿Desea editar los datos del candidato?
				<div class="modal-footer">
				    <button type="button" class="btn btn-primary pull-left">Aceptar</button>
                    <button type="button" class="btn btn-default pull-right" data-dismiss="modal">Cancelar</button>
                </div>
			
			</div>
		</div>
		<div id="resultado" title="Personal de Suplencia Registrado"></div>

		<!-- REQUIRED JS SCRIPTS -->

		<!-- jQuery 2.1.4 -->
		<script src="../../plugins/jQuery/jQuery-2.1.4.min.js"></script>
		<!-- Bootstrap 3.3.5 -->
		<script src="../../bootstrap/js/bootstrap.min.js"></script>
		<!-- JS Javier -->
		<script src="../../include/js/ui.js"></script>
		<!-- DataTables -->
		<script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
		<script src="../../plugins/datatables/dataTables.bootstrap.min.js"></script>
		<script src="../../plugins/datatables/TableTools.min.js"></script>
		<script src="../../plugins/datatables/jquery.battatech.excelexport.js"></script>
		<script src="../../plugins/jQueryUI/jquery-ui.min.js"></script>

		<!-- fancybox iframe -->
		<script src="../../plugins/fancybox/jquery.fancybox.js?v=2.1.5"></script>
		<!-- SlimScroll -->
		<script src="../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
		<!-- FastClick -->
		<script src="../../plugins/fastclick/fastclick.min.js"></script>
		<!-- AdminLTE App -->
		<script src="../../dist/js/app.min.js"></script>
		<!-- InputMask -->
		<script src="../../plugins/input-mask/jquery.inputmask.js"></script>
		<script src="../../plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
		<script src="../../plugins/input-mask/jquery.inputmask.extensions.js"></script>
		<!-- Suplentes -->
		<script src="js/suplentes.js"></script>
		<!-- UI Custom -->
		<script src="../../include/js/ui.js"></script>
		<!-- Bootstraps Dialog -->
		<script src="../../plugins/bootstrap-dialog/bootstrap-dialog.min.js"></script>		
		

<script type="text/javascript">
$(".verImg").fancybox({
		fitToView	: true,
		width		: '100%',
		height		: '100%',
		autoSize	: true,
		closeClick	: true,
		scrolling: 'auto',
		helpers     : {  
		title : { type : 'inside', position: 'top' },
		},
		beforeShow: function(){
		this.title = '<a href="' + this.href + '" download>Click aqui para Descargar</a> '
		//this.title = $("#verImgFoto").attr('href')
		//this.title = "<a type='button' value='Descargar archivo' href='" + $("#verImgFoto").attr('href')+'/cedula.jpg download />'
		}
	});
//····················inputmask (Mascaras como tlfn)························
$("[data-mask]").inputmask();
//···················· Disble click on tabs ························
$('a[data-toggle="tab"]').on('click', function(){
	if ($(this).parent('li').hasClass('disabled')) {
	return false;
	};
});

//····················Dialogo························
$("#dialogo").dialog({
	autoOpen : false,
	closeText : ""
});


$("#tabSoportes").tooltip({
	content : "<div class='ui-state-highlight ui-corner-all' style='padding: 0 .7em;'><p><span class='ui-icon ui-icon-info' style='float: left; margin-right: .3em; margin-top: .2em;'></span>Aviso! Debe<strong style='color:red'> guardar</strong> primero los datos del candidato.</p></div>"
});
$("#btnImprimirFicha").attr('href','pdfFichaPersona.php?id_persona='+$("#id_candidato").val());
//$("#verImgTitulo").attr('href','soportes/'+data[0]["id_persona"]+'/titulo.jpg');
cargarmenu(0);
buscarDatosFicha();
</script>

		<!-- Optionally, you can add Slimscroll and FastClick plugins.
		Both of these plugins are recommended to enhance the
		user experience. Slimscroll is required when using the
		fixed layout. -->
	</body>
</html>
