<?php
	include ("../../include/seg/security.php");
	//include_once('../../include/clases/BD.php');
	include_once('clases/Suplentes.php');
	require('../../include/clases/fpdf/fpdf.php');
	//require('/var/www/main/include/clases/fpdf/fpdf.php')
	$id_persona=$_SESSION['id_persona'];



	$persona = new Suplentes();	
	
	//$persona -> buscarDatosCandidato($id_persona);

	class myPDF extends FPDF{
		function Header(){
	//*********HEADER*****************************************
	$this->SetFont('Arial','',11);
    $this->Image("../../include/img/logo_udo_min.jpg", 10 ,12,12,12);
	$this->Cell(18);
	$this->Cell(180,5,'UNIVERSIDAD DE ORIENTE',0,1,'L');
	$this->Cell(18);
	$this->Cell(180,5,'RECTORADO',0,1,'L');
	$this->Cell(18);
	$this->Cell(180,5,'DIRECCIÓN DE PERSONAL',0,1,'L');
	$this->ln(5);		
/* 	$this->SetFont('helvetica','',9);
	$this->Cell('',0,'FICHA ANUAL DEL PROYECTO',0,1,'C');
	$this->ln(5);
	$this->Cell('',0,'AÑO: 2016',0,1,'C');
	$this->ln(7); */
	}
	//*********FIN HEADER*****************************************
	
	//*******************PARA TABLAS*********************************
	
	var $widths;
	var $aligns;
	
	function SetWidths($w)
	{
	    //Set the array of column widths
	    $this->widths=$w;
	}
	
	function SetAligns($a)
	{
	    //Set the array of column alignments
	    $this->aligns=$a;
	}
	
	function Row($data)
	{
	    //Calculate the height of the row
	    $nb=0;
	    for($i=0;$i<count($data);$i++)
	        $nb=max($nb,$this->NbLines($this->widths[$i],$data[$i]));
	    $h=5*$nb;
	    //Issue a page break first if needed
	    $this->CheckPageBreak($h);
	    //Draw the cells of the row
	    for($i=0;$i<count($data);$i++)
	    {
	        $w=$this->widths[$i];
	        $a=isset($this->aligns[$i]) ? $this->aligns[$i] : 'L';
	        //Save the current position
	        $x=$this->GetX();
	        $y=$this->GetY();
			
			if ($i%2<>0){ //MODIFICACION PARA DIBUJAR LOS BORDES DE LA TABLA SOLO EN LAS COLUMNASP PARES
	        //Draw the border
	        $this->Rect($x,$y,$w,$h);        
			}
			//Print the text
	        $this->MultiCell($w,5,$data[$i],0,$a);
	        //Put the position to the right of the cell
	        $this->SetXY($x+$w,$y);
	    }
	    //Go to the next line
	    $this->Ln($h);
	}
	
	function CheckPageBreak($h)
	{
	    //If the height h would cause an overflow, add a new page immediately
	    if($this->GetY()+$h>$this->PageBreakTrigger)
	        $this->AddPage($this->CurOrientation);
	}
	
	function NbLines($w,$txt)
	{
	    //Computes the number of lines a MultiCell of width w will take
	    $cw=&$this->CurrentFont['cw'];
	    if($w==0)
	        $w=$this->w-$this->rMargin-$this->x;
	    $wmax=($w-2*$this->cMargin)*1000/$this->FontSize;
	    $s=str_replace("\r",'',$txt);
	    $nb=strlen($s);
	    if($nb>0 and $s[$nb-1]=="\n")
	        $nb--;
	    $sep=-1;
	    $i=0;
	    $j=0;
	    $l=0;
	    $nl=1;
	    while($i<$nb)
	    {
	        $c=$s[$i];
	        if($c=="\n")
	        {
	            $i++;
	            $sep=-1;
	            $j=$i;
	            $l=0;
	            $nl++;
	            continue;
	        }
	        if($c==' ')
	            $sep=$i;
	        $l+=$cw[$c];
	        if($l>$wmax)
	        {
	            if($sep==-1)
	            {
	                if($i==$j)
	                    $i++;
	            }
	            else
	                $i=$sep+1;
	            $sep=-1;
	            $j=$i;
	            $l=0;
	            $nl++;
	        }
	        else
	            $i++;
	    }
	    return $nl;
}
	
	//*******************FIN PARA TABLAS*********************************
	
	
	    }
	
	$pdf = new myPDF("P","mm","Letter");
	$pdf->SetLeftMargin(5);
	$pdf->SetTopMargin(12);
	$pdf->SetLineWidth(0.2);
		
	$pdf->AddPage();
	

	
	$datosPersona=$persona->buscarDatosCandidato($id_persona);
//////*****************************DATOS BASICOS DE LA PERSONA**************************//////////////////////
	$pdf->SetFillColor(230,230,230);
	$pdf->Cell('',5,'DATOS BÁSICOS',0,1,'C', TRUE);
	$pdf->ln(10);
	
	//*****Nombre de la persona
	$pdf->Cell(50,-5,'Nombres:',0,1,'L');
	$pdf->Cell(20);
	$pdf->Cell(20,5,$datosPersona[0]['nombres'],0,1,'L');
	//Foto
	if ($datosPersona[0]['fotoimg'] == 1 )
	{$pdf->Image("soportes/".$datosPersona[0]['id_persona']."/fotocarnet.jpg", 165 ,40,40,40);}
	else
	{$pdf->Image("soportes/sinfoto.jpg", 165 ,40,40,40);}
	//$pdf->Image("soportes/83/fotocarnet.jpg", 165 ,40,40,40);
	$pdf->ln(6);
	
	//*****Apellidos de la persona
	$pdf->Cell(50,-5,'Apellidos:',0,1,'L');
	$pdf->Cell(20);
	$pdf->Cell(20,5,$datosPersona[0]['apellidos'],0,1,'L');
	$pdf->ln(6);
	
	//*****Cedula de la persona
	$pdf->Cell(50,-5,'Cedula:',0,1,'L');
	$pdf->Cell(20);
	$pdf->Cell(20,5,$datosPersona[0]['cedula'],0,1,'L');
	$pdf->ln(6);	
		
 	//*****Fecha de Nacim. de la persona
	$pdf->Cell(50,-5,'Fecha de Nacimiento:',0,1,'L');
	$pdf->Cell(40);
	$fechanac = explode("-",$datosPersona[0]['fechanac']);
	$pdf->Cell(20,5,$fechanac[2]."/".$fechanac[1]."/".$fechanac[0],0,1,'L');
	//$pdf->Cell(20,5,$datosPersona[0]['cedula'],0,1,'L');
	$pdf->ln(6); 	
		
	//*****Telefono1 de la persona
	if (!$datosPersona[0]['telefono1'])	{$datosPersona[0]['telefono1'] = "Sin actualizar";}
	$pdf->Cell(50,-5,'Telefono 1:',0,1,'L');
	$pdf->Cell(20);
	$pdf->Cell(20,5,$datosPersona[0]['telefono1'],0,1,'L');
	$pdf->ln(6);	
	
	//*****Telefono2 de la persona
	if (!$datosPersona[0]['telefono2'])	{$datosPersona[0]['telefono2'] = "Sin actualizar";}
	$pdf->Cell(50,-5,'Telefono 2:',0,1,'L');
	$pdf->Cell(20);
	$pdf->Cell(20,5,$datosPersona[0]['telefono2'],0,1,'L');
	$pdf->ln(6);	
	
		
	//*****Email de la persona
	$pdf->Cell(50,-5,'Email:',0,1,'L');
	$pdf->Cell(20);
	$pdf->Cell(20,5,$datosPersona[0]['email'],0,1,'L');
	$pdf->ln(6);	
			
	//*****Sexo de la persona
	if (!$datosPersona[0]['sexo'])	{$datosPersona[0]['sexo'] = "Sin actualizar";}
	$pdf->Cell(50,-5,'Sexo:',0,1,'L');
	$pdf->Cell(20);
	$pdf->Cell(20,5,$datosPersona[0]['sexo'],0,1,'L');
	$pdf->ln(6);	
			
	//*****Motricidad de la persona
	if (!$datosPersona[0]['motricidad'])	{$datosPersona[0]['motricidad'] = "Sin actualizar";}
	$pdf->Cell(50,-5,'Motricidad:',0,1,'L');
	$pdf->Cell(20);
	$pdf->Cell(20,5,$datosPersona[0]['motricidad'],0,1,'L');
	$pdf->ln(6);
	
	//*****SSO
	if (!$datosPersona[0]['estadosso'])	{$datosPersona[0]['estadosso'] = "Sin actualizar";}
	$pdf->Cell(50,-5,'SSO:',0,1,'L');
	$pdf->Cell(20);
	$pdf->Cell(20,5,$datosPersona[0]['estadosso'],0,1,'L');
	$pdf->ln(6);	
				
	//*****Ubicaionales de la persona
	//Estado
	$pdf->Cell(50,-5,'Estado:',0,1,'L');
	$pdf->Cell(20);
	$pdf->Cell(20,5,$datosPersona[0]['estado'],0,1,'L');
	$pdf->ln(6);	
	//MUNICIPIO
	$pdf->Cell(50,-5,'Municipio:',0,1,'L');
	$pdf->Cell(20);
	$pdf->Cell(20,5,$datosPersona[0]['municipio'],0,1,'L');
	$pdf->ln(6);	
	//Parroquia
	$pdf->Cell(50,-5,'Parroquia:',0,1,'L');
	$pdf->Cell(20);
	$pdf->Cell(20,5,$datosPersona[0]['parroquia'],0,1,'L');
	$pdf->ln(6);	
	
		
//////*****************************DATOS PROSEFIONALES DE LA PERSONA**************************//////////////////////
	$pdf->SetFillColor(230,230,230);
	$pdf->Cell('',5,'DATOS PROFESIONALES',0,1,'C', TRUE);
	$pdf->ln(10);
	
	//*****PROFESION de la persona
	$pdf->Cell(50,-5,'Profesión:',0,1,'L');
	$pdf->Cell(20);
	$pdf->Cell(20,5,$datosPersona[0]['profesion'],0,1,'L');
	$pdf->ln(6);
	
	//*****Fortalezas de la persona
	$pdf->Cell(50,-5,'Habilidades:',0,1,'L');
	$pdf->ln(6);
	if (!$datosPersona[0]['nombrefortaleza1'])	{$datosPersona[0]['nombrefortaleza1'] = "Sin actualizar";}
	$pdf->Cell(20,5,"1) ".$datosPersona[0]['nombrefortaleza1'],0,1,'L');
	$pdf->ln(2);
	if (!$datosPersona[0]['nombrefortaleza2'])	{$datosPersona[0]['nombrefortaleza2'] = "Sin actualizar";}
	$pdf->Cell(20,5,"2) ".$datosPersona[0]['nombrefortaleza2'],0,1,'L');
	$pdf->ln(2);
	if (!$datosPersona[0]['nombrefortaleza3'])	{$datosPersona[0]['nombrefortaleza3'] = "Sin actualizar";}
	$pdf->Cell(20,5,"3) ".$datosPersona[0]['nombrefortaleza3'],0,1,'L');
	$pdf->ln(6);	
	
//////*****************************DATOS BANCARIOS DE LA PERSONA**************************//////////////////////
	$pdf->SetFillColor(230,230,230);
	$pdf->Cell('',5,'DATOS BANCARIOS',0,1,'C', TRUE);
	$pdf->ln(10);
	
	//*****Banco
	$pdf->Cell(50,-5,'Banco:',0,1,'L');
	$pdf->Cell(13);
	$pdf->Cell(20,5,$datosPersona[0]['banco'],0,1,'L');
	$pdf->ln(6);	
	//*****Tipo de Cuenta
	$pdf->Cell(50,-5,'Tipo de Cuenta:',0,1,'L');
	$pdf->Cell(28);
	$pdf->Cell(20,5,$datosPersona[0]['tipoctabancaria'],0,1,'L');
	$pdf->ln(6);	
	//*****Nº de Cuenta
	$pdf->Cell(50,-5,'Nº de Cuenta:',0,1,'L');
	$pdf->Cell(26);
	$pdf->Cell(20,5,$datosPersona[0]['nctabnacaria'],0,1,'L');
	$pdf->ln(6);

	/*	
	
	

	//*****NOMBRE DEL PROYECTO
	$pdf->Cell(67);
	$pdf->Cell(50,-5,'Nombre del Proyecto:',0,1,'L');
	$pdf->Cell(105);
	//$pdf->Cell(50,5,'',1,1,'L');
	$pdf->Cell(0,5,$datosProyecto[0]['tx_nombre'],1,1,'L');
	
	$pdf->ln(7);
	
	//*****FECHA DE INICIO
	$pdf->Cell(50,-5,'Fecha de Inicio:',0,1,'L');
	$pdf->Cell(40);
	//$pdf->Cell(50,5,'',1,1,'L');
	$pdf->Cell(20,5,$datosProyecto[0]['fe_ini_proyecto'],1,1,'L');
	
	//*****FECHA DE CULMINACIÓN
	$pdf->Cell(65);
	$pdf->Cell(50,-5,'Fecha de Culminación:',0,1,'L');
	$pdf->Cell(105);
	//$pdf->Cell(50,5,'',1,1,'L');
	$pdf->Cell(20,5,$datosProyecto[0]['fe_culmin_proyecto'],1,1,'L');
	
	$pdf->ln(7);
	
	//*****ESTATUS DEL PROYECTO
	$pdf->Cell(50,-5,'Estatus del Proyecto:',0,1,'L');
	$pdf->Cell(40);
	$pdf->Cell(0,5,$datosProyecto[0]['tx_estatus'],1,1,'L');
	
	$pdf->ln(7);
	
	//*****MONTO TOTAL DEL PROYECTO
	$pdf->Cell(50,-5,'Monto Total del Proyecto:',0,1,'L');
	$pdf->Cell(40);
	$pdf->Cell(0,5,$datosProyecto[0]['tx_estatus'],1,1,'L');
	
	$pdf->ln(7);
	
	//*****CLASIFICACION SECTORIAL
	$pdf->Cell(50,-5,'Clasificaión Sectorial:',0,1,'L');
	$pdf->Cell(40);
	$pdf->Cell(0,5,'Sector: ',0,1,'L');
	$pdf->Cell(52);
	$pdf->Cell(25,-5,$datosProyecto[0]['tx_sector'],1,1,'L');
	$pdf->Cell(81);
	$pdf->Cell(0,5,'Sub Sector: ',0,1,'L');
	$pdf->Cell(105);
	$pdf->Cell(25,-5,$datosProyecto[0]['tx_subsector'],1,1,'L');
	
	$pdf->ln(20);
	
	//*****DESCRIPCION BREVE DEL PROYECTO
	$pdf->Cell(50,-12,'Descripción breve del Proyecto:',0,1,'L');
	$pdf->Cell(52);
	$pdf->MultiCell(0,5,$datosProyecto[0]['tx_descrip_breve_proyecto'],1,1,'L');
	
	//******************************VINCULACION CON LOS PLANES**********************
	$pdf->ln(7);
	$pdf->SetFillColor(230,230,230);
	$pdf->Cell('',5,'VINCULACIÓN CON LOS PLANES',0,1,'C', TRUE);
	$pdf->ln(10);
	
	
	//*****OBJETIVO HISTORICO
	$pdf->Cell(50,-5,'Objetivo Histórico:',0,1,'L');
	$pdf->Cell(33);
	$pdf->MultiCell(0,5,$datosProyecto[0]['tx_objetivo_historico'],1,1,'L');
	
	$pdf->ln(7);
	
	//*****OBJETIVO NACIONAL
	$pdf->MultiCell(50,-5,'Objetivo Nacional:',0,1,'L');
	$pdf->Cell(33);
	$pdf->MultiCell(0,5,$datosProyecto[0]['tx_objetivo_nacional'],1,1,'L');
	
	$pdf->ln(7);
	
	//*****OBJETIVO ESTRATEGICO
	$pdf->Cell(50,-5,'Objetivo Estratégico:',0,1,'L');
	$pdf->Cell(33);
	$pdf->MultiCell(0,5,$datosProyecto[0]['tx_objetivo_estrategico'],1,1,'L');
	
	$pdf->ln(7);
	
	//*****OBJETIVO GENERAL
	$pdf->Cell(50,-5,'Objetivo General:',0,1,'L');
	$pdf->Cell(33);
	$pdf->MultiCell(0,5,$datosProyecto[0]['tx_objetivo_general'],1,1,'L');
	
	$pdf->ln(7);
	
	//*****OBJETIVO ESTRATEGICO INSTITUCIONAL
	$textomultiline = "Institucional: \nObjetivo Estratégico";
	$pdf->MultiCell(50,-3,$textomultiline,0,1,'L');
	//$pdf->Cell(50,0,'Institucional:',0,1,'L');
	$pdf->Cell(33);
	$pdf->MultiCell(0,5,$datosProyecto[0]['tx_objetivo_estrategico_institucional'],1,1,'L');
	
	//******************************LOCALIZACION DEL PROYECTO**********************
	$pdf->ln(5);
	$pdf->SetFillColor(230,230,230);
	$pdf->Cell('',5,'LOCALIZACIÓN DEL PROYECTO',0,1,'C', TRUE);
	$pdf->ln(7);
	
	
	//*****ESTADO
	$pdf->Cell(50,-5,'Estado:',0,1,'L');
	$pdf->Cell(15);
	//$pdf->Cell(50,5,'',1,1,'L');
	$pdf->Cell(65,5,$datosUbicacion[0]['estado'],1,1,'L');
	
	//*****MUNICIPIO
	$pdf->Cell(88);
	$pdf->Cell(50,-5,'Municipio:',0,1,'L');
	$pdf->Cell(105);
	//$pdf->Cell(50,5,'',1,1,'L');
	$pdf->Cell(0,5,$datosUbicacion[0]['municipio'],1,1,'L');
	
	$pdf->ln(7);
	
	//*****CIUDAD
	$pdf->Cell(50,-5,'Ciudad:',0,1,'L');
	$pdf->Cell(15);
	//$pdf->Cell(50,5,'',1,1,'L');
	$pdf->Cell(65,5,$datosUbicacion[0]['ciudad'],1,1,'L');
	
	//*****PARROQUIA
	$pdf->Cell(88);
	$pdf->Cell(50,-5,'Parroquia:',0,1,'L');
	$pdf->Cell(105);
	//$pdf->Cell(50,5,'',1,1,'L');
	$pdf->Cell(0,5,$datosUbicacion[0]['parroquia'],1,1,'L');
	
	$pdf->ln(7);
	
	$pdf->AddPage();
	
	//******************************RESPONSABLE DEL PROYECTO**********************

	$pdf->SetFillColor(230,230,230);
	$pdf->Cell('',5,'RESPONSABLE DEL PROYECTO',0,1,'C', TRUE);
	$pdf->ln(1);
	$pdf->Cell('',5,'DECANO(A)',0,1,'C');
	$pdf->ln(5);
	//*****NOMBRE Y APELLIDOS
	$pdf->Cell(50,-5,'Nombre y Apellidos:',0,1,'L');
	$pdf->Cell(35);
	//$pdf->Cell(50,5,'',1,1,'L');
	$pdf->Cell('',5,$datosResponsable[0]['decano'],1,1,'L');

	
	$pdf->ln(7);
	
	//*****CEDULA
	$pdf->Cell(50,-5,'Cédula de Identidad:',0,1,'L');
	$pdf->Cell(35);
	//$pdf->Cell(50,5,'',1,1,'L');
	$pdf->Cell(25,5,$datosResponsable[0]['cedula_dec'],1,1,'L');
	
	//*****EMAIL
	$pdf->Cell(65);
	$pdf->Cell(50,-5,'Correo Electrónico:',0,1,'L');
	$pdf->Cell(95);
	//$pdf->Cell(50,5,'',1,1,'L');
	$pdf->Cell(0,5,$datosResponsable[0]['email_dec'],1,1,'L');
	
	$pdf->ln(10);
	
	//******************************REGISTRADOR**********************

	$pdf->Cell('',5,'REGISTRADOR (DELEGACIÓN DE PLANIFICACIÓN)',0,1,'C');
	$pdf->ln(7);
	
	
	//*****NOMBRE Y APELLIDOS
	$pdf->Cell(50,-5,'Nombre y Apellidos:',0,1,'L');
	$pdf->Cell(35);
	//$pdf->Cell(50,5,'',1,1,'L');
	$pdf->Cell('',5,$datosResponsable[0]['delegado'],1,1,'L');

	
	$pdf->ln(7);
	
	//*****CEDULA
	$pdf->Cell(50,-5,'Cédula de Identidad:',0,1,'L');
	$pdf->Cell(35);
	//$pdf->Cell(50,5,'',1,1,'L');
	$pdf->Cell(37,5,$datosResponsable[0]['cedula_del'],1,1,'L');
	
	//*****EMAIL
	$pdf->Cell(75);
	$pdf->Cell(50,-5,'Correo Electrónico:',0,1,'L');
	$pdf->Cell(105);
	//$pdf->Cell(50,5,'',1,1,'L');
	$pdf->Cell(0,5,$datosResponsable[0]['email_del'],1,1,'L');
	
	$pdf->ln(7);
	
	//*****NUMEROS TELEFONICOS
	$pdf->Cell(50,-5,'Números Telefónicos:',0,1,'L');
	$pdf->Cell(35);
	$pdf->Cell(0,5,'Oficina: ',0,1,'L');
	$pdf->Cell(47);
	$pdf->Cell(25,-5,$datosResponsable[0]['telefono_del'],1,1,'L');
	$pdf->Cell(91);
	$pdf->Cell(0,5,'Celular: ',0,1,'L');
	$pdf->Cell(105);
	$pdf->Cell(25,-5,$datosResponsable[0]['telefono_del'],1,1,'L');
	
	
	$pdf->AddPage();
	
	//******************************ALCANCE**********************
	$pdf->SetFillColor(230,230,230);
	$pdf->Cell('',5,'ALCANCE E IMPACTO DEL PROYECTO',0,1,'C', TRUE);
	$pdf->ln(10);
	
	$pdf->SetWidths(array(30,70,30,70));
	$pdf->Row(array('Enunciado del Problema o Necesidad',$datosProyecto[0]['tx_enunciado_problema'],'Enunciado de la Situacion deseada',$datosProyecto[0]['tx_enunciado_situacion_deseada']));
	$pdf->Row(array('Poblacion Afectada',$datosProyecto[0]['tx_poblacion_afectada'],'Poblacion Objetivo',$datosProyecto[0]['tx_poblacion_objetivo']));
	$pdf->Row(array('Indicador de la Situacion Actual',$datosProyecto[0]['tx_ind_situacion_actual'],'Indicador de la Situacion Deseada',$datosProyecto[0]['tx_ind_situacion_deseada']));
	$pdf->Row(array('Formula del Indicador',$datosProyecto[0]['tx_formula_indicador'],'Resultado esperado (Bien o Servicio)',$datosProyecto[0]['tx_resultado_esperado']));
	/***********--------------*****************---------------------------************************----------

	//$pdf->Cell(0,'<table><tr><td>',0,1,J);
	//*****ENUNCIADO DEL PROBLEMA
	$textomultiline = "necesidad:\nProblema o\nEnunciado del";
	$pdf->MultiCell(50,-5,$textomultiline,0,1,'R');
	//$pdf->Cell(50,0,'Institucional:',0,1,'L');
	$pdf->Cell(24);
	$pdf->MultiCell(75,4,$datosProyecto[0]['tx_enunciado_problema'],1,1,'J');
	//$pdf->Cell(0,'</td><td>',0,1,J);
	//*****ENUNCIADO SITUACION DESEADA
	$pdf->Cell(100);
	//$textomultiline = "deseada:\nsituación o\nEnunciado de la";
	$textomultiline = "Enunciado de la:\nsituación \ndeseada:";
	$pdf->MultiCell(50,5,$textomultiline,0,1,'R');
	//$pdf->Cell(50,0,'Institucional:',0,1,'L');
	$pdf->Cell(125);
	$pdf->MultiCell(75,4,$datosProyecto[0]['tx_enunciado_situacion_deseada'],1,1,'J');
	//***********--------------*****************---------------------------************************----------
	

	//$pdf->ln(15);
	/***********--------------*****************---------------------------************************----------
	//*****POBLACION AFECTADA
	$textomultiline = "Afectada\nPoblación";
	$pdf->MultiCell(50,-3,$textomultiline,0,1,'R');
	//$pdf->Cell(50,0,'Institucional:',0,1,'L');
	$pdf->Cell(24);
	$pdf->MultiCell(75,10,$datosProyecto[0]['tx_poblacion_afectada'],1,1,'J');
	
	//*****POBLACION OBJETIVO
	$pdf->Cell(100);
	$textomultiline = "Objetivo\nPoblación";
	$pdf->MultiCell(50,-4,$textomultiline,0,1,'R');
	//$pdf->Cell(50,0,'Institucional:',0,1,'L');
	$pdf->Cell(125);
	$pdf->MultiCell(75,10,$datosProyecto[0]['tx_poblacion_objetivo'],1,1,'J');
	//***********--------------*****************---------------------------************************----------
	
	$pdf->ln(30);
	 //***********--------------*****************---------------------------************************----------
	 //*****INDICADOR DEL PROBLEMA ACTUAL
	$textomultiline = "Actual:\nla Situación\nIndicador de";
	$pdf->MultiCell(50,-4,$textomultiline,0,1,'R');
	//$pdf->Cell(50,0,'Institucional:',0,1,'L');
	$pdf->Cell(24);
	$pdf->MultiCell(75,4,$datosProyecto[0]['tx_ind_situacion_actual'],1,1,'J');
	
	//*****INDICADOR SITUACION DESEADA
	$pdf->Cell(100);
	$textomultiline = "deseada:\nla Situación\nIndicador de";
	$pdf->MultiCell(50,-4,$textomultiline,0,1,'R');
	//$pdf->Cell(50,0,'Institucional:',0,1,'L');
	$pdf->Cell(125);
	$pdf->MultiCell(75,4,$datosProyecto[0]['tx_ind_situacion_deseada'],1,1,'J');
	//***********--------------*****************---------------------------************************----------
	
	$pdf->ln(15);
	 //***********--------------*****************---------------------------************************----------
	 //*****FORMULA DEL INDICADOR
	$textomultiline = "\nIndicador:\nFormula del";
	$pdf->MultiCell(50,-4,$textomultiline,0,1,'R');
	//$pdf->Cell(50,0,'Institucional:',0,1,'L');
	$pdf->Cell(24);
	$pdf->MultiCell(75,4,$datosProyecto[0]['tx_formula_indicador'],1,1,'J');
	
	//*****RESULTADO DESEADO
	$pdf->Cell(100);
	$textomultiline = "o Servicio):\nEsperado (Bien\nResultado ";
	$pdf->MultiCell(50,-4,$textomultiline,0,1,'R');
	//$pdf->Cell(50,0,'Institucional:',0,1,'L');
	$pdf->Cell(125);
	$pdf->MultiCell(75,11,$datosProyecto[0]['tx_resultado_esperado'],1,1,'J');
	//***********--------------*****************---------------------------************************----------
	
	$pdf->ln(15);
	 //***********--------------*****************---------------------------************************----------
	 //*****FUENTE DEL INDICADOR
	$textomultiline = "\nIndicador:\nFuente del";
	$pdf->MultiCell(50,-4,$textomultiline,0,1,'R');
	//$pdf->Cell(50,0,'Institucional:',0,1,'L');
	$pdf->Cell(24);
	$pdf->MultiCell(75,11,$datosProyecto[0]['tx_fuente_indicador'],1,1,'J');
	
	//*****UNIDAD DE MEDIDA
	$pdf->Cell(100);
	$textomultiline = "\nMedida:\nUnidad de";
	$pdf->MultiCell(50,-4,$textomultiline,0,1,'R');
	//$pdf->Cell(50,0,'Institucional:',0,1,'L');
	$pdf->Cell(125);
	$pdf->MultiCell(75,12,$datosProyecto[0]['tx_unidad_medida'],1,1,'J');
	//***********--------------*****************---------------------------************************----------
	
	$pdf->ln(15);
	 //***********--------------*****************---------------------------************************----------
	 //*****FECHA DEL INDICADOR SITUACION INICIAL
	$textomultiline = "Situación actual:\nIndicador de la\nFecha del";
	$pdf->MultiCell(50,-4,$textomultiline,0,1,'R');
	//$pdf->Cell(50,0,'Institucional:',0,1,'L');
	$pdf->Cell(24);
	$pdf->MultiCell(75,11,$datosProyecto[0]['fe_indicador_situacion_inicial'],1,1,'J');
	
	//*****META PRYECTO
	$pdf->Cell(100);
	$textomultiline = "\nProyecto:\nMeta del";
	$pdf->MultiCell(50,-4,$textomultiline,0,1,'R');
	//$pdf->Cell(50,0,'Institucional:',0,1,'L');
	$pdf->Cell(125);
	$pdf->MultiCell(75,12,$datosProyecto[0]['tx_meta_proyecto'],1,1,'J');
	//***********--------------*****************---------------------------************************----------
	//$pdf->ln(30);
	//******************************BENEFICIARIOS **********************
	$pdf->ln(5);
	$pdf->SetFillColor(230,230,230);
	$pdf->Cell('',5,'BENEFICIARIOS ESTIMADOS',0,1,'C', TRUE);
	$pdf->ln(10);
	
	
	//*****TOTAL BENEFICIARIOS
	//$pdf->Cell(24);
	$pdf->Cell(50,-5,'Total beneficiarios:',0,1,'L');
	$pdf->Cell(30);
	//$pdf->Cell(50,5,'',1,1,'L');
	$pdf->Cell(69,5,$datosFicha[0]['nu_ben_total'],1,1,'L');
	
	

	//*****TOTAL BENEFICIARIOS MASCULNOS
	$pdf->Cell(110);
	$pdf->Cell(30,-5,'Total Masculinos:',0,1,'L');
	$pdf->Cell(137);
	$pdf->Cell('',5,$datosFicha[0]['nu_ben_mas'],1,1,'L');
	
	$pdf->ln(7);
		//*****TOTAL BENEFICIARIOS FEMENINOS
	$pdf->Cell(110);
	$pdf->Cell(30,-5,'Total Femeninos:',0,1,'L');
	$pdf->Cell(137);
	$pdf->Cell('',5,$datosFicha[0]['nu_ben_fem'],1,1,'L');
	

	//*****DENOMINACIÓN BENEFICIARIOS
	//$pdf->Cell(24);
	//$textomultiline = "\nlos beneficiarios:\nDenominación de";
	//$pdf->MultiCell(50,-5,$textomultiline,0,1,'R');
	$pdf->Cell(50,-5,'Denominación de los beneficiarios:',0,1,'L');
	//$pdf->Cell(40);
	$pdf->ln(5);
	//$pdf->Cell(50,5,'',1,1,'L');
	$pdf->Cell(1.2);
	$pdf->MultiCell(99,15,$datosFicha[0]['tx_denominacion'],1,1,'L');
	

	
	
	//******************************POSIBLES OBSTACULOS DEL PROYECTO **********************
	$pdf->ln(5);
	$pdf->SetFillColor(230,230,230);
	$pdf->Cell('',5,'POSIBLES OBSTÁCULOS DEL PROYECTO',0,1,'C', TRUE);
	$pdf->ln(10);
	

	$pdf->Cell(50,-5,'Cuáles serían los posibles obstáculos para la ejecucuión del Proyecto? Especifíque:',0,1,'J');
	$pdf->ln(7);
	//$pdf->Cell(50,5,'',1,1,'L');
	$pdf->MultiCell('',20,$datosFicha[0]['tx_obstaculos'],1,1,'J');
	*/
	$pdf->Output();
?>
	
