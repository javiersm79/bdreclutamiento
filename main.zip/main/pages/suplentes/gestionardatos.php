<?php
include ("../../include/seg/security.php");
?>

<html>
	<head>
		<meta charset="UTF-8">
		<title>SuplenciasUDO</title>
		<!-- Tell the browser to be responsive to screen width -->
		<meta>
		<!-- Bootstrap 3.3.5 -->
		<link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
		<!-- jquery-ui -->
		<link rel="stylesheet" href="../../include/css/jquery-ui-smoothness.css">
		<!-- Font Awesome -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
		<!-- Ionicons ******** Utilizar en el futuro para cargar iconos locales*************
		<link rel="stylesheet" href="include/themes/ionicons/css/ionicons.min.css">-->

		<!-- fancybox iframe -->
		<link rel="stylesheet" href="../../plugins/fancybox/jquery.fancybox.css?v=2.1.5" media="screen">
		<!-- Theme style -->
		<link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">
		<!-- AdminLTE Skins. We have chosen the skin-blue for this starter
		page. However, you can choose any other skin. Make sure you
		apply the skin class to the body tag so the changes take effect.
		-->
		<link rel="stylesheet" href="../../dist/css/skins/skin-blue.min.css">
		<!-- Bootstraps Dialog -->
		<link rel="stylesheet" href="../../plugins/bootstrap-dialog/bootstrap-dialog.min.css">
		<!-- Select2 -->
		<link rel="stylesheet" href="../../plugins/select2/select2.min.css">
		
		
		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

	</head>
<?php

//print_r($_SESSION);

?>
	<body class="skin-blue layout-top-nav">
		<div class="wrapper" >

			<!-- Main Header -->
			<header class="main-header">
			    <nav class="navbar navbar-static-top">
	
						<div class="navbar-header">
						  <!-- <span class="navbar-brand"><b>Suplencias</b>UDO</span> -->
						  <a href="#" class="logo"><img style="float:left; margin-top: 10" src="../../include/img/logo_udo_min.jpg" class="img-circle" height="30" width="30"/> <span class="logo-lg"><b>Suplencias</b>UDO</span> </a>
						 
						</div>

					<!-- Navbar Right Menu -->
					<div class="navbar-custom-menu">
						<ul class="nav navbar-nav">

							<!-- Salir del sistema -->
							<li>
								<a href="logout.php"><i class="fa fa-sign-out"></i>&nbsp;Cerrar Sesi&oacute;n</a>
							</li>
						</ul>
					</div>
				</nav>
			</header>
			
			<!-- Content Wrapper. Contains page content -->
			<div class="content-wrapper">
				<!-- Content Header (Page header) -->
				<section class="content-header">
					<h1> Gestión de datos <small>Datos de candidatos a suplentes</small></h1>
					
					<!-- <input type="text" name="id_persona" id="id_persona" value="<?php //echo $_SESSION['id_persona']?>"/> -->
				</section>

				<!-- Main content -->
				<section class="content" >

					<div id="botoneraHeader" style="right: 15px; position: absolute;">

					</div>


					<div class="box">

						<div class="box-body">

							<!-- Horizontal Form
							<div class="box box-info">
							<div class="box-header with-border">
							<h3>Ingresar datos del suplente</h3>
							</div><!-- fin header
							</div><!-- /.box info-->
							<div class="nav-tabs-custom" id="nvoSupTabs">
								<ul class="nav nav-tabs">
									<li class="active" id="tabDatos">
										<a data-toggle="tab" href="#datos">Datos</a>
									</li>
									<li id="tabSoportes" title="">
										<a data-toggle="tab" href="#adjuntos">Soportes</a>
									</li>
									<div id="botonActClave" style="float: right; width: 120px;">
										<button id="btnActClave" class="btn btn-block btn-success" onclick="actualizarClave()">
											Cambiar Clave
										</button>
									</div>
									<div id="botonImprimir" style="float: right; width: 120px;">
										<a href="pdfFichaPersonaExt.php" id="btnImprimirFicha" class="btn btn-default" target="blank"><i class="fa fa-print"></i> Imprimir</a>
									</div>
								</ul>
							</div>
							<div class="tab-content">
								<div id="datos" class="tab-pane fade in active">
									<br/>

									<!-- form start -->
									<form id="frmDatosSuplentes" class="form-horizontal">
										<!-- Estatus -->
										<div class="form-group" id="grupoEstatus">
											<label class="col-sm-2 control-label">Estatus</label>
											<div class="col-sm-6" id="estatusCandidato">
												<!-- <label id="infovalido" class="control-label label-warning" style="text-align:left">&nbsp;&nbsp; Existen datos sin cargar.. Favor verificar &nbsp;&nbsp;</label> -->
												
											</div>
										</div>
										
										<!-- Nucleo -->
										<div class="form-group" id="grupoNucleo">
											<label for="nucleo" class="col-sm-2 control-label">N&uacute;cleo <br/>(Donde aspira trabajar)</label>
											<div class="col-sm-2">

													<select id="nucleo" name="nucleo" class="form-control">
														<option value="0" selected>Seleccionar</option>
														<option value="Anzoategui" >Anzoategui</option>
														<option value="Bolívar">Bolívar</option>
														<option value="Monagas">Monagas</option>
														<option value="Nva. Esparta" >Nva. Esparta</option>
														<option value="Sucre">Sucre</option>
														<option value="Rectorado">Rectorado</option>
													</select>

											</div>
											<!-- <pre class="col-sm-4 text-muted">Seleccione el núcleo donde aspira trabajar</pre> -->
											
											
											
										</div>
										
										
										<!-- Profesion del Suplente -->
										<div class="form-group" id="grupoProfesion">
											<label for="profesion" class="col-sm-2 control-label">T&iacute;tulos</label>
											<div class="col-sm-6">
												<div class="input-group">
													<input type="text" class="form-control" id="profesionsuplente" name="profesionsuplente" placeholder="Ej: Licenciado en Condauría Pública "/>
													<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-font"></i></span>
												</div>
											</div>
										</div>
										
										<!-- Sexo del Suplente -->
										<div class="form-group" id="grupoSexo">
											<label for="sexo" class="col-sm-2 control-label">Sexo</label>
											<div class="col-sm-4" >

												<select id="sexo" name="sexo" class="form-control">
													<option value="0" selected>Seleccione</option>
													<option value="Femenino">Femenino</option>
													<option value="Masculino">Masculino</option>
												</select>

											</div>

										</div>

										<!-- Motricidad-->
										<div class="form-group" id="grupoMotricidad">
											<label for="motricidad" class="col-sm-2 control-label">Motricidad</label>
											<div class="col-sm-4">
												<select id="motricidad" name="motricidad" class="form-control">
													<option value="0" selected>Seleccione</option>
													<option value="Izquierda">Izquierda</option>
													<option value="Derecha">Derecha</option>
												</select>
											</div>
										</div>
										
										<!-- Fecha de Nacimiento del Suplente -->
										<div class="form-group" id="grupoFechaNac">
											<label for="fechanacimiento" class="col-sm-2 control-label">Fecha de Nacimiento</label>
											<div class="col-sm-4">
												<div class="input-group">
													<input type="text" class="form-control input-date" id="fechanacsuplente" name="fechanacsuplente" />
													<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-calendar"></i></span>
												</div>
											</div>
										</div>
										
										<!-- Nombres del Suplente -->
										<div class="form-group" id="grupoNombres">
											<label for="nombres" class="col-sm-2 control-label">Nombres</label>
											<div class="col-sm-6">
												<div class="input-group">
													<input type="text" class="form-control" id="nombresuplente" name="nombresuplente" placeholder=" " disabled />
													<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-font"></i></span>
												</div>
											</div>
										</div>

										<!-- Apellidos del Suplente -->
										<div class="form-group" id="grupoApellidos">
											<label for="apellidos" class="col-sm-2 control-label">Apellidos</label>
											<div class="col-sm-6">
												<div class="input-group">
													<input type="text" class="form-control" id="apellidossuplente" name="apellidossuplente" placeholder=" " disabled />
													<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-font"></i></span>
												</div>

											</div>
										</div>

										<!-- Cedula del Suplente -->
										<div class="form-group" id="grupoCedula">
											<label for="cedula" class="col-sm-2 control-label">C&eacute;dula</label>
											<div class="col-sm-2" style="width: 110px">

												<select id="precedula" name="precedula" class="form-control" disabled>
													<option value="V">V</option>
													<option value="E">E</option>
												</select>

											</div>
											<div class="col-sm-2" style="width: 243px">

												<div class="input-group" id="grupoCedula">
													<input type="text" class="form-control numeric" id="cedulasuplente" name="cedulasuplente" placeholder="Ej: 12345678" disabled>
													<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-sort-numeric-asc"></i></big></span>
												</div>
											</div>
										</div>
									
										
										<!-- Estado -->
										<div class="form-group" id="grupoEstado">
											<label for="apellidos" class="col-sm-2 control-label">Estado</label>
											<div class="col-sm-6">
												<div class="input-group">
													<input class="form-control" id="estadosuplente" name="estadoasuplente" placeholder="Ej: Sucre" disabled />
													<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-font"></i></span>
												</div>
											</div>
										</div>
										
										<!-- Municipio -->
										<div class="form-group" id="grupoMunicipio">
											<label for="apellidos" class="col-sm-2 control-label">Municipio</label>
											<div class="col-sm-6">
												<div class="input-group">
													<input class="form-control" id="municipiosuplente" name="municipiosuplente" placeholder="Ej: San Juan" disabled />
													<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-font"></i></span>
												</div>
											</div>
										</div>
										
										<!-- Parroquia -->
										<div class="form-group" id="grupoParroquia">
											<label for="apellidos" class="col-sm-2 control-label">Parroquia</label>
											<div class="col-sm-6">
												<div class="input-group">
													<input class="form-control" id="parroquiasuplente" name="parroquiasuplente" placeholder="Ej: Valentín Valiente" disabled />
													<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-font"></i></span>
												</div>
											</div>
										</div>
										
										<!-- Email -->
										<div class="form-group" id="grupoEmail">
											<label for="apellidos" class="col-sm-2 control-label">Email</label>
											<div class="col-sm-6">
												<div class="input-group">
													<input class="form-control" id="emailsuplente" name="emailsuplente" placeholder="Ej: suplencia@udo.edu.ve" />
													<span class="input-group-addon" style="background: #f0f0f0"><i class="fa fa-font"></i></span>
												</div>
											</div>
										</div>	
										<!-- Telf Principal del Suplente -->
										<div class="form-group" id="grupoTlf1">
											<label for="telefono1" class="col-sm-2 control-label">Telf. Principal</label>
											<div class="col-sm-4" >
												<div class="input-group">
													<input type="text" id="telefono1" name="telefono1" class="form-control" data-inputmask='"mask": "(9999) 999-9999"' data-mask>
													<span class="input-group-addon" style="background: #f0f0f0">☎</span>
												</div>
											</div>
										</div>
										<!-- Telf Adicional del Suplente -->
										<div class="form-group" id="grupoTlf2">
											<label for="telefono2" class="col-sm-2 control-label">Telf. Seundario</label>
											<div class="col-sm-4" >
												<div class="input-group">
													<input type="text" id="telefono2" name="telefono2" class="form-control" data-inputmask='"mask": "(9999) 999-9999"' data-mask>
													<span class="input-group-addon" style="background: #f0f0f0">☎</span>
												</div>
											</div>
										</div>

										<!-- CARGOS -->
										<div class="form-group" id="grupoCargos">
											<label class="col-sm-2 control-label">Cargos</label>
											<div class="col-sm-6" >
												<div class="panel panel-default">
													<div class="panel-heading">Seleccione tres (3) cargos en los cuales quiera desempe&ntilde;arse</div>
													<div class="panel-body">
														<select id="fortaleza1" name="fortaleza1" class="form-control fortalezas">
															<option value=0 selected>Seleccione</option>
														</select><br/><br/>
														<select id="fortaleza2" name="fortaleza2" class="form-control fortalezas">
															<option value=0 selected>Seleccione</option>
														</select><br/><br/>
														<select id="fortaleza3" name="fortaleza3" class="form-control fortalezas">
															<option value=0 selected>Seleccione</option>
														</select>
													</div>
		
												</div>
											</div>
										</div>
										
										<!-- Banco -->
										<div class="form-group" id="grupoBanco">
											<label for="fortaleza1" class="col-sm-2 control-label">Banco</label>
											<div class="col-sm-6" >
												<div class="panel panel-default">
													<div class="panel-heading">Registre su información bancaria</div>
													<div class="panel-body">
													
														<label for="banco" class="control-label">Nombre del banco</label>
														<select name="banco" id="banco" class="form-control banco">
															<option value="0" selected>Seleccione</option>
															<option value="100%BANCO">100%BANCO</option>
															<option value="ABN AMRO BANK">ABN AMRO BANK</option>
															<option value="BANCAMIGA BANCO MICROFINANCIERO, C.A.">BANCAMIGA BANCO MICROFINANCIERO, C.A.</option>
															<option value="BANCO ACTIVO BANCO COMERCIAL, C.A.">BANCO ACTIVO BANCO COMERCIAL, C.A.</option>
															<option value="BANCO AGRICOLA">BANCO AGRICOLA</option>
															<option value="BANCO BICENTENARIO">BANCO BICENTENARIO</option>
															<option value="BANCO CARONI, C.A. BANCO UNIVERSAL">BANCO CARONI, C.A. BANCO UNIVERSAL</option>
															<option value="BANCO DE DESARROLLO DEL MICROEMPRESARIO">BANCO DE DESARROLLO DEL MICROEMPRESARIO</option>
															<option value="BANCO DE VENEZUELA S.A.I.C.A.">BANCO DE VENEZUELA S.A.I.C.A.</option>
															<option value="BANCO DEL CARIBE C.A.">BANCO DEL CARIBE C.A.</option>
															<option value="BANCO DEL PUEBLO SOBERANO C.A.">BANCO DEL PUEBLO SOBERANO C.A.</option>
															<option value="BANCO DEL TESORO">BANCO DEL TESORO</option>
															<option value="BANCO ESPIRITO SANTO, S.A.">BANCO ESPIRITO SANTO, S.A.</option>
															<option value="BANCO EXTERIOR C.A.">BANCO EXTERIOR C.A.</option>
															<option value="BANCO INDUSTRIAL DE VENEZUELA.">BANCO INDUSTRIAL DE VENEZUELA.</option>
															<option value="BANCO INTERNACIONAL DE DESARROLLO, C.A.">BANCO INTERNACIONAL DE DESARROLLO, C.A.</option>
															<option value="BANCO MERCANTIL C.A.">BANCO MERCANTIL C.A.</option>
															<option value="BANCO NACIONAL DE CREDITO">BANCO NACIONAL DE CREDITO</option>
															<option value="BANCO PLAZA">BANCO OCCIDENTAL DE DESCUENTO.</option>
															<option value="aqui">BANCO PLAZA</option>
															<option value="BANCO PROVINCIAL BBVA">BANCO PROVINCIAL BBVA</option>
															<option value="BANCO VENEZOLANO DE CREDITO S.A.">BANCO VENEZOLANO DE CREDITO S.A.</option>
															<option value="BANCRECER S.A. BANCO DE DESARROLLO">BANCRECER S.A. BANCO DE DESARROLLO</option>
															<option value="BANESCO">BANESCO</option>
															<option value="BANGENTE">BANGENTE</option>
															<option value="BANFANB">BANFANB</option>
															<option value="BANPLUS BANCO COMERCIAL C.A">BANPLUS BANCO COMERCIAL C.A</option>
															<option value="CITIBANK">CITIBANK</option>
															<option value="DELSUR BANCO UNIVERSAL">DELSUR BANCO UNIVERSAL</option>
															<option value="FONDO COMUN">FONDO COMUN</option>
															<option value="INSTITUTO MUNICIPAL DE CRÉDITO POPULAR">INSTITUTO MUNICIPAL DE CRÉDITO POPULAR</option>
															<option value="MIBANCO BANCO DE DESARROLLO, C.A.">MIBANCO BANCO DE DESARROLLO, C.A.</option>
															<option value="SOFITASA">SOFITASA</option>
														</select><br/>
														<label for="banco" class="control-label">Tipo de cuenta</label>
														<select id="tipoctabancaria" name="tipoctabancaria" class="form-control banco">
															<option value="0" selected>Seleccione</option>
															<option value="Corriente">Corriente</option>
															<option value="Ahorro">Ahorro</option>
														</select><br/>
														<label for="nctabnacaria" class="control-label">Número de Cuenta</label>
														<input class="form-control" id="nctabnacaria" name="nctabnacaria" placeholder="" data-inputmask='"mask": "9999-9999-99-9999999999"' data-mask/><br/>
													</div>
		
												</div>
											</div>
										</div>
									</form>
									
									<div class="box-footer">
										<div class="btn-group">
											<button id="btnGuardar"class="btn btn-block btn-primary" style="width: 100px;">
												Guardar
											</button>
											
												<!--<div id="msgFooterDatos" style="position: absolute; left:110px; width: 700px; height: 10px">
											<button id="excelBut"class="btn btn-block btn-success" style="width: 100px; " onclick="window.open('tablepg2.php','_blank');">Excel</button>
											
											<button id="enviarBut" class="btn btn-block btn-danger" style="width: 100px; ">Enviar</button>
											</div>-->

										</div>

									</div><!-- /.box-footer -->
									
								</div><!-- Fin del tab "DATOS" -->

								<!-- tab "ADJUNTOS" -->
								<div id="adjuntos" class="tab-pane fade">
									<!-- <h3>Adjuntar documentaci&oacute;n</h3> -->
									<br/>

									<div class="box box-info">
										<div class="box-header with-border">
											<!-- Grupo Superior -->
											<div class="form-group">
												<!-- Foto Carnet -->
												<div class="col-sm-6">
													<label for="imgfoto" class="col-sm-2 control-label">Foto Carnet</label>
													<div class="col-sm-4">
														<form id="formFotoCarnet" name="formFotoCarnet" class="form-horizontal">
															<input name="campo" type="hidden" value="fotoimg">
															<input name="nombrearchivo" type="hidden" value="fotocarnet">
															<input name="id_persona" type="hidden" value="<?php echo $_SESSION["id_persona"]; ?>">
															<input name="archivo" id="imgfoto" type="file" style="width: 350px">
															<p class="help-block">
																Formato: .jpg - tama&ntilde;o m&aacute;ximo: 2Mb
															</p>
															<div class="progress">
																<div id="progFoto" class=""></div>
															</div>
															<input type="button" value="Cargar" id="btnImgFoto"/>
															<input id="verImgFoto" class="verImg fancybox.iframe" type="button" value="Ver" href="" />

														</form>
													</div>
												</div>
												<!-- Fin de Foto Carnet -->											
												<!-- Cedula -->
												<div class="col-sm-6">
													<label for="cedula" class="col-sm-2 control-label">C&eacute;dula</label>
													<div class="col-sm-4">
														<form id="formCedula" class="form-horizontal">
															<input name="campo" type="hidden" value="cedulaimg">
															<input name="nombrearchivo" type="hidden" value="cedula">
															<input name="id_persona" type="hidden" value="<?php echo $_SESSION["id_persona"]; ?>">															
															<input name="archivo" id="imgcedula" type="file">
															<p class="help-block">
																Formato: .jpg - tama&ntilde;o m&aacute;ximo: 2Mb
															</p>
															<div class="progress">
																<div id="progCedula" class=""></div>
															</div>
															<input type="button" value="Cargar" id="btnImgCed"/>
															<input id="verImgCedula"class="verImg fancybox.iframe" type="button" value="Ver" href="" />
														</form>
													</div>
												</div>
												<!-- Fin de Cedula -->
											</div>
											<!-- /.form-group-superior -->											
											
											<h1>&nbsp;<hr></h1>
																					
											<!-- Grupo Middle -->
											<div class="form-group">
												<!-- Certificado de Salud -->
												<div class="col-sm-6">
													<label for="titulo" class="col-sm-2 control-label">Certificado de Salud</label>
													<div class="col-sm-4">
														<form id="formSalud" class="form-horizontal">
															<input name="campo" type="hidden" value="saludimg">
															<input name="nombrearchivo" type="hidden" value="certificado_salud">
															<input id="id_persona" name="id_persona" type="hidden" value="<?php echo $_SESSION["id_persona"]; ?>">															
															<input name="archivo" id="imgsalud" type="file" style="width: 350px">
															<p class="help-block">
																Formato: .jpg - tama&ntilde;o m&aacute;ximo: 2Mb
															</p>
															<div class="progress">
																<div id="progSalud" class=""></div>
															</div>
															<input type="button" value="Cargar" id="btnImgSalud"/>
															<input id="verImgSalud" class="verImg fancybox.iframe" type="button" value="Ver" href="" />
														</form>
													</div>
												</div>
												<!-- Fin del Certificado de Salud -->

												<!-- Cta Bancaria -->
												<div class="col-sm-6">
													<label for="imgBanco" class="col-sm-2 control-label">Cta. Bancaria</label>
													<div class="col-sm-4">
														<form id="formBanco" class="form-horizontal">
															<input name="campo" type="hidden" value="bancoimg">
															<input name="nombrearchivo" type="hidden" value="cta_bancaria">
															<input name="id_persona" type="hidden" value="<?php echo $_SESSION["id_persona"]; ?>">														
															<input name="archivo" id="imgBanco" type="file" style="width: 350px">
															<p class="help-block">
																Formato: .pdf - tama&ntilde;o m&aacute;ximo: 2Mb
															</p>
															<div class="progress">
																<div id="progBanco" class=""></div>
															</div>
															<input type="button" value="Cargar" id="btnImgBco"/>
															<input id="verImgBanco"  class="verImg fancybox.iframe" type="button" value="Ver" href="" />
															
														</form>
													</div>
												</div>
												<!-- Fin del Curriculum -->
											</div>
											<!-- /.form-group-Middle -->
											<h1>&nbsp;<hr></h1>
											
											<!-- Grupo Inferior -->
											<div class="form-group">
												<!-- Titulo -->
												<div class="col-sm-6">
													<label for="titulo" class="col-sm-2 control-label">T&iacute;tulo (Fondo negro)</label>
													<div class="col-sm-4">
														<form id="formTitulo" class="form-horizontal">
															<input name="campo" type="hidden" value="tituloimg">
															<input name="nombrearchivo" type="hidden" value="titulo">
															<input name="id_persona" type="hidden" value="<?php echo $_SESSION["id_persona"]; ?>">
															<input name="archivo" id="imgtitulo" type="file" style="width: 350px">
															<p class="help-block">
																Formato: .jpg - tama&ntilde;o m&aacute;ximo: 2Mb
															</p>
															<div class="progress">
																<div id="progTitulo" class=""></div>
															</div>
															<input type="button" value="Cargar" id="btnImgTit"/>
															<input id="verImgTitulo" class="verImg fancybox.iframe" type="button" value="Ver" href="" />
														</form>
													</div>
												</div>
												<!-- Fin del Titulo -->

												<!-- Curriculum -->
												<div class="col-sm-6">
													<label for="pdfcurriculum" class="col-sm-2 control-label">Curriculum Vitae</label>
													<div class="col-sm-4">
														<form id="formCurriculum" class="form-horizontal">
															<input name="campo" type="hidden" value="curriculumpdf">
															<input name="nombrearchivo" type="hidden" value="curriculum">
															<input name="id_persona" type="hidden" value="<?php echo $_SESSION["id_persona"]; ?>">
															<input name="archivo" id="pdfcurriculum" type="file" style="width: 350px">
															<p class="help-block">
																Formato: .pdf - tama&ntilde;o m&aacute;ximo: 5Mb
															</p>
															<div class="progress">
																<div id="progCV" class=""></div>
															</div>
															<input type="button" value="Cargar" id="btnPdfCV"/>
															
															<!-- <input id="verCV" type="button" href="" style="width:" ><a id="verCV" href="" download></a></input> -->
															<input id="verCV" class="verImg fancybox.iframe" class="verImg fancybox.iframe" type="button" value="Ver" href="" />
														</form>
													</div>
												</div>
												<!-- Fin del Curriculum -->
											</div>
											<!-- /.form-group-inferior -->

										</div><!-- /.box-header-->
									</div><!-- /.box-info -->

								</div><!-- Fin del tab "Adjuntos" -->

							</div><!-- /.tab-content -->

						</div><!-- /.box-body -->

						<div class="box-footer">

							<!-- <button type="submit" class="btn btn-info pull-right">Sign in</button> -->

						</div><!-- /.box-footer -->

					</div><!-- /.box -->

				</section><!-- /.content -->
			</div><!-- /.content-wrapper -->

			<!-- Main Footer -->
			<footer class="main-footer">
				<!-- To the right -->
				<div class="pull-right hidden-xs">
					Web Master - Lcdo. Javier Salazar Marcano
				</div>
				<!-- Default to the left -->
				<strong>Copyright &copy; 2015 <a href="#">Universidad de Oriente</a>.</strong> Todos los Derechos Reservados.
			</footer>

		</div><!-- ./wrapper -->

		<!-- Cuadros de dialogos -->
		<div id="dialogo" title="Aviso"></div>
		<div id="resultado" title="Personal de Suplencia Registrado"></div>

		<!-- REQUIRED JS SCRIPTS -->

		<!-- jQuery 2.1.4 -->
		<script src="../../plugins/jQuery/jQuery-2.1.4.min.js"></script>
		<!-- Bootstrap 3.3.5 -->
		<script src="../../bootstrap/js/bootstrap.min.js"></script>
		<!-- JS Javier -->
		<script src="../../include/js/ui.js"></script>
		<!-- DataTables -->
		<script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
		<script src="../../plugins/datatables/dataTables.bootstrap.min.js"></script>
		<script src="../../plugins/datatables/TableTools.min.js"></script>
		<script src="../../plugins/datatables/jquery.battatech.excelexport.js"></script>
		<script src="../../plugins/jQueryUI/jquery-ui.min.js"></script>

		<!-- fancybox iframe -->
		<script src="../../plugins/fancybox/jquery.fancybox.js?v=2.1.5"></script>
		<!-- SlimScroll -->
		<script src="../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
		<!-- FastClick -->
		<script src="../../plugins/fastclick/fastclick.min.js"></script>
		<!-- AdminLTE App -->
		<script src="../../dist/js/app.min.js"></script>
		<!-- InputMask -->
		<script src="../../plugins/input-mask/jquery.inputmask.js"></script>
		<script src="../../plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
		<script src="../../plugins/input-mask/jquery.inputmask.extensions.js"></script>
		<!-- Suplentes -->
		<script src="js/suplentesExt.js"></script>
		<!-- UI Custom -->
		<script src="../../include/js/ui.js"></script>
		<!-- Bootstraps Dialog -->
		<script src="../../plugins/bootstrap-dialog/bootstrap-dialog.min.js"></script>
		<!-- Select2 -->
		<script src="../../plugins/select2/select2.full.min.js"></script>
		<!-- date-picker -->
		<link rel="stylesheet" href="../../plugins/bootstrap-datepicker/datepicker3.min.css" />
		<script src="../../plugins/bootstrap-datepicker/bootstrap-datepicker.js"></script>
		<script src="../../plugins/bootstrap-datepicker/moment.js"></script>

<script type="text/javascript">
$(document).ready(function() {

	$(".verImg").fancybox({
		fitToView	: true,
		width		: '100%',
		height		: '100%',
		autoSize	: true,
		closeClick	: true,
		scrolling: 'auto',
		helpers     : {  
		title : { type : 'inside', position: 'top' },
		},
		beforeShow: function(){
		this.title = '<a href="' + this.href + '" download>Click aqui para Descargar</a> '
		//this.title = $("#verImgFoto").attr('href')
		//this.title = "<a type='button' value='Descargar archivo' href='" + $("#verImgFoto").attr('href')+'/cedula.jpg download />'
		}
	});
$(".banco").select2();
$(".banco").on("change", function (e) { $(".select2-selection span").attr('title', ''); });
$(".fortalezas").select2();
$(".fortalezas").on("change", function (e) { $(".select2-selection span").attr('title', ''); });
//Elimina los titulos flotantes
$(".select2-selection span").attr('title', '');
//cargarLstDsp("fortaleza3");
cargarOcupaciones();
buscarDatosCandidato();
});

$('.input-date').datepicker({
	language: 'es',
	format: "dd/mm/yyyy",
	startView: 'decade'
	//daysOfWeekDisabled: "0,6"

});
//····················inputmask (Mascaras como tlfn)························
$("[data-mask]").inputmask();
//···················· Disble click on tabs ························
/* $('a[data-toggle="tab"]').on('click', function(){
	if ($(this).parent('li').hasClass('disabled')) {
	return false;
	};
});
 */
 
 
//····················Dialogo························
$("#dialogo").dialog({
	autoOpen : false,
	closeText : ""
});

/* $("#tabSoportes").tooltip({
	content : "<div class='ui-state-highlight ui-corner-all' style='padding: 0 .7em;'><p><span class='ui-icon ui-icon-info' style='float: left; margin-right: .3em; margin-top: .2em;'></span>Aviso! Debe<strong style='color:red'> guardar</strong> primero los datos del candidato.</p></div>"
}); */
//cargarmenu(0);

</script>

		<!-- Optionally, you can add Slimscroll and FastClick plugins.
		Both of these plugins are recommended to enhance the
		user experience. Slimscroll is required when using the
		fixed layout. -->
	</body>
</html>
