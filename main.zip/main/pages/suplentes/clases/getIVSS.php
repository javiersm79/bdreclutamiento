<?php

//extract data from the post
extract($_POST);

//set POST variables
$url = 'http://www.ivss.gob.ve:28083/CuentaIndividualIntranet/CtaIndividual_PortalCTRL';
$fields = array(
						'nacionalidad_aseg' => urlencode($nacionalidad_aseg),
						'cedula_aseg' => urlencode($cedula_aseg),
						'd' => urlencode($d),
						'm' => urlencode($m),
						'y' => urlencode($y),
						'boton' => urlencode($boton)
				);

//url-ify the data for the POST
$fields_string ="";
foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
rtrim($fields_string, '&');

//open connection
$ch = curl_init();
//13773401 - 30-06-1979
//set the url, number of POST vars, POST data
curl_setopt($ch,CURLOPT_URL, $url);
curl_setopt($ch,CURLOPT_POST, count($fields));
curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
curl_setopt($ch,CURLOPT_RETURNTRANSFER, true); // almacene en una variable
curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1); // almacene en una variable

//execute post
$result = curl_exec($ch);
//echo json_encode($result);
// when you need the position, as well whether it's present
function str_contains($haystack, $needle, $ignoreCase = false) {
    if ($ignoreCase) {
        $haystack = strtolower($haystack);
        $needle   = strtolower($needle);
    }
    $needlePos = strpos($haystack, $needle);
    return ($needlePos === false ? false : ($needlePos+1));
}

$needlePos = str_contains($result, 'Estatus del Asegurado:');
if ($needlePos) {
    //echo 'Found it at position ' . ($needlePos-1);
    echo substr($result, $needlePos+54, 10);
}
return $result;

curl_close($ch);

?>
