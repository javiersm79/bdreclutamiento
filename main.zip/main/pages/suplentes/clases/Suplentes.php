<?php 
	include_once('/var/www/main/include/clases/BD.php');
	
	
	class Suplentes
	{
 		public function actualizarSSO($fields,$id_persona)
		{
			$url = 'http://www.ivss.gob.ve:28083/CuentaIndividualIntranet/CtaIndividual_PortalCTRL';

			//print_r($fields);
			//url-ify the data for the POST
			$fields_string ="";
			foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
			rtrim($fields_string, '&');

			//open connection
			$ch = curl_init();
			//13773401 - 30-06-1979
			//set the url, number of POST vars, POST data
			curl_setopt($ch,CURLOPT_URL, $url);
			curl_setopt($ch,CURLOPT_POST, count($fields));
			curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
			curl_setopt($ch,CURLOPT_RETURNTRANSFER, true); // almacene en una variable
			curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1); // almacene en una variable

			//execute post
			$result = curl_exec($ch);
			//echo json_encode($result);
			// when you need the position, as well whether it's present
			function str_contains($haystack, $needle, $ignoreCase = false) {
				if ($ignoreCase) {
					$haystack = strtolower($haystack);
					$needle   = strtolower($needle);
				}
				$needlePos = strpos($haystack, $needle);
				//echo "aja";
				return ($needlePos === false ? false : ($needlePos+1));
				
			}
			curl_close($ch);
			$needlePos = str_contains($result, 'Estatus del Asegurado:');
			if ($needlePos) {
				//echo 'Found it at position ' . ($needlePos-1);
				$estatus= substr($result, $needlePos+54, 10);
				$bd=new Datos();
				$bd->conectar();
				$sql = "UPDATE persona SET estadosso = '$estatus (Fecha Verif. ".date("d/m/Y").")' WHERE id_persona = $id_persona"; 
				$bd->consultar($sql);
				//echo $sql;
				return "$estatus (Fecha Verif. ".date("d/m/Y").")";
				
			}
			else
			{
				return 0;
			}
			//echo $result;
			
			
			//return "X";
			

			
 
		}
		
 		public function cargarCandidatosNucleo($nucleo)
		{
			//return "Llegue a la clase";
 			$bd=new Datos();
			$bd->conectar();
			$sql = "
					SELECT DISTINCT
					a.*,
					b.*
					FROM 
					persona as a JOIN 
					persona_caracteristicas as b ON (a.id_persona  = b.id_persona)
					WHERE a.nucleo = '$nucleo'
        "; 
			//echo $sql;
			$resultado=$bd->consultar($sql);	
			return $resultado;
 
		}
		
 		public function cargarCandidatosCargo($id_fortaleza, $nucleo)
		{
			//return "Llegue a la clase";
 			$bd=new Datos();
			$bd->conectar();
			$sql = "
					SELECT DISTINCT
					a.*,
					b.*
					FROM 
					persona as a JOIN 
					persona_caracteristicas as b ON (a.id_persona  = b.id_persona)
					WHERE (b.fortaleza1 = $id_fortaleza or b.fortaleza2 = $id_fortaleza or b.fortaleza3 = $id_fortaleza) AND nucleo = '$nucleo'
        "; 
			//echo $sql;
			$resultado=$bd->consultar($sql);	
			return $resultado;
 
		}
		
 		public function cargarCandidatosProfesion($patronProfesion, $nucleo)
		{
			//return "Llegue a la clase";
 			$bd=new Datos();
			$bd->conectar();
			$sql = "
					SELECT DISTINCT
					a.*,
					b.*
					FROM 
					persona as a JOIN 
					persona_caracteristicas as b ON (a.id_persona  = b.id_persona)
					WHERE upper(b.profesion) like upper('%$patronProfesion%') AND nucleo = '$nucleo'
        "; 
			//echo $sql;
			$resultado=$bd->consultar($sql);	
			return $resultado;
 
		}
 		public function cargarCandidatos()
		{
			//return "Llegue a la clase";
 			$bd=new Datos();
			$bd->conectar();
			$sql = "
					SELECT DISTINCT
					a.*,
					b.*
					FROM 
					persona as a JOIN 
					persona_caracteristicas as b ON (a.id_persona  = b.id_persona)
        "; 
			//echo $sql;
			$resultado=$bd->consultar($sql);	
			return $resultado;
 
		}
		
 		public function guardarNuevaClave($id_persona, $clave)
		{
 			$datosCandidato = array ("id_persona" =>$id_persona,"clave"=>$clave);
			//return "Llegue a la clase";
			$bd=new Datos();
			$bd->conectar();
			$sql = "UPDATE persona SET clave = '$clave' WHERE id_persona = $id_persona"; 
			//echo $sql;
			//$resultado=$bd->actualizar($sql);	
			$resultado=$bd->actualizar("persona",$datosCandidato,"id_persona",$datosCandidato["id_persona"]);
			//$datosCandidato = array ("id_persona" =>$id_persona,"clave"=>$clave);
			return $resultado;

		}
		
		public function buscarDatosCandidato($id_persona)
		{
			//return "Llegue a la clase";
			$bd=new Datos();
			$bd->conectar();
			$sql = "
					SELECT DISTINCT
					a.*,
					b.*,
					c.nombre_ocupacion as nombrefortaleza1,
					d.nombre_ocupacion as nombrefortaleza2,
					e.nombre_ocupacion as nombrefortaleza3
					FROM 
					persona as a JOIN 
					persona_caracteristicas as b ON (a.id_persona  = b.id_persona) LEFT JOIN
					ocupaciones as c ON (b.fortaleza1 = c.id_ocupacion) LEFT JOIN
					ocupaciones as d ON (b.fortaleza2 = d.id_ocupacion) LEFT JOIN
					ocupaciones as e ON (b.fortaleza3 = e.id_ocupacion)  
					WHERE a.id_persona = $id_persona
        "; 
			//echo $sql;
			$resultado=$bd->consultar($sql);	
			return $resultado;

		}
		
		public function cargarOcupaciones()
		{
			//return "Llegue a la clase";
			$bd=new Datos();
			$bd->conectar();
			$sql = "
					SELECT *
					FROM 
					ocupaciones ORDER BY nombre_ocupacion
        "; 
			//echo $sql;
			$resultado=$bd->consultar($sql);	
			return $resultado;
		}
		
		public function actualizarDatosCandidato($datosCandidato, $datosCandidatoF, $id_persona)
		{
			$bd=new Datos();
			$bd->conectar();
			$buscarEmail = $this->verificarEmailSuplente($datosCandidato["email"],$id_persona); //Verifica si ese email esta registrada
			//echo "Resultado: ".$buscarEmail."\n";
			//$emailReg = json_decode($buscarEmail);
			//echo "\n".$buscarEmail;
			//print_r($datosCandidatoF);
 			if ($buscarEmail == 0) {
			//if ($buscarCedula == 0) {
				$resultado=$bd->actualizar("persona",$datosCandidato,"id_persona",$datosCandidato["id_persona"]);
				$resultado=$bd->actualizar("persona_caracteristicas",$datosCandidatoF,"id_persona",$datosCandidato["id_persona"]);
				$resultado = 0;
			 }
			else {
				$resultado = 1;
			}
			//$resultado = 2;
			$bd->desconectar();	
			return $resultado;

		} //Fin de la funcion guardarTempPersona
		
		public function verificarCedulaSuplente($cedula)
		{
			$bd=new Datos();
			$bd->conectar();
			$sql ="SELECT cedula, id_persona FROM persona WHERE cedula != '".$cedula."'";
			//echo $sql;
			$resultado=$bd->consultar($sql);	
			return $resultado;
		} //Fin de la funcion verificarCedulaSuplente	
		
		public function verificarEmailSuplente($email, $id_persona)
		{
			$bd=new Datos();
			$bd->conectar();
			$sql ="SELECT email, id_persona FROM persona WHERE email = '".$email."' and id_persona != ".$id_persona;
			//echo $sql;
			$resultado=$bd->consultar($sql);	
			return $resultado;
		} //Fin de la funcion verificarEmailSuplente
		
		
			
	} //Fin de la clase Suplentes
	
/* $Suplentes = new Suplentes();
			$fields = array(
									'nacionalidad_aseg' =>	"V",
									'cedula_aseg' 		=> 	"14815020",
									'd' 				=>	"30",
									'm' 				=> 	"04",
									'y' 				=> 	"1979",
									'boton' 			=> 	"Consultar"
							);
			$datos = $Suplentes->actualizarSSO($fields);
			echo $datos; */

	
?>