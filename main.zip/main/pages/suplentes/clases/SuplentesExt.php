<?php 
	include_once('../../../include/clases/BD.php');
	
	
	class SuplentesExt
	{
 		public function guardarNuevaClave($id_persona, $clave)
		{
 			$datosCandidato = array ("id_persona" =>$id_persona,"clave"=>$clave);
			//return "Llegue a la clase";
			$bd=new Datos();
			$bd->conectar();
			$sql = "UPDATE persona SET clave = '$clave' WHERE id_persona = $id_persona"; 
			//echo $sql;
			//$resultado=$bd->actualizar($sql);	
			$resultado=$bd->actualizar("persona",$datosCandidato,"id_persona",$datosCandidato["id_persona"]);
			//$datosCandidato = array ("id_persona" =>$id_persona,"clave"=>$clave);
			return $resultado;

		}
		
		public function buscarDatosCandidato($id_persona)
		{
			//return "Llegue a la clase";
			$bd=new Datos();
			$bd->conectar();
			$sql = "
					SELECT DISTINCT
					a.*,
					b.*
					FROM 
					persona as a JOIN 
					persona_caracteristicas as b ON (a.id_persona  = b.id_persona) 
					WHERE
					a.id_persona = $id_persona
        "; 
			//echo $sql;
			$resultado=$bd->consultar($sql);	
			return $resultado;

		}
		
		public function cargarOcupaciones()
		{
			//return "Llegue a la clase";
			$bd=new Datos();
			$bd->conectar();
			$sql = "
					SELECT *
					FROM 
					ocupaciones ORDER BY nombre_ocupacion
        "; 
			//echo $sql;
			$resultado=$bd->consultar($sql);	
			return $resultado;
		}
		
		
		public function subirImagen($id_datos_generales)
		{
			print_r($_FILES);
			/* foreach($_FILES as $file){
			  echo $file['name']."\n"; 
			}
			$target_dir = "";
			$target_file = $target_dir . basename($file['name']);
			$uploadOk = 1;
			$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
			// Check if image file is a actual image or fake image
			if(isset($_POST["submit"])) {
				$check = getimagesize($file["tmp_name"]);
				if($check !== false) {
					echo "File is an image - " . $check["mime"] . ".";
					$uploadOk = 1;
				} else {
					echo "File is not an image.";
					$uploadOk = 0;
				}
			}
			// Check if file already exists
			if (file_exists($target_file)) {
				echo "Sorry, file already exists.";
				$uploadOk = 0;
			}
			// Check file size
			if ($file["size"] > 200000) {
				echo "Sorry, your file is too large.";
				$uploadOk = 0;
			}
			// Allow certain file formats
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
			&& $imageFileType != "gif" ) {
				echo "Sorry, only JPG, JPEG, PNG files are allowed.";
				$uploadOk = 0;
			}
			// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
				echo "Sorry, your file was not uploaded.";
			// if everything is ok, try to upload file
			} else {
				if (move_uploaded_file($file["tmp_name"], $target_file)) {
					echo "The file ". basename( $file["name"]). " has been uploaded.";
				} else {
					echo "Sorry, there was an error uploading your file.";
				}
			}  */
			return "Aqui subo la imagen";
		} //Fin de la funcion guardarTempPersona
		
		public function actualizarDatosCandidato($datosCandidato, $datosCandidatoF, $id_persona)
		{
			$bd=new Datos();
			$bd->conectar();
			$buscarEmail = $this->verificarEmailSuplente($datosCandidato["email"],$id_persona); //Verifica si ese email esta registrada
			//echo "Resultado: ".$buscarEmail."\n";
			//$emailReg = json_decode($buscarEmail);
			//echo "\n".$buscarEmail;
			//print_r($datosCandidatoF);
 			if ($buscarEmail == 0) {
			//if ($buscarCedula == 0) {
				$resultado=$bd->actualizar("persona",$datosCandidato,"id_persona",$datosCandidato["id_persona"]);
				$resultado=$bd->actualizar("persona_caracteristicas",$datosCandidatoF,"id_persona",$datosCandidato["id_persona"]);
				$resultado = 0;
			 }
			else {
				$resultado = 1;
			}
			//$resultado = 2;
			$bd->desconectar();	
			return $resultado;

		} //Fin de la funcion guardarTempPersona
		
		public function verificarCedulaSuplente($cedula)
		{
			$bd=new Datos();
			$bd->conectar();
			$sql ="SELECT cedula, id_persona FROM persona WHERE cedula != '".$cedula."'";
			//echo $sql;
			$resultado=$bd->consultar($sql);	
			return $resultado;
		} //Fin de la funcion verificarCedulaSuplente	
		
		public function verificarEmailSuplente($email, $id_persona)
		{
			$bd=new Datos();
			$bd->conectar();
			$sql ="SELECT email, id_persona FROM persona WHERE email = '".$email."' and id_persona != ".$id_persona;
			//echo $sql;
			$resultado=$bd->consultar($sql);	
			return $resultado;
		} //Fin de la funcion verificarEmailSuplente
		
		
			
	} //Fin de la clase Suplentes
?>