<?php 
	include_once('../../clases/constantes.php');
	class PdfFichasAP
	{
		public function informacionBase($id_proyecto){
			$sql="select * from t001_proyecto where  id_proyecto =".$id_proyecto; 
			$bd=new FachadaBD();
			$bd->abrir(BD,SERVIDOR,USUARIO,CLAVE,PUERTO);
			$resultado=$bd->consultar($sql,'ARREGLO');
			return $resultado;
		}
		
		
		public function buscarDatosFicha($id_ficha)
		{ 
        	$sql="select * from   fichasap.t001_pro_fichas where id_pro_fichas=".$id_ficha; 
        	$bd=new FachadaBD();
			$bd->abrir(BD,SERVIDOR,USUARIO,CLAVE,PUERTO);
			$resultado=$bd->consultar($sql,'ARREGLO');
			return $resultado;
		}
		public function buscarUbicacion($id_ubicacion)
		{ 
        	$sql="select 
						a.tx_ciudad as ciudad, 
						d.tx_nombre_ubic as estado,
						c.tx_nombre_ubic as municipio,
						b.tx_nombre_ubic as parroquia	
						
					from   	b002_nucleo a join b007_ubicacion b on (a.b007_id_ubicacion = b.id_ubicacion) join 
						b007_ubicacion c on (c.id_ubicacion = b.id_ubic_padre) join
						b007_ubicacion d on (d.id_ubicacion = c.id_ubic_padre) 
					 where id_nucleo =".$id_ubicacion; 
        	$bd=new FachadaBD();
			$bd->abrir(BD,SERVIDOR,USUARIO,CLAVE,PUERTO);
			$resultado=$bd->consultar($sql,'ARREGLO');
			return $resultado;
		}

		public function buscarResponsable($id_ubicacion)
		{ 
        	$sql="select 
					b.tx_nombre_apellido as decano,
					b.tx_cedula as cedula_dec,
					b.tx_email as email_dec,
					b.tx_telefono as telefono_dec,
					c.tx_nombre_apellido as delegado,
					c.tx_cedula as cedula_del,
					c.tx_email as email_del,
					c.tx_telefono as telefono_del
			from   	
				b002_nucleo a join  b003_persona b on (a.b003_id_decano = b.id_persona ) join
				b003_persona c on (a.b003_id_rsp_planificacion = c.id_persona) 
			 where 
			a.id_nucleo =".$id_ubicacion; 
        	$bd=new FachadaBD();
			$bd->abrir(BD,SERVIDOR,USUARIO,CLAVE,PUERTO);
			$resultado=$bd->consultar($sql,'ARREGLO');
			return $resultado;
		}




	}
?>