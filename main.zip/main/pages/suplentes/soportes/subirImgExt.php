<?php
include_once('../../../include/clases/BD.php');
//include_once("../clases/SuplentesExt.php");
/* foreach($_FILES as $file){
  echo $file['name']."\n"; 
} */
$archivo = $_FILES["archivo"];
$bd=new Datos();
$bd->conectar();
$datos = array($_POST["campo"]=>1);
//$SuplentesExT=new SuplentesExT();

//$resultado=$SuplentesExT->verificarCedulaSuplente($_POST["imgCedulaId"]);
/*  print_r($_POST);
print_r($_FILES); */

//$target_dir = "/var/www/main/pages/suplentes/soportes/".$_POST["id_persona"];
$target_file = "/var/www/main/pages/suplentes/soportes/".$_POST["id_persona"]."/".$_POST["nombrearchivo"];
$uploadOk = 1;
//$imageFileType = pathinfo($file["tmp_name"],PATHINFO_EXTENSION);
$imageFileType = end(explode(".", $archivo ['name']));
//echo "Extension: ".$imageFileType."\n"; */
//print_r($_FILES["archivo"])."\n";
// Check if image file is a actual image or fake image
if(isset($_POST["nombrearchivo"])) {
    $check = getimagesize($archivo ["tmp_name"]);
    if($check !== false) {
        //echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        $mensaje = "El archivo no es una imagen";
        $uploadOk = 0;
    }
}
// Check if file already exists
/* if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
} */
// Check file size
if ($archivo ["size"] > 2000000) {
    $mensaje = "El tamaño del archivo es muy grande (Tamaño m&aacute;ximo: 2 Megabytes )";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "jpeg") {
    //$mensaje =  "Solamente est&aacute; permitido archivos de tipo JPG, JPEG, PNG";
    $mensaje =  "Solamente est&aacute; permitido archivos de tipo JPG";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo $mensaje;
// if everything is ok, try to upload file
} else {
    //if (move_uploaded_file($archivo ["tmp_name"], $target_file.".".$imageFileType)) {
    if (move_uploaded_file($archivo ["tmp_name"], $target_file.".jpg")) {
        //echo "The file ". basename( $archivo ["name"]). $imageFileType" has been uploaded.";
		$bd->actualizar("persona",$datos,"id_persona",$_POST["id_persona"]);
		echo 1;
    } else {
        echo "Error subiendo el archivo";
    }
}
?>