<?php
	session_start();
	include_once("../clases/SuplentesExt.php");

	foreach($_POST as $nombre_campo => $valor)
	{
	   $asignacion = "\$" . $nombre_campo . "='".addslashes($valor)."';";
	   eval($asignacion);
	}
	 //print_r($asignacion);
	switch($accion){
/* 		case 'cedulaCNE':	
			$Suplentes = new SuplentesExt();
			$id_persona = $_SESSION['id_persona'];					
			$datos = $Suplentes->SearchCNE('V', 14815020);
		//print_r($_POST);
		//$datos = $_POST;
		break; */
		case 'actualizarDatosCandidato':	
			$Suplentes = new SuplentesExt();
			$id_persona = $_SESSION['id_persona'];
			$datosCandidato = array(	"id_persona"			=>	$id_persona,
										"nucleo" 				=>	$nucleo,
										"nombres" 				=>	$nombres,
										"apellidos" 			=>	$apellidos,
										"fechanac"				=>	$fechanac,
										"cedula"				=>	$cedula,
										"email"	 				=>	$email,
										"usuario" 				=>	$email,
										"telefono1"				=>	$telefono1,
										"telefono2"				=>	$telefono2,
										"nctabnacaria"			=>	$nctabnacaria,
										"banco"					=>	$banco,
										"validar_datos	"		=>	$validar_datos,
										"tipoctabancaria"		=>	$tipoctabancaria);
			$datosCandidatoF = array(	"profesion"				=>	$profesion,
										"sexo"					=>	$sexo,
										"motricidad"			=>	$motricidad,
										"fortaleza1"			=>	$fortaleza1,
										"fortaleza2"			=>	$fortaleza2,
										"fortaleza3"			=>	$fortaleza3);					
			$datos = $Suplentes->actualizarDatosCandidato($datosCandidato, $datosCandidatoF, $id_persona);
		//print_r($_POST);
		//$datos = $_POST;
		break;
		case 'guardarNuevaClave':	
			$SuplentesExt = new SuplentesExt();
			$id_persona = $_SESSION['id_persona'];
			//print_r($_POST);
			$datos = $SuplentesExt->guardarNuevaClave($id_persona, $clave);
			//$datos = "Llegue a la clase";
			
		break;
		case 'buscarDatosCandidato':	
			$SuplentesExt = new SuplentesExt();
			$id_persona = $_SESSION['id_persona'];
			//print_r($_SESSION)
			$datos = $SuplentesExt->buscarDatosCandidato($id_persona);
			
		break;
		case 'cargarOcupaciones':	
			$SuplentesExt = new SuplentesExt();
			$datos = $SuplentesExt->cargarOcupaciones();
		break;
		case 'subirImagen':
			$SuplentesExt = new SuplentesExt();
			$datos = $SuplentesExt->subirImagen();
		break;
/* 		case 'subirImagen':	
			$Suplentes = new Suplentes();
			$datos = $Suplentes->verificarCedulaSuplente($cedula);
		break; */	
	}
	echo json_encode($datos);
	//echo json_encode($datos);

?>