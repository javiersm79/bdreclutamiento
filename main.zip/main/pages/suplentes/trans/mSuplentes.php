<?php
	session_start();
	include_once("../clases/Suplentes.php");

	foreach($_POST as $nombre_campo => $valor)
	{
	   $asignacion = "\$" . $nombre_campo . "='".addslashes($valor)."';";
	   eval($asignacion);
	}
	 //print_r($asignacion);
	switch($accion){
		case 'actualizarSSO':	
			$Suplentes = new Suplentes();
			//$id_persona = $_SESSION['id_persona'];
			$fields = array(
									'nacionalidad_aseg' =>	$nacionalidad_aseg,
									'cedula_aseg' 		=> 	$cedula_aseg,
									'd' 				=>	$d,
									'm' 				=> 	$m,
									'y' 				=> 	$y,
									'boton' 			=> 	"Consultar"
							);
			$datos = $Suplentes->actualizarSSO($fields,$id_persona);
			//echo $id_fortaleza;
		break;
		case 'cargarCandidatosCargo':	
			$Suplentes = new Suplentes();
			//$id_persona = $_SESSION['id_persona'];
			//print_r($_POST);
			$datos = $Suplentes->cargarCandidatosCargo($id_fortaleza, $nucleo);
			//echo $id_fortaleza;
		break;
		case 'cargarCandidatosNucleo':	
			$Suplentes = new Suplentes();
			//$id_persona = $_SESSION['id_persona'];
			//print_r($_POST);
			$datos = $Suplentes->cargarCandidatosNucleo($nucleo);
			//echo $id_fortaleza;
		break;		
		case 'cargarCandidatosProfesion':	
			$Suplentes = new Suplentes();
			//$id_persona = $_SESSION['id_persona'];
			//print_r($_POST);
			$datos = $Suplentes->cargarCandidatosProfesion($patronProfesion, $nucleo);
		break;		
		case 'buscarDatosFicha':	
			$Suplentes = new Suplentes();
			//$id_persona = $_SESSION['id_persona'];
			//print_r($_SESSION)
			$datos = $Suplentes->buscarDatosCandidato($id_persona);
		break;
		case 'cargarCandidatos':	
			$Suplentes = new Suplentes();
			$id_persona = $_SESSION['id_persona'];					
			$datos = $Suplentes->cargarCandidatos();
		//print_r($_POST);
		//$datos = $_POST;
		break;
		case 'actualizarDatosCandidato':	
			$Suplentes = new Suplentes();
			$id_persona = $_SESSION['id_persona'];
			$datosCandidato = array(	"id_persona"			=>	$id_persona,
										"nombres" 				=>	$nombres,
										"apellidos" 			=>	$apellidos,
										"cedula"				=>	$cedula,
										"email"	 				=>	$email,
										"usuario" 				=>	$email,
										"telefono1"				=>	$telefono1,
										"telefono2"				=>	$telefono2);
			$datosCandidatoF = array(	"profesion"				=>	$profesion,
										"sexo"					=>	$sexo,
										"motricidad"			=>	$motricidad,
										"fortaleza1"			=>	$fortaleza1,
										"fortaleza2"			=>	$fortaleza2,
										"fortaleza3"			=>	$fortaleza3);					
			$datos = $Suplentes->actualizarDatosCandidato($datosCandidato, $datosCandidatoF, $id_persona);
		//print_r($_POST);
		//$datos = $_POST;
		break;
		case 'guardarNuevaClave':	
			$Suplentes = new Suplentes();
			$id_persona = $_SESSION['id_persona'];
			//print_r($_POST);
			$datos = $Suplentes->guardarNuevaClave($id_persona, $clave);
			//$datos = "Llegue a la clase";
			
		break;
		case 'buscarDatosCandidato':	
			$Suplentes = new Suplentes();
			$id_persona = $_SESSION['id_persona'];
			//print_r($_SESSION)
			$datos = $Suplentes->buscarDatosCandidato($id_persona);
		break;
		case 'cargarOcupaciones':	
			$Suplentes = new Suplentes();
			$datos = $Suplentes->cargarOcupaciones();
		break;
		case 'subirImagen':
			$Suplentes = new Suplentes();
			$datos = $Suplentes->subirImagen();
		break;
/* 		case 'subirImagen':	
			$Suplentes = new Suplentes();
			$datos = $Suplentes->verificarCedulaSuplente($cedula);
		break; */	
	}
	echo json_encode($datos);
	//echo json_encode($datos);

?>