<?php
	//session_start();
	include_once("../clases/Suplentes.php");

	foreach($_POST as $nombre_campo => $valor)
	{
	   $accion = "\$" . $nombre_campo . "='".addslashes($valor)."';";
	   eval($accion);
	} 
	 
	switch($accion){
		case 'buscarDatosCandidato':	
			$Suplentes = new Suplentes();
			$id_persona = $_SESSION['id_persona'];
			$datos = $Suplentes->buscarDatosCandidato($id_persona);
		break;
		case 'verificarCedulaSuplente':	
			$Suplentes = new Suplentes();
			$datos = $Suplentes->verificarCedulaSuplente($cedula);
		break;	
	}
	echo json_encode($datos);

?>