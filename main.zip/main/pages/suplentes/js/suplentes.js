//Buscar datos de Personas Reguistradas en el sistema por Profesion
function buscarPorProfesion(){
//$("#busquedaPatron").html("Ingresar la profesión:&nbsp;&nbsp;<input type='text' class='' name='patronprofesion' value='' id='patronprofesion' size=80/>");
$("#tipobusqueda").html('<div class="box box-info"> \
<div class="box-header with-border"> \
<h3 class="box-title">Seleccione el Núcleo y coloque una profesión</h3> \
</div> \
<div class="box-body"> \
<div class="input-group"> \
<label for="nucleo" control-label">N&uacute;cleo</label> \
<select id="nucleo" name="nucleo" class="form-control"> \
	<option value="0" selected>Seleccionar</option> \
	<option value="Anzoategui" >Anzoategui</option> \
	<option value="Bolívar">Bolívar</option> \
	<option value="Monagas">Monagas</option> \
	<option value="Nva. Esparta" >Nva. Esparta</option> \
	<option value="Sucre">Sucre</option> \
	<option value="Rectorado">Rectorado</option> \
</select> \
</div><br> \
<div class="input-group"> \
<input class="form-control" type="text" id="patronprofesion" placeholder="Ingresar un patrón de búsqueda" size= 300> \
</div><br> \
<button class="btn btn-default" onclick="cargarTablaCandidatosProfesion()">Buscar</button> ');
$("#tablaCandidatos").html("");
}	

//Buscar datos de Personas Reguistradas en el sistema por Fortalezas (1,2,3)
function buscarPorCargo(){
//$("#busquedaPatron").html("Ingresar la profesión:&nbsp;&nbsp;<input type='text' class='' name='patronprofesion' value='' id='patronprofesion' size=80/>");
$("#tipobusqueda").html('<div class="box box-info"> \
<div class="box-header with-border"> \
<h3 class="box-title">Seleccione el Núcleo y el cargo</h3> \
</div> \
<div class="box-body"> \
<div class="input-group"> \
<label for="nucleo" control-label">N&uacute;cleo</label> \
<select id="nucleo" name="nucleo" class="form-control"> \
	<option value="0" selected>Seleccionar</option> \
	<option value="Anzoategui" >Anzoategui</option> \
	<option value="Bolívar">Bolívar</option> \
	<option value="Monagas">Monagas</option> \
	<option value="Nva. Esparta" >Nva. Esparta</option> \
	<option value="Sucre">Sucre</option> \
	<option value="Rectorado">Rectorado</option> \
</select> \
</div><br> \
<div class="input-group"> \
<label for="idfortaleza" control-label form-control">Cargo</label><br> \
<select id="idfortaleza" class="fortalezas" title=""> \
<option value=0 selected title="">Seleccione</option> \
</select> \
</div><br> \
<button class="btn btn-default" onclick="cargarTablaCandidatosCargos()">Buscar</button> ');
$("#tablaCandidatos").html("");
cargarOcupaciones();
$("#idfortaleza").select2();
$(".select2-selection span").attr('title', '');
$(".fortalezas").on("change", function (e) { $(".select2-selection span").attr('title', ''); });
}	

//Buscar datos de Personas Reguistradas en el sistema por Nucleo
function buscarPorNucleo(){
//$("#busquedaPatron").html("Ingresar la profesión:&nbsp;&nbsp;<input type='text' class='' name='patronprofesion' value='' id='patronprofesion' size=80/>");
$("#tipobusqueda").html('<div class="box box-info"> \
<div class="box-header with-border"> \
<h3 class="box-title">Seleccione un Núcleo</h3> \
</div> \
<div class="box-body"> \
<div class="input-group"> \
<select id="nucleo" name="nucleo" class="form-control"> \
	<option value="0" selected>Seleccionar</option> \
	<option value="Anzoategui" >Anzoategui</option> \
	<option value="Bolívar">Bolívar</option> \
	<option value="Monagas">Monagas</option> \
	<option value="Nva. Esparta" >Nva. Esparta</option> \
	<option value="Sucre">Sucre</option> \
	<option value="Rectorado">Rectorado</option> \
</select> \
</div><br> \
<button class="btn btn-default" onclick="cargarTablaCandidatosNucleo()">Buscar</button> ');
$("#tablaCandidatos").html("");
//cargarOcupaciones();
/* $("#idNucleo").select2();
$(".select2-selection span").attr('title', '');
$(".fortalezas").on("change", function (e) { $(".select2-selection span").attr('title', ''); }); */
}	

//Buscar datos de Personas Reguistradas en el sistema
function buscarDatosFicha(){
	id_persona=$("#id_candidato").val();
	//alert(id_persona);
	$.ajax({
		type:'POST',
		async:false,
		//url:"datosfrm.php",
		url:"trans/mSuplentes.php",	
		data:{"accion":"buscarDatosFicha", "id_persona":id_persona},
		error:function(xhr,ajaxOptions,thrownError){
			//$('#msgFooterDatos').html('<div class="ui-state-error ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;Error!</strong> Intente nuevamente</h4></div>');
			msgNotificar("msgFooterDatos", "error", " Error! Contactar con el administrador del sistema");
		},
		success:function(req){			
			
 				var data=$.parseJSON(req);
				if(data)
				{
					$("#nombres").text(data[0]["nombres"]+' '+data[0]["apellidos"]+' - ');
					$("#precedula").text(data[0]["cedula"].substring(0, 1));
					$("#cedula").text(data[0]["cedula"].substring(2, 13));
					if (!data[0]["telefono1"])
					{
						$("#telefono1").text("S/N");
					}
					else
					{
						$("#telefono1").text(data[0]["telefono1"]);
					}
					
					if (!data[0]["telefono2"])
					{
						$("#telefono2").text("S/N");
					}
					else
					{
						$("#telefono2").text(data[0]["telefono2"]);
					}
					
					if (!data[0]["fechanac"])
					{
						$("#fechanacsuplente").text("Sin actualizar");
					}
					else
					{
						fechanac=data[0]["fechanac"].split('-');
						//$("#fechanacsuplente").val(fechanac[2]+'/'+fechanac[1]+'/'+fechanac[0]);
						$("#fechanacsuplente").text(fechanac[2]+'/'+fechanac[1]+'/'+fechanac[0]);
					}
					if (!data[0]["profesion"])
					{
						$("#profesionsuplente").text("Sin actualizar");
					}
					else
					{
						$("#profesionsuplente").text(data[0]["profesion"]);
					}

					$("#emailsuplente").text(data[0]["email"]);
					$("#estadosuplente").text(data[0]["estado"]);
					$("#municipiosuplente").text(data[0]["municipio"]);
					$("#parroquiasuplente").text(data[0]["parroquia"]);
					if (!data[0]["sexo"])
					{
						$("#sexo").text("Sin actualizar");
					}
					else
					{
						$("#sexo").text(data[0]["sexo"]);
					}

					if (!data[0]["estadosso"])
					{
						$("#segurosocial").text("Sin actualizar");
					}
					else
					{
						$("#segurosocial").text(data[0]["estadosso"]);
					}
					
					if (!data[0]["motricidad"])
					{
						$("#motricidad").text("Sin actualizar");
					}
					else
					{
						$("#motricidad").text(data[0]["motricidad"]);
					}
					
					if (data[0]["fortaleza1"] == 0)
					{
						$("#fortaleza1").text("Sin actualizar");
					}
					else
					{
						$("#fortaleza1").text(data[0]["nombrefortaleza1"]);
					}
										
					if (data[0]["fortaleza2"] == 0)
					{
						$("#fortaleza2").text("Sin actualizar");
					}
					else
					{
						$("#fortaleza2").text(data[0]["nombrefortaleza2"]);
					}
										
					if (data[0]["fortaleza3"] == 0)
					{
						$("#fortaleza3").text("Sin actualizar");
					}
					else
					{
						$("#fortaleza3").text(data[0]["nombrefortaleza3"]);
					}
					if (!data[0]["banco"])
					{
						$("#banco").text("Sin actualizar");
					}
					else
					{
						$("#banco").text(data[0]["banco"]);
					}
					if (!data[0]["tipoctabancaria"])
					{
						$("#tipoctabancaria").text("Sin actualizar");
					}
					else
					{
						$("#tipoctabancaria").text(data[0]["tipoctabancaria"]);
					}
					if (!data[0]["nctabnacaria"])
					{
						$("#nctabnacaria").text("Sin actualizar");
					}
					else
					{
						$("#nctabnacaria").text(data[0]["nctabnacaria"]);
					}
					
					
/* 					$("#fortaleza1").text(data[0]["nombrefortaleza1"]);
					$("#fortaleza2").text(data[0]["nombrefortaleza2"]);
					$("#fortaleza3").text(data[0]["nombrefortaleza3"]); */
					if (data[0]["fotoimg"]==0){
						$("#verImgFoto").attr('disabled','disabled');					
					}
					else 
					{
						$("#verImgFoto").attr('href','soportes/'+data[0]["id_persona"]+'/fotocarnet.jpg');
						$("#verImgFoto").addClass('verImg');
					}
					
					if (data[0]["cedulaimg"]==0){
						$("#verImgCedula").attr('disabled','disabled');
					}
					else 
					{
						$("#verImgCedula").attr('href','soportes/'+data[0]["id_persona"]+'/cedula.jpg');
						$("#verImgCedula").addClass('verImg');
					}
					
					if (data[0]["saludimg"]==0){
						$("#verImgSalud").attr('disabled','disabled');
					}
					else 
					{
						$("#verImgSalud").attr('href','soportes/'+data[0]["id_persona"]+'/certificado_salud.jpg');
						$("#verImgSalud").addClass('verImg');
					}
											
					if (data[0]["bancoimg"]==0){
						$("#verImgBanco").attr('disabled','disabled');
					}
					else 
					{
						$("#verImgBanco").attr('href','soportes/'+data[0]["id_persona"]+'/cta_bancaria.jpg');
						$("#verImgBanco").addClass('verImg');
					}
					
					if (data[0]["tituloimg"]==0){
						$("#verImgTitulo").attr('disabled','disabled');
					}
					else 
					{
						$("#verImgTitulo").attr('href','soportes/'+data[0]["id_persona"]+'/titulo.jpg');
						$("#verImgTitulo").addClass('verImg');
					}
						
					if (data[0]["curriculumpdf"]==0){
						$("#verCV").attr('disabled','disabled');						
					}
					else 
					{
						$("#verCV").attr('href','soportes/'+data[0]["id_persona"]+'/curriculum.pdf');
					} 

					
				}
				else 
				{
					//msgNotificar("msgFooterDatos", "advertencia", "C&eacute;dula registrada en el sistema");
					notificar ("<li class='fa  fa-warning '/> Ocurrio un error. Contactar al Administrador", "type-danger");
				} 
			}
		
	});
}
/////////////////////////////////////////////////////////////////////////////////////////

function buscarDatosCandidato(){
	//cedula=$("#cedulaimg").val();
	$.ajax({
		type:'POST',
		async:false,
		//url:"datosfrm.php",
		url:"trans/mSuplentes.php",	
		data:{"accion":"buscarDatosCandidato"},
		error:function(xhr,ajaxOptions,thrownError){
			//$('#msgFooterDatos').html('<div class="ui-state-error ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;Error!</strong> Intente nuevamente</h4></div>');
			msgNotificar("msgFooterDatos", "error", " Error! Contactar con el administrador del sistema");
		},
		success:function(req){			
			
 				var data=$.parseJSON(req);
				if(data)
				{
					//alert(data[0]["profesionsuplente"]);
					$("#profesionsuplente").val(data[0]["profesion"]);
					$("#nombresuplente").val(data[0]["nombres"]);
					$("#apellidossuplente").val(data[0]["apellidos"]);
					//alert(data[0]["cedula"].substring(0, 1));
					$("#precedula").val(data[0]["cedula"].substring(0, 1));
					$("#cedulasuplente").val(data[0]["cedula"].substring(2, 13));
					$("#emailsuplente").val(data[0]["email"]);
					$("#estadosuplente").val(data[0]["estado"]);
					$("#municipiosuplente").val(data[0]["municipio"]);
					$("#parroquiasuplente").val(data[0]["parroquia"]);
					$("#telefono1").val(data[0]["telefono1"]);
					$("#telefono2").val(data[0]["telefono2"]);
					//$("#fortaleza1").val();
					$('#fortaleza1 option[value='+data[0]["fortaleza1"]+']').attr("selected", "selected").change();
					alert(data[0]["fortaleza1"]);
					$('#fortaleza2 option[value='+data[0]["fortaleza2"]+']').attr("selected", "selected").change();
					alert(data[0]["fortaleza2"]);
					$('#fortaleza3 option[value='+data[0]["fortaleza3"]+']').attr("selected", "selected").change();
					alert(data[0]["fortaleza3"]);
					$('#sexo option[value='+data[0]["sexo"]+']').attr("selected", "selected").change();
					$('#motricidad option[value='+data[0]["motricidad"]+']').attr("selected", "selected").change();
					//alert (data[0]["sexo"]);
					if (data[0]["fotoimg"]==0){
						$("#verImgFoto").attr('disabled','disabled');
						$("#progFoto").addClass('bg-red color-palette');
						$("#progFoto").html('&nbsp;Dato sin cargar');
						
					}
					else 
					{
						$("#verImgFoto").attr('href','soportes/'+data[0]["id_persona"]+'/fotocarnet.jpg');
						$("#progFoto").addClass('bg-aqua color-palette');
						$("#progFoto").html('&nbsp;Dato cargado');
					}
					
					if (data[0]["cedulaimg"]==0){
						$("#verImgCedula").attr('disabled','disabled');
						$("#progCedula").addClass('bg-red color-palette');
						$("#progCedula").html('&nbsp;Dato sin cargar');
						
					}
					else 
					{
						$("#verImgCedula").attr('href','soportes/'+data[0]["id_persona"]+'/cedula.jpg');
						$("#progCedula").addClass('bg-aqua color-palette');
						$("#progCedula").html('&nbsp;Dato Cargado');
					}
					
					if (data[0]["saludimg"]==0){
						$("#verImgSalud").attr('disabled','disabled');
						$("#progSalud").addClass('bg-red color-palette');
						$("#progSalud").html('&nbsp;Dato sin cargar');
						
					}
					else 
					{
						$("#verImgSalud").attr('href','soportes/'+data[0]["id_persona"]+'/certificado_salud.jpg');
						$("#progSalud").addClass('bg-aqua color-palette');
						$("#progSalud").html('&nbsp;Dato sin cargar');
					}
											
					if (data[0]["bancoimg"]==0){
						$("#verImgBanco").attr('disabled','disabled');
						$("#progBanco").addClass('bg-red color-palette');
						$("#progBanco").html('&nbsp;Dato sin cargar');
						
					}
					else 
					{
						$("#verImgBanco").attr('href','soportes/'+data[0]["id_persona"]+'/cta_bancaria.jpg');
						$("#progBanco").addClass('bg-aqua color-palette');
						$("#progBanco").html('&nbsp;Dato Cargado');
					}
					
					if (data[0]["tituloimg"]==0){
						$("#verImgTitulo").attr('disabled','disabled');
						$("#progTitulo").addClass('bg-red color-palette');
						$("#progTitulo").html('&nbsp;Dato sin cargar');
						
					}
					else 
					{
						$("#verImgTitulo").attr('href','soportes/'+data[0]["id_persona"]+'/titulo.jpg');
						$("#progTitulo").addClass('bg-aqua color-palette');
						$("#progTitulo").html('&nbsp;Dato Cargado');
					}
						
					if (data[0]["curriculumpdf"]==0){
						$("#verCV").attr('disabled','disabled');
						$("#progCV").addClass('bg-red color-palette');
						$("#progCV").html('&nbsp;Dato sin cargar');
						
					}
					else 
					{
						$("#verCV").attr('href','soportes/'+data[0]["id_persona"]+'/curriculum.pdf');
						$("#progCV").addClass('bg-aqua color-palette');
						$("#progCV").html('&nbsp;Dato Cargado');
					}
						
					
					
					
				}
				else 
				{
					//msgNotificar("msgFooterDatos", "advertencia", "C&eacute;dula registrada en el sistema");
					notificar ("<li class='fa  fa-warning '/> Ocurrio un error. Contactar al Administrador", "type-danger");
				} 
			}
		
	});
}
/////////////////////////////////////////////////////////////////////////////////////////

//Buscar datos de Personas Registrados en el sistema
function cargarOcupaciones(){
	//cedula=$("#cedulaimg").val();
	$.ajax({
		type:'POST',
		async:false,
		//url:"datosfrm.php",
		url:"trans/mSuplentes.php",	
		data:{"accion":"cargarOcupaciones"},
		error:function(xhr,ajaxOptions,thrownError){
			//$('#msgFooterDatos').html('<div class="ui-state-error ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;Error!</strong> Intente nuevamente</h4></div>');
			//msgNotificar("msgFooterDatos", "error", " Error! Contactar con el administrador del sistema");
		},
		success:function(req){
  				var data=$.parseJSON(req);
				if(data)
				{
					var cmb = $(".fortalezas");

						for (var i = 0; i < data.length; i++) {
							var option = $("<option></option>").attr("value", data[i]['id_ocupacion']).text(data[i]['nombre_ocupacion']).appendTo(cmb);
						}
				}
				else 
				{
					//msgNotificar("msgFooterDatos", "advertencia", "C&eacute;dula registrada en el sistema");
					notificar ("<li class='fa  fa-warning '/> Ocurrio un error. Contactar al Administrador", "type-danger");
				}  
			}
		
	});
}
/////////////////////////////////////////////////////////////////////////////////////////

//Cargar en tabla los Registrados en el sistema
function cargarTablaCandidatos(){
	//cedula=$("#cedulaimg").val();
	$.ajax({
		type:'POST',
		async:false,
		//url:"datosfrm.php",
		url:"trans/mSuplentes.php",	
		data:{"accion":"cargarCandidatos"},
		error:function(xhr,ajaxOptions,thrownError){
			//$('#msgFooterDatos').html('<div class="ui-state-error ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;Error!</strong> Intente nuevamente</h4></div>');
			//msgNotificar("msgFooterDatos", "error", " Error! Contactar con el administrador del sistema");
		},
		success:function(req){
  				var data=$.parseJSON(req);
				if(data)
				{
					//$("<span>Hello World!</span>").appendTo("#tablaCandidatos");
 					$('#tablaCandidatos').html("\
					<table id='tablaCandidatosAll' class='table table-bordered table-striped table-hover'> \
					<thead> \
					<th>CEDULA</th><th>NOMBRE</th><th>TELEFONO</th><th>EMAIL</th><th>SELECCIONAR</th> \
					</thead> \
					<tbody> \
					</tbody></table>")
					//$('#tablaCandidatosAll > tbody:last').append('<tr><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td></tr>');
					//alert(data[0]["usuario"])
					for (i = 0; i < data.length; i++) {
						if (!data[i]["telefono1"])
						{telefono="N/A"}
						else
						{telefono = data[i]["telefono1"]}
						$('#tablaCandidatosAll > tbody:last').append('<tr><td>'+data[i]["cedula"]+'</td><td>'+data[i]["nombres"]+' '+data[i]["apellidos"]+'</td><td>'+telefono+'</td><td>'+data[i]["email"]+'</td><td><button class="btn btn-block btn-info btn-xs" onclick="window.location.href =\'ficha.php?id_candidato='+data[i]["id_persona"]+'\'">Ver</button></td></tr>');
						//$('#tablaCandidatosAll > tbody:last').append('<tr><td>'+data[i]["cedula"]+'</td><td>'+data[i]["nombres"]+' '+data[i]["apellidos"]'</td><td>3</td><td>4</td><td>5</td></tr>');
					}
					
					//$('#tablaCandidatos').append("<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td></tr></tbody></table> ");
					$('#tablaCandidatosAll').dataTable( {
					"language": {"url": "../../plugins/datatables/dataTableSpanish.json"},
					 "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "Todos"]],
					 "columnDefs": [
						//{ "visible": false, "targets": 0 } 
			  ]
        } );
					 
				}
				else 
				{
					notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","Error al cargar datos", "type-danger");
				}  
			}
		
	});
}
/////////////////////////////////////////////////////////////////////////////////////////

//Cargar en tabla los Registrados en el sistema
function actualizarSSO(){
	
	id_persona=$("#id_candidato").val();
	fechanacsuplente=$("#fechanacsuplente").text();
	fechanac=fechanacsuplente.split('/');
	nacionalidad_aseg=$("#precedula").text();
	cedula_aseg=$("#cedula").text();
	if (fechanacsuplente == "Sin actualizar")
		{
			notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","La fecha de la nacimiento debe estar actualizada", "type-danger");
		}
	else
		{
			$.ajax({
				type:'POST',
				async:false,
				//url:"datosfrm.php",
				url:"trans/mSuplentes.php",	
				data:{"accion":"actualizarSSO","nacionalidad_aseg":nacionalidad_aseg, "cedula_aseg":cedula_aseg, "d":fechanac[0],"m":fechanac[1],"y":fechanac[2], "id_persona":id_persona},
				error:function(xhr,ajaxOptions,thrownError){
					//$('#msgFooterDatos').html('<div class="ui-state-error ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;Error!</strong> Intente nuevamente</h4></div>');
					//msgNotificar("msgFooterDatos", "error", " Error! Contactar con el administrador del sistema");
				},
				success:function(req){
						var data=$.parseJSON(req);
						if(data != 0)
						{
							$("#segurosocial").text(data);
						}
						else 
						{
							notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","Error al cargar datos", "type-danger");
						}  
					}
				
			});
		}
	
}
/////////////////////////////////////////////////////////////////////////////////////////

//Cargar en tabla los Registrados en el sistema segun su profesion
function cargarTablaCandidatosProfesion(){
	patronProfesion=$("#patronprofesion").val();
	nucleo=$("#nucleo").val();
	$.ajax({
		type:'POST',
		async:false,
		//url:"datosfrm.php",
		url:"trans/mSuplentes.php",	
		data:{"accion":"cargarCandidatosProfesion", "patronProfesion":patronProfesion, "nucleo":nucleo},
		error:function(xhr,ajaxOptions,thrownError){
			//$('#msgFooterDatos').html('<div class="ui-state-error ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;Error!</strong> Intente nuevamente</h4></div>');
			//msgNotificar("msgFooterDatos", "error", " Error! Contactar con el administrador del sistema");
		},
		success:function(req){
  				var data=$.parseJSON(req);
				if(data)
				{
					//$("<span>Hello World!</span>").appendTo("#tablaCandidatos");
					//alert(data.length)
 					$('#tablaCandidatos').html("\
					<table id='tablaCandidatosProfesion' class='table table-bordered table-striped table-hover'> \
					<thead> \
					<th>CEDULA</th><th>NOMBRE</th><th>TELEFONO</th><th>EMAIL</th><th>SELECCIONAR</th> \
					</thead> \
					<tbody> \
					</tbody></table>")
					//$('#tablaCandidatosAll > tbody:last').append('<tr><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td></tr>');
					//alert(data[0]["usuario"])
					for (i = 0; i < data.length; i++) {
						if (!data[i]["telefono1"])
						{telefono="N/A"}
						else
						{telefono = data[i]["telefono1"]}
						$('#tablaCandidatosProfesion > tbody:last').append('<tr><td>'+data[i]["cedula"]+'</td><td>'+data[i]["nombres"]+' '+data[i]["apellidos"]+'</td><td>'+telefono+'</td><td>'+data[i]["email"]+'</td><td><button class="btn btn-block btn-info btn-xs" onclick="window.location.href =\'ficha.php?id_candidato='+data[i]["id_persona"]+'\'">Ver</button></td></tr>');
						//$('#tablaCandidatosAll > tbody:last').append('<tr><td>'+data[i]["cedula"]+'</td><td>'+data[i]["nombres"]+' '+data[i]["apellidos"]'</td><td>3</td><td>4</td><td>5</td></tr>');
					}
					
					//$('#tablaCandidatos').append("<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td></tr></tbody></table> ");
					$('#tablaCandidatosProfesion').dataTable( {
					"language": {"url": "../../plugins/datatables/dataTableSpanish.json"},
					 "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "Todos"]],
					 "columnDefs": [
						//{ "visible": false, "targets": 0 } 
			  ]
        } );
					 
				}
				else 
				{
					notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","No hay datos registrados con ese patr&oacute;n", "type-warning");
				}  
			}
		
	});
}
/////////////////////////////////////////////////////////////////////////////////////////

//Cargar en tabla los Registrados en el sistema segun sus habilidades
function cargarTablaCandidatosCargos(){
	id_fortaleza=$("#idfortaleza").val();
	nucleo=$("#nucleo").val();
	//alert(id_fortaleza);
	$.ajax({
		type:'POST',
		async:false,
		//url:"datosfrm.php",
		url:"trans/mSuplentes.php",	
		data:{"accion":"cargarCandidatosCargo", "id_fortaleza":id_fortaleza, "nucleo":nucleo},
		error:function(xhr,ajaxOptions,thrownError){
			//$('#msgFooterDatos').html('<div class="ui-state-error ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;Error!</strong> Intente nuevamente</h4></div>');
			//msgNotificar("msgFooterDatos", "error", " Error! Contactar con el administrador del sistema");
		},
		success:function(req){
  				var data=$.parseJSON(req);
				if(data)
				{
					//$("<span>Hello World!</span>").appendTo("#tablaCandidatos");
					//alert(data.length)
 					$('#tablaCandidatos').html("\
					<table id='tablaCandidatosProfesion' class='table table-bordered table-striped table-hover'> \
					<thead> \
					<th>CEDULA</th><th>NOMBRE</th><th>TELEFONO</th><th>EMAIL</th><th>SELECCIONAR</th> \
					</thead> \
					<tbody> \
					</tbody></table>")
					//$('#tablaCandidatosAll > tbody:last').append('<tr><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td></tr>');
					//alert(data[0]["usuario"])
					for (i = 0; i < data.length; i++) {
						if (!data[i]["telefono1"])
						{telefono="N/A"}
						else
						{telefono = data[i]["telefono1"]}
						$('#tablaCandidatosProfesion > tbody:last').append('<tr><td>'+data[i]["cedula"]+'</td><td>'+data[i]["nombres"]+' '+data[i]["apellidos"]+'</td><td>'+telefono+'</td><td>'+data[i]["email"]+'</td><td><button class="btn btn-block btn-info btn-xs" onclick="window.location.href =\'ficha.php?id_candidato='+data[i]["id_persona"]+'\'">Ver</button></td></tr>');
						//$('#tablaCandidatosAll > tbody:last').append('<tr><td>'+data[i]["cedula"]+'</td><td>'+data[i]["nombres"]+' '+data[i]["apellidos"]'</td><td>3</td><td>4</td><td>5</td></tr>');
					}
					
					//$('#tablaCandidatos').append("<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td></tr></tbody></table> ");
					$('#tablaCandidatosProfesion').dataTable( {
					"language": {"url": "../../plugins/datatables/dataTableSpanish.json"},
					 "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "Todos"]],
					 "columnDefs": [
						//{ "visible": false, "targets": 0 } 
			  ]
        } );
					 
				}
				else 
				{
					notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","No hay datos registrados con ese patr&oacute;n", "type-warning");
				}  
			}
		
	});
}
/////////////////////////////////////////////////////////////////////////////////////////

//Cargar en tabla los Registrados en el sistema segun sus habilidades
function cargarTablaCandidatosNucleo(){
	nucleo=$("#nucleo").val();
	//alert(nucleo);
	$.ajax({
		type:'POST',
		async:false,
		//url:"datosfrm.php",
		url:"trans/mSuplentes.php",	
		data:{"accion":"cargarCandidatosNucleo", "nucleo":nucleo},
		error:function(xhr,ajaxOptions,thrownError){
			//$('#msgFooterDatos').html('<div class="ui-state-error ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;Error!</strong> Intente nuevamente</h4></div>');
			//msgNotificar("msgFooterDatos", "error", " Error! Contactar con el administrador del sistema");
		},
		success:function(req){
  				var data=$.parseJSON(req);
				if(data)
				{
					//$("<span>Hello World!</span>").appendTo("#tablaCandidatos");
					//alert(data.length)
 					$('#tablaCandidatos').html("\
					<table id='tablaCandidatosProfesion' class='table table-bordered table-striped table-hover'> \
					<thead> \
					<th>CEDULA</th><th>NOMBRE</th><th>TELEFONO</th><th>EMAIL</th><th>SELECCIONAR</th> \
					</thead> \
					<tbody> \
					</tbody></table>")
					//$('#tablaCandidatosAll > tbody:last').append('<tr><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td></tr>');
					//alert(data[0]["usuario"])
					for (i = 0; i < data.length; i++) {
						if (!data[i]["telefono1"])
						{telefono="N/A"}
						else
						{telefono = data[i]["telefono1"]}
						$('#tablaCandidatosProfesion > tbody:last').append('<tr><td>'+data[i]["cedula"]+'</td><td>'+data[i]["nombres"]+' '+data[i]["apellidos"]+'</td><td>'+telefono+'</td><td>'+data[i]["email"]+'</td><td><button class="btn btn-block btn-info btn-xs" onclick="window.location.href =\'ficha.php?id_candidato='+data[i]["id_persona"]+'\'">Ver</button></td></tr>');
						//$('#tablaCandidatosAll > tbody:last').append('<tr><td>'+data[i]["cedula"]+'</td><td>'+data[i]["nombres"]+' '+data[i]["apellidos"]'</td><td>3</td><td>4</td><td>5</td></tr>');
					}
					
					//$('#tablaCandidatos').append("<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td></tr></tbody></table> ");
					$('#tablaCandidatosProfesion').dataTable( {
					"language": {"url": "../../plugins/datatables/dataTableSpanish.json"},
					 "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "Todos"]],
					 "columnDefs": [
						//{ "visible": false, "targets": 0 } 
			  ]
        } );
					 
				}
				else 
				{
					notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","No candidatos registrados para ese Núcleo", "type-warning");
				}  
			}
		
	});
}
/////////////////////////////////////////////////////////////////////////////////////////



function actualizarDatosCandidato(datafrm){
	
	$.ajax({
		type:'POST',
		async:false,
		//url:"datosfrm.php",
		url:"trans/mSuplentes.php",	
		data:datafrm,
		error:function(xhr,ajaxOptions,thrownError){
			//$('#msgFooterDatos').html('<div class="ui-state-error ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;Error!</strong> Intente nuevamente</h4></div>');
			notificar("msgFooterDatos", "error", " Error! Contactar con el administrador del sistema");
		},
		success:function(req){			
			
 				var data=req;
				if(data == 1){
					notificar ("<li class='fa  fa-warning '/> Aviso","El&nbsp;&nbsp;<b>EMAIL</b>&nbsp;&nbsp;se encuentra registrado en el sistema", "type-warning");
				}
				else
				{
					notificar ("<li class='fa  fa-check '/> Notificaci&oacute;n","Registros acutalizados exitosamente", "type-success");
				}
/* 				else if(data == 1){
					$('#tabSoportes').removeClass("disabled");
					$("#tabSoportes").tooltip("disable");
					var i=0; for (i=1;i<=1;i++) {
						//$('form > input')[i].val("Funciono");
						$('form').each(function(){
							//$(this).find("input #idCedula").text("Funciono");
							idFrm=$(this).attr("id");
							//alert($( "#"+idFrm+" input:first" ).val());
						});
						
					} 
					notificar("msgFooterDatos", "exito", "Registro ingresado exitosamente");
					
				} 				
				else if(data == 2){
					notificar ("<li class='fa  fa-warning '/> Aviso","La&nbsp;&nbsp;<b>C&Eacute;DULA</b>&nbsp;&nbsp;se encuentra reistrada en el sistenma", "type-warning");
				} */ 
			}
		
	});
}
//···················· Carga de archivos JPG/PNG························
function subirImagen(datafrm, campo){
			var id_persona = $("#id_persona").val();
			$.ajax({
			url:"soportes/subirImgExt.php",  //Server script to process data
			//url: 'datosfrm.php',  //Server script to process data
			type: 'POST',
/* 			xhr: function() {  // Custom XMLHttpRequest
				var myXhr = $.ajaxSettings.xhr();
				if(myXhr.upload){ // Check if upload property exists
					//myXhr.upload.addEventListener('progress',progressHandlingFunction, false); // For handling the progress of the upload
				}
				return myXhr;
			}, */
			//Ajax events
			//beforeSend: beforeSendHandler,
			success:function(resultado){
				if (resultado == 1)
				{	
					switch (campo) {
					case 'btnImgFoto':
					$("#progFoto").removeClass('bg-red color-palette');
					$("#progFoto").addClass('bg-green color-palette');
					$("#progFoto").html('&nbsp;Dato cargado');
					$('#verImgFoto').prop('disabled', false);
					$("#verImgFoto").attr('href','soportes/'+id_persona+'/fotocarnet.jpg');
					break;
					case 'btnImgCed':
					$("#progCedula").removeClass('bg-red color-palette');
					$("#progCedula").addClass('bg-green color-palette');
					$("#progCedula").html('&nbsp;Dato cargado');
					$('#verImgCedula').prop('disabled', false);
					$("#verImgCedula").attr('href','soportes/'+id_persona+'/cedula.jpg');
					break;
					case 'btnImgSalud':
					$("#progSalud").removeClass('bg-red color-palette');
					$("#progSalud").addClass('bg-green color-palette');
					$("#progSalud").html('&nbsp;Dato cargado');
					$('#verImgSalud').prop('disabled', false);
					$("#verImgSalud").attr('href','soportes/'+id_persona+'/certificado_salud.jpg');
					break;
					case 'btnImgBco':
					$("#progBanco").removeClass('bg-red color-palette');
					$("#progBanco").addClass('bg-green color-palette');
					$("#progBanco").html('&nbsp;Dato cargado');
					$('#verImgBanco').prop('disabled', false);
					$("#verImgBanco").attr('href','soportes/'+id_persona+'/cta_bancaria.jpg');
					break;
					case 'btnImgTit':
					$("#progTitulo").removeClass('bg-red color-palette');
					$("#progTitulo").addClass('bg-green color-palette');
					$("#progTitulo").html('&nbsp;Dato cargado');
					$('#verImgTitulo').prop('disabled', false);
					$("#verImgTitulo").attr('href','soportes/'+id_persona+'/titulo.jpg');
					break;
/* 					case 'btnPdfCV':
					$("#progCV").removeClass('bg-red color-palette');
					$("#progCV").addClass('bg-green color-palette');
					$("#progCV").html('&nbsp;Dato cargado');
					$('#verCV').prop('disabled', false);
					$("#verCV").attr('href','soportes/'+id_persona+'/curriculum.pdf');
					break; */
					}
				}
				else
				{
					notificar ("Aviso",resultado, "type-warning");
				}
					
			},
			//error: errorHandler,
			// Form data
			//data: {datafrm,"unvalor":"123"},
			data: datafrm,
			//Options to tell jQuery not to process data or worry about content-type.
			cache: false,
			contentType: false,
			processData: false
		}); //*****Fin $.ajax UPLOAD
}
//···················· Carga de archivos PDF························
function subirPDF(datafrm){
		var id_persona = $("#id_persona").val();
			$.ajax({
			url:"soportes/subirPdfEXT.php",  //Server script to process data
			//url: 'datosfrm.php',  //Server script to process data
			type: 'POST',
/* 			xhr: function() {  // Custom XMLHttpRequest
				var myXhr = $.ajaxSettings.xhr();
				if(myXhr.upload){ // Check if upload property exists
					//myXhr.upload.addEventListener('progress',progressHandlingFunction, false); // For handling the progress of the upload
				}
				return myXhr;
			}, */
			//Ajax events
			//beforeSend: beforeSendHandler,
			success:function(resultado){
				if (resultado == 1)
				{
					$("#progCV").removeClass('bg-red color-palette');
					$("#progCV").addClass('bg-green color-palette');
					$("#progCV").html('&nbsp;Dato cargado');
					$('#verCV').prop('disabled', false);
					$("#verCV").attr('href','soportes/'+id_persona+'/curriculum.pdf');
				}
				else
				{
					notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n",resultado, "type-warning");
				}
					
			},
			//error: errorHandler,
			// Form data
			//data: {datafrm,"unvalor":"123"},
			data: datafrm,
			//Options to tell jQuery not to process data or worry about content-type.
			cache: false,
			contentType: false,
			processData: false
		}); //*****Fin $.ajax UPLOAD
}


/* function guardarActualizarSuplente(datafrm){
	cedula=$("#cedulaimg").val();
	$.ajax({
		type:'POST',
		async:false,
		//url:"datosfrm.php",
		url:"trans/mSuplentes.php",	
		data:datafrm,
		error:function(xhr,ajaxOptions,thrownError){
			//$('#msgFooterDatos').html('<div class="ui-state-error ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;Error!</strong> Intente nuevamente</h4></div>');
			msgNotificar("msgFooterDatos", "error", " Error! Contactar con el administrador del sistema");
		},
		success:function(req){			
			
 				var data=req;
				if(data == 0){
					msgNotificar("msgFooterDatos", "advertencia", "Verificar los datos");
				}
				else if(data == 1){
					$('#tabSoportes').removeClass("disabled");
					$("#tabSoportes").tooltip("disable");
					var i=0; for (i=1;i<=1;i++) {
						//$('form > input')[i].val("Funciono");
						$('form').each(function(){
							//$(this).find("input #idCedula").text("Funciono");
							idFrm=$(this).attr("id");
							//alert($( "#"+idFrm+" input:first" ).val());
						});
						
					} 
					msgNotificar("msgFooterDatos", "exito", "Registro ingresado exitosamente");
					
				} 				
				else if(data == 2){
					msgNotificar("msgFooterDatos", "advertencia", "C&eacute;dula registrada en el sistema");
				} 
			}
		
	});
}
//···················· Carga de archivos ························
function subirArchivo(datafrm){
			$.ajax({
			url: 'soportes/subirImg.php',  //Server script to process data
			//url: 'datosfrm.php',  //Server script to process data
			type: 'POST',
			xhr: function() {  // Custom XMLHttpRequest
				var myXhr = $.ajaxSettings.xhr();
				if(myXhr.upload){ // Check if upload property exists
					myXhr.upload.addEventListener('progress',progressHandlingFunction, false); // For handling the progress of the upload
				}
				return myXhr;
			},
			//Ajax events
			//beforeSend: beforeSendHandler,
			//success: completeHandler,
			//error: errorHandler,
			// Form data
			//data: {datafrm, 'cedula':'123'},
			data: datafrm,
			//Options to tell jQuery not to process data or worry about content-type.
			cache: false,
			contentType: false,
			processData: false
		}); //*****Fin $.ajax UPLOAD
}
function progressHandlingFunction(e){
    if(e.lengthComputable){
        //$('#progceula').attr({'style', 'width:'+e.loaded,max:e.total;});
		$( "#progcedula" ).css( "width", e.loaded );
       
    }

}
//···················· Fin de carga de archivos ························ */

//····················Botones de carga de archivo y envio de datos························
$(':button').click(function(){
	//var valido =0;
	switch ($(this).attr('id')) {
	case 'btnGuardar':
        //var formData = new FormData($('form')[0]);
		var profesionsuplente=$("#profesionsuplente").val();
		var nombresuplente=$("#nombresuplente").val();
		var apellidossuplente=$("#apellidossuplente").val();
		var sexo=$("#sexo").val();
		var motricidad=$("#motricidad").val();
		var precedula=$("#precedula").val();
		var cedulasuplente=$("#cedulasuplente").val();
		var emailsuplente=$("#emailsuplente").val();
		var telefono1=$("#telefono1").val();
		var telefono2=$("#telefono2").val();
		var fortaleza1=$("#fortaleza1").val();
		var fortaleza2=$("#fortaleza2").val();
		var fortaleza3=$("#fortaleza3").val();
		emailvalido = validarEmail (emailsuplente);
		
		if (profesionsuplente == "")
		{
			$("#grupoProfesion").addClass("has-error");
			$("#profesionsuplente").attr("title", "Ingresar la profesi&oacute;n del candidato");
		}
		else if (nombresuplente == "")
		{
			$("#grupoNombres").addClass("has-error")
			$("#nombresuplente").attr("title", "Ingresar los nombres del candidato");
		}
		else if (apellidossuplente == "")
		{
			$("#grupoApellidos").addClass("has-error")
			$("#apellidossuplente").attr("title", "Ingresar los apellidos del candidato");
		}
		else if (cedulasuplente == "")
		{
			$("#grupoCedula").addClass("has-error")
			$("#cedulasuplente").attr("title", "Ingresar la c&eacute;dula del candidato");
		}
		else if (emailsuplente == "" &&  telefono1 == "" &&  telefono2 == "")
		{
			$("#grupoEmail").addClass("has-error");
			$("#grupoTlf1").addClass("has-error");
			$("#grupoTlf2").addClass("has-error");
			//if( $('#msgFooterDatos').length )         // use this if you are using id to check 
			//{
			     //$('#msgFooterDatos').html('<div class="alert alert-warning alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> <strong>Aviso!</strong> Debe ingresar alg&uacute;n dato de contacto (Email o Tel&eacute;fono)</h4></div>');
			     //$('#msgFooterDatos').html('<div class="ui-state-error ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;Aviso!</strong> Debe ingresar alg&uacute;n dato de contacto (Email o Tel&eacute;fono)</h4></div>');
				 notificar ("Aviso","Debe ingresar alg&uacute;n dato de contacto (Email o Tel&eacute;fono)", "type-warning");
			//}
			//$('#dialogo').html('Debe ingresar alg&uacute;n dato de contacto (Email o Tel&eacute;fono)');
			//$('#dialogo').dialog('open');
		}
		else if (!emailvalido)
		{
			$("#grupoEmail").addClass("has-error")
			$("#emailsuplente").attr("title", "Ingresar un formato de email valido");
		}
		else
		{
			//valido =0;
			//var formData = "{'data1':'" + nombresuplente+ "', 'data2':'" + cedulasuplente+ "', 'data3':'" + emailasuplente+ "'}";
			var formData = {accion: 'actualizarDatosCandidato', profesion: profesionsuplente, nombres: nombresuplente, apellidos: apellidossuplente, cedula: precedula + '-' + cedulasuplente, email: emailsuplente, telefono1: telefono1, telefono2: telefono2, fortaleza1: fortaleza1, fortaleza2: fortaleza2, fortaleza3: fortaleza3,sexo:sexo,motricidad:motricidad};
			actualizarDatosCandidato(formData);
		}
        break;
    case 'btnImgFoto':
		if ($("#imgfoto").val() != '')
		{
			var formData = new FormData($("#formFotoCarnet")[0]);
			subirImagen(formData, $(this).attr('id'));
		}
		else
		{
			notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","Seleccione una foto tipo carnet para subir", "type-warning");
		}
        break;
	case 'btnImgCed':
		if ($("#imgcedula").val() != '')
		{
			var formData = new FormData($("#formCedula")[0]);
			subirImagen(formData, $(this).attr('id'));
		}
		else
		{
			notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","Seleccione una imagen de su cedula para subir", "type-warning");
		}
        break;
    case 'btnImgSalud':
		if ($("#imgsalud").val() != '')
		{
			var formData = new FormData($("#formSalud")[0]);
			subirImagen(formData, $(this).attr('id'));
		}
		else
		{
			notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","Seleccione una imagen de su certificado de salud para subir", "type-warning");
		}
        break;
    case 'btnImgBco':
		if ($("#imgBanco").val() != '')
		{
			var formData = new FormData($("#formBanco")[0]);
			subirImagen(formData, $(this).attr('id'));
		}
		else
		{
			notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","Seleccione una imagen de un cheque o libreta a su nombre para subir", "type-warning");
		}
        break;
    case 'btnImgTit':
		if ($("#imgtitulo").val() != '')
		{
			var formData = new FormData($("#formTitulo")[0]);
			subirImagen(formData, $(this).attr('id'));
		}
		else
		{
			notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","Seleccione una imagen en fondo negro de su titulo para subir", "type-warning");
		}
        break;
    case 'btnPdfCV':
		if ($("#pdfcurriculum").val() != '')
		{
			var formData = new FormData($("#formCurriculum")[0]);
			subirPDF(formData);
		}
		else
		{
			notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","Seleccione un archivo en formato PDF de su Curriculum vitae para subir", "type-warning");
		}
        break;

	default:
/* 		$("#botonGuardar").show();
		$('#dialogo').html('');
		$('#dialogo').dialog('open'); */
	}
	//$( "#tabSoportes" ).tooltip( "disable" );
	
}); 
//********************Fin evento click del boton*******************
function validarEmail (email)
{

// Verificar el formato del email
var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
var valido = filter.test(email);
return valido
//*****************

}

	
//************PREVIENE EL CLICK EN LAS TABS DESABILITADAS**********************
/* $('a[data-toggle="tab"]').on('click', function(){
  if ($(this).parent('li').hasClass('disabled')) {
    return false;
  };
}); */

