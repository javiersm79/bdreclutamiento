function validarCandidato(clave){
$("#estatusCandidato").html('<pre class="col-sm-6 text-muted bg-green color-palette"><span class="fa fa-warning"></span> Existen datos sin cargar.. Favor verificar</pre>');
}

function guardarNuevaClave(clave){
 	$.ajax({
		type:'POST',
		async:false,
		//url:"datosfrm.php",
		url:'trans/mSuplentesExt.php',	
		data:{'accion':'guardarNuevaClave','clave':clave},
		//data:{'accion':'guardarNuevaClave'},
		error:function(xhr,ajaxOptions,thrownError){
			//$('#msgFooterDatos').html('<div class="ui-state-error ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;Error!</strong> Intente nuevamente</h4></div>');
			msgNotificar("capamensaje", "error", "ERROR AL CONECTAR CON EL SERVIDOR");
		},
		success:function(req){			
				
				resultado = req;
			}
		
	});
return resultado;
}



function actualizarClave(){

mnsj = ' \
<div class="input-group"> \
  <span class="input-group-addon">Clave &nbsp;&nbsp;</span> \
  <input type="password" id="clave1" class="form-control" maxlength=8> \
</div> <br \>\
<div class="input-group"> \
  <span class="input-group-addon">Repetir</span> \
  <input type="password" id="clave2" class="form-control" maxlength=8> \
</div><br \>\
<div id="capamensaje" class="input-group"></div>';

BootstrapDialog.show({
            title: 'Actualizar Clave de Ingreso',
            message: mnsj,
			size: BootstrapDialog.SIZE_SMALL,
            buttons: [{
				icon: 'glyphicon glyphicon-ok',
                label: 'Cambiar',
                cssClass: 'btn-success',
                action: function(){
                    //alert('Clave Cambiada');
					var claves = [$("#clave1").val(), $("#clave2").val()];
				if (claves[0] != claves[1])
					{msgNotificar("capamensaje", "error", "Claves distintas")}
				else if (claves[0].length < 4)
					{msgNotificar("capamensaje", "error", "Ingrese m&iacute;nimo 4 caracteres")}
				else
					{
						var guardado = guardarNuevaClave(claves[0])
						//alert (guardado)
						if (guardado > 0)
						{msgNotificar("capamensaje", "exito", "Clave Cambiada")}
						else
						{msgNotificar("capamensaje", "advertencia", "Error! Intente de nuevo")}
				
					} 
                }
            }, {
                icon: 'glyphicon glyphicon-ban-circle',
                label: 'Cancelar',
                cssClass: 'btn-danger',
				action: function(dialogItself){
                    dialogItself.close();
                }
            }]
        });		
		
		
		
}

//Buscar datos de Personas Reguistradas en el sistema
function buscarDatosCandidato(){
	//cedula=$("#cedulaimg").val();
	$.ajax({
		type:'POST',
		async:false,
		//url:"datosfrm.php",
		url:"trans/mSuplentesExt.php",	
		data:{"accion":"buscarDatosCandidato"},
		error:function(xhr,ajaxOptions,thrownError){
			//$('#msgFooterDatos').html('<div class="ui-state-error ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;Error!</strong> Intente nuevamente</h4></div>');
			msgNotificar("msgFooterDatos", "error", " Error! Contactar con el administrador del sistema");
		},
		success:function(req){			
			
 				var data=$.parseJSON(req);
				if(data)
				{
					//var validarPerfil = data[0]["validar_perfil"]
					//alert(data[0]["profesionsuplente"]);
					validar_adjuntos = 1
					$("#nucleo").val(data[0]["nucleo"]);
					$("#profesionsuplente").val(data[0]["profesion"]);
					$("#nombresuplente").val(data[0]["nombres"]);
					$("#apellidossuplente").val(data[0]["apellidos"]);
					//alert(data[0]["cedula"].substring(0, 1));
					$("#precedula").val(data[0]["cedula"].substring(0, 1));
					$("#cedulasuplente").val(data[0]["cedula"].substring(2, 13));
					if (data[0]["fechanac"]){
					fechanac=data[0]["fechanac"].split('-');
					$("#fechanacsuplente").val(fechanac[2]+'/'+fechanac[1]+'/'+fechanac[0]);
					}
					$("#emailsuplente").val(data[0]["email"]);
					$("#estadosuplente").val(data[0]["estado"]);
					//alert(data[0]["estado"]);
					$("#municipiosuplente").val(data[0]["municipio"]);
					$("#parroquiasuplente").val(data[0]["parroquia"]);
					$("#telefono1").val(data[0]["telefono1"]);
					$("#telefono2").val(data[0]["telefono2"]);
					//FORTALEZAS
					$('#fortaleza1 option[value='+data[0]["fortaleza1"]+']').attr("selected", "selected").change();
					$('#fortaleza2 option[value='+data[0]["fortaleza2"]+']').attr("selected", "selected").change();
					$('#fortaleza3 option[value='+data[0]["fortaleza3"]+']').attr("selected", "selected").change();
					//Banco
					//$("#banco").text(data[0]["banco"]);
					$("#banco").val(data[0]["banco"]).change();
					$("#tipoctabancaria").val(data[0]["tipoctabancaria"]).change();
					$("#nctabnacaria").val(data[0]["nctabnacaria"]);
					//OTROS
					$('#sexo option[value='+data[0]["sexo"]+']').attr("selected", "selected").change();
					$('#motricidad option[value='+data[0]["motricidad"]+']').attr("selected", "selected").change();
					//alert (data[0]["sexo"]);
					
					
					if (data[0]["fotoimg"]==0){
						$("#verImgFoto").attr('disabled','disabled');
						$("#progFoto").addClass('bg-red color-palette');
						$("#progFoto").html('&nbsp;Dato sin cargar');
						validar_adjuntos = 0
						
					}
					else 
					{
						$("#verImgFoto").attr('href','soportes/'+data[0]["id_persona"]+'/fotocarnet.jpg');
						$("#progFoto").addClass('bg-aqua color-palette');
						$("#progFoto").html('&nbsp;Dato cargado');
					}
					
					if (data[0]["cedulaimg"]==0){
						$("#verImgCedula").attr('disabled','disabled');
						$("#progCedula").addClass('bg-red color-palette');
						$("#progCedula").html('&nbsp;Dato sin cargar');
						validar_adjuntos = 0
						
					}
					else 
					{
						$("#verImgCedula").attr('href','soportes/'+data[0]["id_persona"]+'/cedula.jpg');
						$("#progCedula").addClass('bg-aqua color-palette');
						$("#progCedula").html('&nbsp;Dato Cargado');
					}
					
					if (data[0]["saludimg"]==0){
						$("#verImgSalud").attr('disabled','disabled');
						$("#progSalud").addClass('bg-red color-palette');
						$("#progSalud").html('&nbsp;Dato sin cargar');
						validar_adjuntos = 0
						
					}
					else 
					{
						$("#verImgSalud").attr('href','soportes/'+data[0]["id_persona"]+'/certificado_salud.jpg');
						$("#progSalud").addClass('bg-aqua color-palette');
						$("#progSalud").html('&nbsp;Dato sin cargar');
					}
											
					if (data[0]["bancoimg"]==0){
						$("#verImgBanco").attr('disabled','disabled');
						$("#progBanco").addClass('bg-red color-palette');
						$("#progBanco").html('&nbsp;Dato sin cargar');
						validar_adjuntos = 0
					}
					else 
					{
						$("#verImgBanco").attr('href','soportes/'+data[0]["id_persona"]+'/cta_bancaria.jpg');
						$("#progBanco").addClass('bg-aqua color-palette');
						$("#progBanco").html('&nbsp;Dato Cargado');
					}
					
					if (data[0]["tituloimg"]==0){
						$("#verImgTitulo").attr('disabled','disabled');
						$("#progTitulo").addClass('bg-red color-palette');
						$("#progTitulo").html('&nbsp;Dato sin cargar');
						validar_adjuntos = 0
					}
					else 
					{
						$("#verImgTitulo").attr('href','soportes/'+data[0]["id_persona"]+'/titulo.jpg');
						$("#progTitulo").addClass('bg-aqua color-palette');
						$("#progTitulo").html('&nbsp;Dato Cargado');
					}
						
					if (data[0]["curriculumpdf"]==0){
						$("#verCV").attr('disabled','disabled');
						$("#progCV").addClass('bg-red color-palette');
						$("#progCV").html('&nbsp;Dato sin cargar');
						validar_adjuntos = 0
					}
					else 
					{
						$("#verCV").attr('href','soportes/'+data[0]["id_persona"]+'/curriculum.pdf');
						$("#progCV").addClass('bg-aqua color-palette');
						$("#progCV").html('&nbsp;Dato Cargado');
					}
					//validar_adjuntos = 1
					if (data[0]["validar_datos"]==0 || validar_adjuntos == 0){
						$('#estatusCandidato').html('<div class="alert alert-warning ui-corner-all" style="padding: 2px; height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;Perfil con datos sin completar.. Complete los campos para pasar a la Base de Datos de Elegibles</strong></h4></div>');
	
					}
					else 
					{
						$('#estatusCandidato').html('<div class="alert alert-success ui-corner-all" style="padding: 2px; height:30px;">&nbsp;<i class="icon fa fa-check"></i><strong>&nbsp;Perfil con todos los datos completado..  Usted se encuentra en la Base de Datos de Elegibles</strong></h4></div>');
					}
						
					
					
					
				}
				else 
				{
					//msgNotificar("msgFooterDatos", "advertencia", "C&eacute;dula registrada en el sistema");
					notificar ("<li class='fa  fa-warning '/> Ocurrio un error. Contactar al Administrador", "type-danger");
				} 
			}
		
	});
}
/////////////////////////////////////////////////////////////////////////////////////////

//Buscar datos de Personas Registrados en el sistema
function cargarOcupaciones(){
	//cedula=$("#cedulaimg").val();
	$.ajax({
		type:'POST',
		async:false,
		//url:"datosfrm.php",
		url:"trans/mSuplentes.php",	
		data:{"accion":"cargarOcupaciones"},
		error:function(xhr,ajaxOptions,thrownError){
			//$('#msgFooterDatos').html('<div class="ui-state-error ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;Error!</strong> Intente nuevamente</h4></div>');
			//msgNotificar("msgFooterDatos", "error", " Error! Contactar con el administrador del sistema");
		},
		success:function(req){
  				var data=$.parseJSON(req);
				if(data)
				{
					var cmb = $(".fortalezas");
					//var cmb1 = $("#fortaleza1");
						//cmb1.empty();
					//var cmb2 = $("#fortaleza2");
						//cmb2.empty();
					//var cmb3 = $("#fortaleza3");
						//cmb3.empty();
						//var option = $("<option></option>").attr("value", 0).text("Seleccione").appendTo(cmb);
						for (var i = 0; i < data.length; i++) {
							var option = $("<option></option>").attr("value", data[i]['id_ocupacion']).text(data[i]['nombre_ocupacion']).appendTo(cmb);
							//var option = $("<option></option>").attr("value", data[i]['id_ocupacion']).text(data[i]['nombre_ocupacion']).appendTo(cmb2);
							//var option = $("<option></option>").attr("value", data[i]['id_ocupacion']).text(data[i]['nombre_ocupacion']).appendTo(cmb3);
						}
				}
				else 
				{
					//msgNotificar("msgFooterDatos", "advertencia", "C&eacute;dula registrada en el sistema");
					notificar ("<li class='fa  fa-warning '/> Ocurrio un error. Contactar al Administrador", "type-danger");
				}  
			}
		
	});
}
/////////////////////////////////////////////////////////////////////////////////////////

function actualizarDatosCandidato(datafrm){
	//cedula=$("#cedulaimg").val();
	$.ajax({
		type:'POST',
		async:false,
		//url:"datosfrm.php",
		url:"trans/mSuplentesExt.php",	
		data:datafrm,
		error:function(xhr,ajaxOptions,thrownError){
			//$('#msgFooterDatos').html('<div class="ui-state-error ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;Error!</strong> Intente nuevamente</h4></div>');
			notificar("msgFooterDatos", "error", " Error! Contactar con el administrador del sistema");
		},
		success:function(req){			
			
 				var data=req;
				if(data == 1){
					notificar ("<li class='fa  fa-warning '/> Aviso","El&nbsp;&nbsp;<b>EMAIL</b>&nbsp;&nbsp;se encuentra registrado en el sistema", "type-warning");
				}
				else
				{
					notificar ("<li class='fa  fa-check '/> Notificaci&oacute;n","Registros acutalizados exitosamente", "type-success");
				}
/* 				else if(data == 1){
					$('#tabSoportes').removeClass("disabled");
					$("#tabSoportes").tooltip("disable");
					var i=0; for (i=1;i<=1;i++) {
						//$('form > input')[i].val("Funciono");
						$('form').each(function(){
							//$(this).find("input #idCedula").text("Funciono");
							idFrm=$(this).attr("id");
							//alert($( "#"+idFrm+" input:first" ).val());
						});
						
					} 
					notificar("msgFooterDatos", "exito", "Registro ingresado exitosamente");
					
				} 				
				else if(data == 2){
					notificar ("<li class='fa  fa-warning '/> Aviso","La&nbsp;&nbsp;<b>C&Eacute;DULA</b>&nbsp;&nbsp;se encuentra reistrada en el sistenma", "type-warning");
				} */ 
			}
		
	});
}
//···················· Carga de archivos JPG/PNG························
function subirImagen(datafrm, campo){
			var id_persona = $("#id_persona").val();
			$.ajax({
			url:"soportes/subirImgExt.php",  //Server script to process data
			//url: 'datosfrm.php',  //Server script to process data
			type: 'POST',
/* 			xhr: function() {  // Custom XMLHttpRequest
				var myXhr = $.ajaxSettings.xhr();
				if(myXhr.upload){ // Check if upload property exists
					//myXhr.upload.addEventListener('progress',progressHandlingFunction, false); // For handling the progress of the upload
				}
				return myXhr;
			}, */
			//Ajax events
			//beforeSend: beforeSendHandler,
			success:function(resultado){
				if (resultado == 1)
				{	
					switch (campo) {
					case 'btnImgFoto':
					$("#progFoto").removeClass('bg-red color-palette');
					$("#progFoto").addClass('bg-green color-palette');
					$("#progFoto").html('&nbsp;Dato cargado');
					$('#verImgFoto').prop('disabled', false);
					$("#verImgFoto").attr('href','soportes/'+id_persona+'/fotocarnet.jpg');
					break;
					case 'btnImgCed':
					$("#progCedula").removeClass('bg-red color-palette');
					$("#progCedula").addClass('bg-green color-palette');
					$("#progCedula").html('&nbsp;Dato cargado');
					$('#verImgCedula').prop('disabled', false);
					$("#verImgCedula").attr('href','soportes/'+id_persona+'/cedula.jpg');
					break;
					case 'btnImgSalud':
					$("#progSalud").removeClass('bg-red color-palette');
					$("#progSalud").addClass('bg-green color-palette');
					$("#progSalud").html('&nbsp;Dato cargado');
					$('#verImgSalud').prop('disabled', false);
					$("#verImgSalud").attr('href','soportes/'+id_persona+'/certificado_salud.jpg');
					break;
					case 'btnImgBco':
					$("#progBanco").removeClass('bg-red color-palette');
					$("#progBanco").addClass('bg-green color-palette');
					$("#progBanco").html('&nbsp;Dato cargado');
					$('#verImgBanco').prop('disabled', false);
					$("#verImgBanco").attr('href','soportes/'+id_persona+'/cta_bancaria.jpg');
					break;
					case 'btnImgTit':
					$("#progTitulo").removeClass('bg-red color-palette');
					$("#progTitulo").addClass('bg-green color-palette');
					$("#progTitulo").html('&nbsp;Dato cargado');
					$('#verImgTitulo').prop('disabled', false);
					$("#verImgTitulo").attr('href','soportes/'+id_persona+'/titulo.jpg');
					break;
/* 					case 'btnPdfCV':
					$("#progCV").removeClass('bg-red color-palette');
					$("#progCV").addClass('bg-green color-palette');
					$("#progCV").html('&nbsp;Dato cargado');
					$('#verCV').prop('disabled', false);
					$("#verCV").attr('href','soportes/'+id_persona+'/curriculum.pdf');
					break; */
					}
				}
				else
				{
					notificar ("Aviso",resultado, "type-warning");
				}
					
			},
			//error: errorHandler,
			// Form data
			//data: {datafrm,"unvalor":"123"},
			data: datafrm,
			//Options to tell jQuery not to process data or worry about content-type.
			cache: false,
			contentType: false,
			processData: false
		}); //*****Fin $.ajax UPLOAD
}
//···················· Carga de archivos PDF························
function subirPDF(datafrm){
		var id_persona = $("#id_persona").val();
			$.ajax({
			url:"soportes/subirPdfEXT.php",  //Server script to process data
			//url: 'datosfrm.php',  //Server script to process data
			type: 'POST',
/* 			xhr: function() {  // Custom XMLHttpRequest
				var myXhr = $.ajaxSettings.xhr();
				if(myXhr.upload){ // Check if upload property exists
					//myXhr.upload.addEventListener('progress',progressHandlingFunction, false); // For handling the progress of the upload
				}
				return myXhr;
			}, */
			//Ajax events
			//beforeSend: beforeSendHandler,
			success:function(resultado){
				if (resultado == 1)
				{
					$("#progCV").removeClass('bg-red color-palette');
					$("#progCV").addClass('bg-green color-palette');
					$("#progCV").html('&nbsp;Dato cargado');
					$('#verCV').prop('disabled', false);
					$("#verCV").attr('href','soportes/'+id_persona+'/curriculum.pdf');
				}
				else
				{
					notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n",resultado, "type-warning");
				}
					
			},
			//error: errorHandler,
			// Form data
			//data: {datafrm,"unvalor":"123"},
			data: datafrm,
			//Options to tell jQuery not to process data or worry about content-type.
			cache: false,
			contentType: false,
			processData: false
		}); //*****Fin $.ajax UPLOAD
}
/* function progressHandlingFunction(e){
    if(e.lengthComputable){
        //$('#progceula').attr({'style', 'width:'+e.loaded,max:e.total;});
		$( "#progcedula" ).css( "width", e.loaded );
       
    } 

}*/
//···················· Fin de carga de archivos ························

//····················Botones de carga de archivo y envio de datos························
$(':button').click(function(){
	//var valido =0;
	switch ($(this).attr('id')) {
	case 'btnGuardar':
        //var formData = new FormData($('form')[0]);
		var nucleosuplente=$("#nucleo").val();
		var profesionsuplente=$("#profesionsuplente").val();
		var nombresuplente=$("#nombresuplente").val();
		var apellidossuplente=$("#apellidossuplente").val();
		var sexo=$("#sexo").val();
		var motricidad=$("#motricidad").val();
		var fechanacsuplente=$("#fechanacsuplente").val().split('/');
		//var dateAr = '2014-01-06'.split('-');
		//var newDate = fechanacsuplente[1] + '-' + fechanacsuplente[2] + '-' + fechanacsuplente[0];
		//var date = moment(); //Get the current date
		//date.format("YYYY-MM-DD"); //2014-07-10
		//alert (moment(fechanacsuplente, "YYYYMMDD"));
		var precedula=$("#precedula").val();
		var cedulasuplente=$("#cedulasuplente").val();
		var emailsuplente=$("#emailsuplente").val();
		var telefono1=$("#telefono1").val();
		var telefono2=$("#telefono2").val();
		var fortaleza1=$("#fortaleza1").val();
		var fortaleza2=$("#fortaleza2").val();
		var fortaleza3=$("#fortaleza3").val();
		var banco=$("#banco").val();
		var tipoctabancaria=$("#tipoctabancaria").val();
		var nctabnacaria=$("#nctabnacaria").val();
		emailvalido = validarEmail (emailsuplente);
		//alert (nucleosuplente);
		if (profesionsuplente == "")
		{
			$("#grupoProfesion").addClass("has-error");
			$("#profesionsuplente").attr("title", "Ingresar la(s) profesión(es) que tiene");
			notificar ("<li class='fa  fa-warning '/> Notificacion","Ingrese una profesión", "type-warning");
		}
		else if (nucleosuplente == "0")
		{
			$("#grupoNucleo").addClass("has-error")
			$("#nucleo").attr("title", "Seleccione el núcleo donde aspira trabajar");
			notificar ("<li class='fa  fa-warning '/> Notificacion", "Seleccione el núcleo donde aspira trabajar", "type-warning");
		}
		else if (apellidossuplente == "")
		{
			$("#grupoApellidos").addClass("has-error")
			$("#apellidossuplente").attr("title", "Ingresar sus apellidos");
		}
		else if (sexo == "0")
		{
			$("#grupoSexo").addClass("has-error")
			$("#sexo").attr("title", "Seleccione un sexo");
			notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","Seleccione un sexo", "type-warning");
		}
		else if (motricidad == "0")
		{
			$("#grupoMotricidad").addClass("has-error")
			$("#sexo").attr("title", "Seleccione su motricidad");
			notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","Seleccione su motricidad", "type-warning");
		}
		else if (fechanacsuplente == "")
		{
			$("#grupoFechaNac").addClass("has-error")
			//$("#fechanacsuplente").attr("title", "Ingresar su fecha de nacimiento");
			notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","Ingrese su fecha de nacimiento", "type-warning");
		}
		else if (cedulasuplente == "")
		{
			$("#grupoCedula").addClass("has-error")
			$("#cedulasuplente").attr("title", "Ingresar su n&uacute;mero c&eacute;dula");
		}
		else if (emailsuplente == "" &&  telefono1 == "" &&  telefono2 == "")
		{
			$("#grupoEmail").addClass("has-error");
			$("#grupoTlf1").addClass("has-error");
			$("#grupoTlf2").addClass("has-error");
			//if( $('#msgFooterDatos').length )         // use this if you are using id to check 
			//{
			     //$('#msgFooterDatos').html('<div class="alert alert-warning alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> <strong>Aviso!</strong> Debe ingresar alg&uacute;n dato de contacto (Email o Tel&eacute;fono)</h4></div>');
			     //$('#msgFooterDatos').html('<div class="ui-state-error ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;Aviso!</strong> Debe ingresar alg&uacute;n dato de contacto (Email o Tel&eacute;fono)</h4></div>');
				 notificar ("Aviso","Debe ingresar alg&uacute;n dato de contacto (Email o Tel&eacute;fono)", "type-warning");
			//}
			//$('#dialogo').html('Debe ingresar alg&uacute;n dato de contacto (Email o Tel&eacute;fono)');
			//$('#dialogo').dialog('open');
		}
		else if (banco == "0" ||  nctabnacaria == "" ||  tipoctabancaria == "0")
		{
			$("#banco").addClass("has-error");
			$("#nctabnacaria").addClass("has-error");
			$("#tipoctabancaria").addClass("has-error");
			//if( $('#msgFooterDatos').length )         // use this if you are using id to check 
			//{
			     //$('#msgFooterDatos').html('<div class="alert alert-warning alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> <strong>Aviso!</strong> Debe ingresar alg&uacute;n dato de contacto (Email o Tel&eacute;fono)</h4></div>');
			     //$('#msgFooterDatos').html('<div class="ui-state-error ui-corner-all" style="padding: 2px;height:30px;">&nbsp;<i class="icon fa fa-warning"></i><strong>&nbsp;Aviso!</strong> Debe ingresar alg&uacute;n dato de contacto (Email o Tel&eacute;fono)</h4></div>');
				 notificar ("Aviso","Debe llenar todos los datos bancarios", "type-warning");
			//}
			//$('#dialogo').html('Debe ingresar alg&uacute;n dato de contacto (Email o Tel&eacute;fono)');
			//$('#dialogo').dialog('open');
		}
		else if (!emailvalido)
		{
			$("#grupoEmail").addClass("has-error")
			$("#emailsuplente").attr("title", "Ingresar un formato de email valido");
		}
		else if (fortaleza1 == 0 &&  fortaleza2 == 0 &&  fortaleza3 == 0)
		{
			$("#grupoCargos").addClass("has-error")
			notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","Seleccione al menos un cargo por el cual optar", "type-warning");
		}
		else
		{
			//validarAdjuntos = 0;
			//var formData = "{'data1':'" + nombresuplente+ "', 'data2':'" + cedulasuplente+ "', 'data3':'" + emailasuplente+ "'}";
			var formData = {accion: 'actualizarDatosCandidato', validar_datos: 1, nucleo: nucleosuplente, profesion: profesionsuplente, nombres: nombresuplente, apellidos: apellidossuplente, cedula: precedula + '-' + cedulasuplente, fechanac:fechanacsuplente[2] + '-' + fechanacsuplente[1] + '-' + fechanacsuplente[0],email: emailsuplente, telefono1: telefono1, telefono2: telefono2, fortaleza1: fortaleza1, fortaleza2: fortaleza2, fortaleza3: fortaleza3,sexo:sexo,motricidad:motricidad,nctabnacaria:nctabnacaria,tipoctabancaria:tipoctabancaria,banco:banco};
			actualizarDatosCandidato(formData);
			limpiarCampos();
			buscarDatosCandidato();
		}
        break;
    case 'btnImgFoto':
		if ($("#imgfoto").val() != '')
		{
			var formData = new FormData($("#formFotoCarnet")[0]);
			subirImagen(formData, $(this).attr('id'));
		}
		else
		{
			notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","Seleccione una foto tipo carnet para subir", "type-warning");
		}
        break;
	case 'btnImgCed':
		if ($("#imgcedula").val() != '')
		{
			var formData = new FormData($("#formCedula")[0]);
			subirImagen(formData, $(this).attr('id'));
		}
		else
		{
			notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","Seleccione una imagen de su cedula para subir", "type-warning");
		}
        break;
    case 'btnImgSalud':
		if ($("#imgsalud").val() != '')
		{
			var formData = new FormData($("#formSalud")[0]);
			subirImagen(formData, $(this).attr('id'));
		}
		else
		{
			notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","Seleccione una imagen de su certificado de salud para subir", "type-warning");
		}
        break;
    case 'btnImgBco':
		if ($("#imgBanco").val() != '')
		{
			var formData = new FormData($("#formBanco")[0]);
			subirImagen(formData, $(this).attr('id'));
		}
		else
		{
			notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","Seleccione una imagen de un cheque o libreta a su nombre para subir", "type-warning");
		}
        break;
    case 'btnImgTit':
		if ($("#imgtitulo").val() != '')
		{
			var formData = new FormData($("#formTitulo")[0]);
			subirImagen(formData, $(this).attr('id'));
		}
		else
		{
			notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","Seleccione una imagen en fondo negro de su titulo para subir", "type-warning");
		}
        break;
    case 'btnPdfCV':
		if ($("#pdfcurriculum").val() != '')
		{
			var formData = new FormData($("#formCurriculum")[0]);
			subirPDF(formData);
		}
		else
		{
			notificar ("<li class='fa  fa-warning '/> Notificaci&oacute;n","Seleccione un archivo en formato PDF de su Curriculum vitae para subir", "type-warning");
		}
        break;

	default:
/* 		$("#botonGuardar").show();
		$('#dialogo').html('');
		$('#dialogo').dialog('open'); */
	}
	//$( "#tabSoportes" ).tooltip( "disable" );
	
}); 
//********************Fin evento click del boton*******************

function  limpiarCampos()
{
	//var formData = new FormData($('form')[0]);
	$("#grupoNucleo").removeClass("has-error");
	$("#grupoProfesion").removeClass("has-error");
	$("#grupoSexo").removeClass("has-error");
	$("#grupoMotricidad").removeClass("has-error");
	$("#grupoFechaNac").removeClass("has-error");
	$("#grupoEmail").removeClass("has-error");
	$("#grupoTlf1").removeClass("has-error");
	$("#grupoTlf1").removeClass("has-error");
	$("#grupoCargos").removeClass("has-error");
	$("#grupoBanco").removeClass("has-error");
}

	
//************PREVIENE EL CLICK EN LAS TABS DESABILITADAS**********************
/* $('a[data-toggle="tab"]').on('click', function(){
  if ($(this).parent('li').hasClass('disabled')) {
    return false;
  };
}); */

function validarEmail (email)
{

// Verificar el formato del email
var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
var valido = filter.test(email);
return valido
//*****************

}