<?php 
session_start();
//COMPRUEBA QUE EL USUARIO ESTA AUTENTIFICADO
if ($_SESSION["autenticado"] == "SI") {
//si no existe, envio a la página de autentificacion
header("Location: /main/pages/solicitudes/formulario.php");
//ademas salgo de este script
exit();
}
?>
<html>
  <head>
    <meta charset="UTF-8">
    <title>SuplenciasUDO</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/square/blue.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="login-page">
    <div class="login-box">
      <div class="login-logo">
		<img src="include/logo_udo.png" alt="?" title="?" /><br/>
        <a href="index.html"><b>Suplencias</b>UDO</a>
      </div><!-- /.login-logo -->
      <div class="login-box-body">
        <p class="login-box-msg">Ingrese su usuario y clave</p>
        <form action="#" onsubmit="iniciarSesion();">
          <div class="form-group has-feedback">
            <input type="user" class="form-control" placeholder="Usuario" id="username" required>
            <span class="glyphicon glyphicon-user form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
            <input type="password" class="form-control" placeholder="Clave" id="password" required>
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
          <div class="row">
            <div class="col-xs-8">
  <!--             <div class="checkbox icheck">
                <label>
                  <input type="checkbox"> Remember Me
                </label>
              </div> -->
			  <div id="errorlogin" style="color:red; font-weight: bold;  visibility: hidden;">Usuario y/o Clave incorrectos</div>
            </div><!-- /.col -->
            <div class="col-xs-4">
              <button type="submit" class="btn btn-primary btn-block btn-flat">Acceder</button>
              <!-- <button class="btn btn-primary btn-block btn-flat" onclick="window.location.href = 'pages/solicitudes/formulario.php';">Acceder</button> -->
            </div><!-- /.col -->
          </div>
        </form>
<!-- 
        <div class="social-auth-links text-center">
          <p>- OR -</p>
          <a href="#" class="btn btn-block btn-social btn-facebook btn-flat"><i class="fa fa-facebook"></i> Sign in using Facebook</a>
          <a href="#" class="btn btn-block btn-social btn-google btn-flat"><i class="fa fa-google-plus"></i> Sign in using Google+</a>
        </div><!-- /.social-auth-links

        <a href="#">I forgot my password</a><br> -->
		<a href="resgistrarse.html">Registrarse</a><br>
        <a href="mailto:jjlion79@gmail.com" class="text-center">Contactar al administrador</a>

      </div><!-- /.login-box-body -->
    </div><!-- /.login-box -->

    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
	<!-- Comun -->
    <script src="include/js/comunes.js"></script>
	
<script>

</script>
  </body>
</html>
