
<html>
  <head>
    <meta charset="UTF-8">
    <title>SuplenciasUDO</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
	<!-- Bootstraps Dialog -->
    <link rel="stylesheet" href="plugins/bootstrap-dialog/bootstrap-dialog.min.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="login-page">
    <div class="login-box">
      <div class="login-logo">
			  <img src="include/logo_udo.png"/><br/>
       <h2 style="width:800px; text-align:left;"><b>Contrataciones y Suplencias</b></h2>
      </div><!-- /.login-logo -->
      <div class="login-box-body">
        <p class="login-box-msg"><b>Registro de nuevos candidatos</b></p>
        <form action="#" onsubmit="registrarUsuario(0);">

		<div class="row">
			<div class="col-xs-12">
			<p class="">Ingresar un n&uacute;mero de c&eacute;dula y validar</p>
				
			</div>
		</div>
		<div class="row">
			<div class="col-xs-4">
				<div class="form-group has-feedback">
					<select id="precedula" name="precedula" class="form-control">
						<option value="V" selected>V</option>
						<option value="E">E</option>
					</select>					
				</div>
			</div>

			<div class="col-xs-8">
				<div class="form-group has-feedback">
					<input type="text" class="form-control entero" placeholder="Cedula" id="cedula" required>
					<!-- <span class="form-control-feedback"><big><b>#</b></big></span> -->
				</div>
			</div>
			

		</div>
		<div class="row">
            <div class="col-xs-4">
				<div class="form-group has-feedback">
					<span id="btnValidar" class="btn btn-primary btn-block btn-flat" onclick="validarCNE()">Validar</span>
				</div>
			</div>
            <div class="col-xs-4">
				<div class="form-group has-feedback">
					<span class="btn btn-danger btn-block btn-flat" onclick="limpiarRegistro()">Limpiar</span>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-12">
				<div class="form-group has-feedback">
					<input type="text" class="form-control" placeholder="Nombres" id="nombres" disabled>
					<span class="glyphicon glyphicon-font form-control-feedback"></span>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-12">
				<div class="form-group has-feedback">
					<input type="text" class="form-control" placeholder="Apellidos" id="apellidos" disabled>
					<span class="glyphicon glyphicon-font form-control-feedback"></span>
				</div>
			</div>
		</div>
		<!-- CAMPOS OCULTOS DE PARROQUIA, MUNICIPIO  Y ESTADO -->
		<input type="hidden" class="form-control" id="parroquia">
		<input type="hidden" class="form-control" id="municipio">
		<input type="hidden" class="form-control" id="estado">
		
		<div class="row">
			<div class="col-xs-12">
				<div class="form-group has-feedback">
					<input type="text" class="form-control" placeholder="Email" id="email" required>
					<span class="glyphicon glyphicon-envelope form-control-feedback"></span>
				</div>
			</div>

        </div>
		 
          <div class="row">
            <div class="col-xs-12">
  <!--             <div class="checkbox icheck">
                <label>
                  <input type="checkbox"> Remember Me
                </label>
              </div> 
			  
			  			  <div class="form-group has-feedback">
				<input type="text" class="form-control" placeholder="Apellidos" id="apellido" required>
				<span class="glyphicon glyphicon-font form-control-feedback"></span>
			  </div>
			  <div class="form-group has-feedback">
				<input type="text" class="form-control" placeholder="Email" id="email" required>
				<span class="glyphicon glyphicon-envelope form-control-feedback"></span>
			  </div>
			
			  
			  -->
			  <div id="errorReg" style="color:red; font-weight: bold;  visibility: hidden;">Email registrado en el sistema</div>
            </div><!-- /.col -->
            <div class="col-xs-4">
              <button id="btnRegistrar" type="submit" class="btn btn-primary btn-block btn-flat" disabled>Registrarse</button>
            </div><!-- /.col -->
          </div>
        </form>
<!-- 
        <div class="social-auth-links text-center">
          <p>- OR -</p>
          <a href="#" class="btn btn-block btn-social btn-facebook btn-flat"><i class="fa fa-facebook"></i> Sign in using Facebook</a>
          <a href="#" class="btn btn-block btn-social btn-google btn-flat"><i class="fa fa-google-plus"></i> Sign in using Google+</a>
        </div><!-- /.social-auth-links

        <a href="#">I forgot my password</a><br> -->
		<a href="index.html">Usuario Existente</a><br>
        <a href="mailto:jjlion79@gmail.com" class="text-center">Contactar al administrador</a>

      </div><!-- /.login-box-body -->
    </div><!-- /.login-box -->

    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
	<!-- Comun -->
    <script src="include/js/comunes.js"></script>
	<!-- UI -->
    <script src="include/js/ui.js"></script>
	<!-- Bootstraps Dialog -->
	<script src="plugins/bootstrap-dialog/bootstrap-dialog.min.js"></script>
	<!-- Numeros -->
	<script src="plugins/number/jquery.number.js"></script>
	
<script>
$('.entero').number( true, 0, ',', '' );
limpiarRegistro ();
</script>
  </body>
</html>
